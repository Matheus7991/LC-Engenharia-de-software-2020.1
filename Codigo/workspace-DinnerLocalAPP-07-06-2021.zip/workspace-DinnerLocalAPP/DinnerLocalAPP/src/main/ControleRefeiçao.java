package main;

import java.sql.SQLException;
import java.util.ArrayList;

import dados.RepositorioRefei�ao;

public class ControleRefei�ao {
	//cadastrar
	//remover
	//atualizar
	//procurar
	
	public static ArrayList<Refei�ao> Refei�oes = new ArrayList<Refei�ao>();
	
	private static RepositorioRefei�ao Repo = new RepositorioRefei�ao();
	
	public static void cadastrarRefei�ao(String nome) {
		if (procurarRefei�ao(nome)!=null) {
			return;
		}
		int i =0;
		while (procurarRefei�aoNid(Integer.toString(i))!=null) {
			i=i+1;
		}
		Refei�ao P = new Refei�ao(i, nome);
		Refei�oes.add(P);
		
		try {
			Repo.cadastrarRefei�ao(nome);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void removerRefei�ao(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return;
		}
		Refei�oes.remove(r);
		
		try {
			Repo.removerRefei�ao(n);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void atualizar() throws SQLException {
		ArrayList<ArrayList<String>> received = Repo.getUpdate();
		Refei�oes.clear();
		
		int i = 0;
		int u = received.size()-1;
		while (i<=u) {
			String n = received.get(i).get(0);
			cadastrarRefei�ao(n);
			modPreco(n, Integer.parseInt(received.get(i).get(1)));
			String p = received.get(i).get(2);//"aaa|bbb|ccc|";
			String q = received.get(i).get(3);
			while (true) {
				int pp = p.indexOf("|");
				if (pp==-1) {
					break;
				}
				
				String pc = p.substring(0,pp);
				String qc = q.substring(0,q.indexOf("|"));
				p = p.substring(pp+1);
				q = q.substring(q.indexOf("|")+1);
				addIgred(n, pc,Integer.parseInt(qc));
			}
			
			i=i+1;
		}
		
	}
	
	public static Refei�ao procurarRefei�ao(String n) {
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			if (o.getName().compareTo(n)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}
	
	private static Refei�ao procurarRefei�aoNid(String nid) {
		int inid = Integer.parseInt(nid);
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			if (o.getNid()==inid) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}

	public static ArrayList<Refei�ao> getRefei() {
		return Refei�oes;
	}

	public static void modPreco(String string, int i) {
		Refei�ao r = procurarRefei�aoNid(string);
		if (r==null) {
			return;
		}
		r.setCusto(i);
		
	}

	public static ArrayList<String> getIDs() {
		ArrayList<String> r = new ArrayList<String>();
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			r.add(Integer.toString(Refei�oes.get(i).getNid()));
			i=i+1;
		}
		return r;
	}

	public static ArrayList<String> getIgred(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return null;
		}
		return r.getigreds();
	}

	public static void removIgred(String ID, String n) {
		Refei�ao r = procurarRefei�aoNid(ID);
		if (r==null) {
			return;
		}
		r.removigred(n);
	}

	public static void addIgred(String n, String ingred,int q) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return;
		}
		r.addigred(ingred,q);
		
	}

	public static String getnome(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return null;
		}
		return r.getName();
	}

	public static int getpreco(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return 0;
		}
		return r.getCusto();
	}

	public static void setnome(String n, String n2) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return;
		}
		r.setNome(n2);
	}

	
}
