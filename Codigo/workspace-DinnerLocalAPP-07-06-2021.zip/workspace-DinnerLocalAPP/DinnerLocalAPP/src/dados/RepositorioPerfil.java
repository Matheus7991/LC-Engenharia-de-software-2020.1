package dados;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RepositorioPerfil extends Repositorio {
	
	public void createtable() throws SQLException {//execute if table doesnt exists
		String createtable =
		"CREATE TABLE `new_testschema`.`perfil` (\r\n" + 
		"  `idPerfil` INT NOT NULL,\r\n" + 
		"  `NomePerfil` VARCHAR(45) NOT NULL,\r\n" + 
		"  `ModCardapio` TINYINT NULL,\r\n" + 
		"  `ModPedidos` TINYINT NULL,\r\n" + 
		"  `ModCozinha` TINYINT NULL,\r\n" + 
		"  `ModPerfil` TINYINT NULL,\r\n" + 
		"  `ModItemPedidos` TINYINT NULL,\r\n" + 
		"  `ModArquivo` TINYINT NULL,\r\n" + 
		"  PRIMARY KEY (`idPerfil`),\r\n" + 
		"  UNIQUE INDEX `idPerfil_UNIQUE` (`idPerfil` ASC) VISIBLE,\r\n" + 
		"  UNIQUE INDEX `Nome_UNIQUE` (`Nome` ASC) VISIBLE);\r\n" + 
		"";
		Execute(createtable);
	}

	public void cadastrarPerfil(String n) throws SQLException {
		String cmd = "INSERT INTO `new_testschema`.`perfil` (`NomePerfil`) VALUES ('"+n+"');";
		Execute(cmd);
	}

	public void removerPerfil(String n) throws SQLException {
		String cmd = "DELETE FROM `new_testschema`.`perfil` WHERE (`NomePerfil` = '"+n+"');";
		Execute(cmd);
	}

	public ArrayList<ArrayList<String>> getUpdate() throws SQLException {
		
		ResultSet results = Query("SELECT * FROM new_testschema.Perfil;");
		ArrayList<ArrayList<String>> r = new ArrayList<ArrayList<String>>();
		while (results.next()) {
			ArrayList<String> rr = new ArrayList<String>();
			rr.add(results.getString("NomePerfil"));
			rr.add(results.getString("ModCardapio"));
			rr.add(results.getString("ModPedidos"));
			rr.add(results.getString("ModCozinha"));
			rr.add(results.getString("ModPerfil"));
			rr.add(results.getString("ModItemPedidos"));
			rr.add(results.getString("ModArquivo"));
			r.add(rr);
		}
		return r;
	}

	public void modPermPerfil(String n, String perm, boolean value) throws SQLException {
		String cmd = "UPDATE `new_testschema`.`perfil` SET `"+perm+"` = '"+value+"' WHERE (`NomePerfil` = '"+n+"');";
		Execute(cmd);
	}
	
	
	
	
}
