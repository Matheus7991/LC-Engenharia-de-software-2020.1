package main;

public class Refei�ao {
	private int id = 0;
	private String nome = "";
	private String custo = "";
	
	public Refei�ao(int nid,String nnome,String ncusto) {
		this.id = nid;
		this.nome = nnome;
		this.custo = ncusto;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String r) {
		nome = r;
	}
	public String getCusto() {
		return custo;
	}
	public void setCusto(String r) {
		custo = r;
	}
}
