package main;

import java.io.IOException;
import java.util.ArrayList;

public class Fachada {
	
	
	public Fachada() {
		
	}
	
	public static void login(String CPF,String Senh) {
		int i = Main.Accounts.size()-1;
		Account u = null;
		while (i>=0) {
			if (Main.Accounts.get(i).getCPF().compareTo(CPF)==0) {
				u = Main.Accounts.get(i);
				break;
			}
			i=i-1;
		}
		if (u!=null) {
			if (u.getSenh().compareTo(Senh)==0) {
				Main.UsuarioAtual=u;
			}
		}
		
	}
	
	public static ArrayList<Refei�ao> getRefei(){
		return Main.Refei�oes;
	}
	
	
	public static void addRefei(String nome,String pre�o) throws IOException {
		if ((Main.UsuarioAtual==null) || (Main.UsuarioAtual.permModCardapio==false)) {
			throw new IOException("Acesso negado");
		}
		Main.Refei�oes.add(new Refei�ao(1,nome,pre�o));
	}
	public static void removRefei(String nome) throws IOException {
		if ((Main.UsuarioAtual==null) || (Main.UsuarioAtual.permModCardapio==false)) {
			throw new IOException("Acesso negado");
		}
		Main.Refei�oes.removeIf(n -> (nome.compareTo(n.getNome())==0));
	}
}


