package main;

import java.util.ArrayList;

public class ControlePedido {
	
	private static ArrayList<Pedido> Pedidos = new ArrayList<Pedido>();
	//Cadastrar
	//Remover
	//Atualizar
	//Procurar
	//Relatorio (Custo total de todos os pedidos)
	
	//encerrar pedido (o cliente esta pagando)
	
	public static void cadastrarPedido(String Nordem) {
		if (procurarPedido(Nordem)!=null) {
			return;
		}
		Pedido P = new Pedido(Nordem);
		Pedidos.add(P);
	}
	
	public static void removerPedido(String Nordem) {
		Pedido r = procurarPedido(Nordem);
		if (r==null) {
			return;
		}
		Pedidos.remove(r);
		
	}
	
	public static void atualizar() {
		
	}
	
	public static Pedido procurarPedido(String Nordem) {
		if (Nordem==null) {
			return null;
		}
		int u = Pedidos.size()-1;
		int i = 0;
		while (i<=u) {
			Pedido o = Pedidos.get(i);
			if (o.getNordem().compareTo(Nordem)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}

	public static ArrayList<String> getNOrdemPedidos() {
		ArrayList<String> r = new ArrayList<String>();
		int u = Pedidos.size()-1;
		int i = 0;
		while (i<=u) {
			Pedido o = Pedidos.get(i);
			r.add(o.getNordem());
			
			i=i+1;
		}
		return r ;
	}

	public static String getClientePedido(String Nordem) {
		if (Nordem==null) {
			return null;
		}
		Pedido p = procurarPedido(Nordem);
		if (p==null) {
			return null;
		}
		return p.getCliente();
	}

	public static String getEntradaPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getEntrada();
	}

	public static String getSaidaPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getSaida();
	}

	public static String getPreoTotPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getPreoTotal();
	}

	public static String getPreoExtPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getPreoExtra();
	}

	public static String getLocalPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getLocal();
	}

	public static String getEstadoPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getEstado();
	}

	public static void setClientePedido(String nOrdem, String v) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setCliente(v);
	}

	public static void setPreoExtPedido(String nOrdem, String v) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setPreoExt(v);
	}

	public static void setLocalPedido(String nOrdem, String v) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setLocal(v);
		
	}

	public static void enviarPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.enviar();
		
	}

	public static ArrayList<String> getRefeiPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getRefeiList(nOrdem);
		
	}

	public static void addRefeiPedido(String nOrdem, String n) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.addRefei(n);
		
	}

	public static void removRefeiPedido(String nOrdem, String text) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.removRefei(text);
	}

	public static String getEstadoRefei�ao(String nOrdem, String refei) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getEstadoRefei(refei);
		
	}

	public static void setEstadoRefeiPedido(String nOrdem, String refei, String text) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setEstadoRefei(refei,text);
		
	}

	public static String getQuantiRefei(String nOrdem, String refei) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getQuantiRefei(refei);
	}

	public static void setEstadoPedido(String nOrdem, String string) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setEstado(string);
	}

	public static void setEstadoTRefeiPedido(String nOrdem, String string) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setEstadoTRefei(string);
	}
	
	
}
