package main;

public class Account {
	private String CPF = "00011122233";
	private String senh = "1234";
	private String nome = "";
	private int salario = 0;
	private Perfil perfil = null;
	
	public Account(String nCPF,String nSenha) {
		this.CPF = nCPF;
		this.senh = nSenha;
	}
	
	public String getCPF() {
		return CPF;
	}
	public void setCPF(String r) {
		CPF = r;
	}
	public String getSenh() {
		return senh;
	}
	public void setSenh(String r) {
		senh = r;
	}
	public String getName() {
		return nome;
	}
	public void setName(String r) {
		nome = r;
	}
	public Perfil getPerfil() {
		return perfil;
	}
	public void setPerfil(String n) throws Exception {
		Perfil p = ControlePerfil.procurarPerfil(n);
		if (p==null) {
			throw new Exception("Perfil n�o existe");
		}
		perfil = p;
	}

	public int getSalario(){
		return salario;
	}
	
	public void setSalario(int v) {
		salario = v;
		
	}
	
}
