package main;

public class Refei�ao {
	private int id = 0;
	private String nome = "";
	private int custo;
	
	public Refei�ao(int nid,String nnome,int custo2) {
		this.id = nid;
		this.nome = nnome;
		this.custo = custo2;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String r) {
		nome = r;
	}
	public int getCusto() {
		return custo;
	}
	public void setCusto(int r) {
		custo = r;
	}

	public String getName() {
		return nome;
	}

	public int getNid() {
		return id;
	}
}
