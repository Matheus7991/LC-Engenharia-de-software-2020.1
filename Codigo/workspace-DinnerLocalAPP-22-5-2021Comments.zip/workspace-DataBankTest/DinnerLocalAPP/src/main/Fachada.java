package main;

import java.io.IOException;
import java.util.ArrayList;

import javax.swing.Icon;

public class Fachada {
	
	public static Account UsuarioAtual = null;
	
	
	//test variables
	public static void testvar() {
		ControlePerfil.cadastrarPerfil("Gerente");
		ControlePerfil.modPermPerfil("Gerente", "ModCardapio", true);
		ControlePerfil.modPermPerfil("Gerente", "ModPedidos", true);
		ControlePerfil.modPermPerfil("Gerente", "ModCozinha", true);
		ControlePerfil.modPermPerfil("Gerente", "ModPerfil", true);
		
		ControleAccount.cadastrarAccount("00011122233", "1234");
		ControleAccount.setNome("00011122233","gerente");
		try {
			ControleAccount.setPerfil("00011122233","Gerente");
		} catch (Exception e1) {
		}
		
		ControlePerfil.cadastrarPerfil("Atendente");
		ControlePerfil.modPermPerfil("Atendente", "ModPedidos", true);
		ControlePerfil.modPermPerfil("Atendente", "ModCozinha", true);
		
		ControleAccount.cadastrarAccount("11122233344", "1234");
		ControleAccount.setNome("11122233344","atendente");
		try {
			ControleAccount.setPerfil("11122233344","Atendente");
		} catch (Exception e) {
		}
		
		ControleRefei�ao.cadastrarRefei�ao(1,"ref1",1000);
		ControleRefei�ao.cadastrarRefei�ao(2,"ref2",2000);
		
		
	}
	//test variables end
	
	public static void login(String CPF,String Senh) {
		UsuarioAtual = ControleAccount.login(CPF,Senh);
		
	}
	
	public static ArrayList<Refei�ao> getRefei(){
		//recebe uma lista de refei�oes
		return ControleRefei�ao.getRefei();
	}
	
	
	public static void addRefei(String nome,String pre�o) throws IOException {
		//cria uma refei�ao
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModCardapio")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleRefei�ao.cadastrarRefei�ao(1,nome,Integer.parseInt(pre�o)); //TODO ask for nid
	}
	public static void removRefei(String nome) throws IOException {
		//remove uma refei�ao
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModCardapio")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleRefei�ao.removerRefei�ao(nome);
	}
	//move to controlerefei�ao end

	public static ArrayList<String> getPerfilNames() {
		//recebe nomes dos perfis
		return ControlePerfil.getPerfisNames();
	}

	public static ArrayList<String> getPerfilPermNames() {
		//recebe nomes das permissoes dos perfis
		return ControlePerfil.getPerfisPermNames();
	}

	public static void removerPerfil(String n) throws IOException {
		//remove um perfil
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePerfil.removerPerfil(n);
		
	}

	public static boolean getPerfPerm(String n, String n2) {
		//recebe a permissao de um perfil
		return ControlePerfil.getPerfPerm(n,n2);
	}

	public static void setPerfPerm(String n, String n2, boolean value) throws Exception {
		//muda a permissao de um perfil
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePerfil.setPerfPerm(n,n2,value);
	}

	public static void cadastrarPerfil(String n) throws IOException {
		//cria um perfil
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePerfil.cadastrarPerfil(n);
		
	}

	public static ArrayList<String> getContaNames() throws IOException {
		//recebe uma lista com nomes de contas
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		return ControleAccount.getContaNames();
	}

	public static void modNomeConta(String CPF, String v) throws IOException {
		//modifica o nome da conta
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.setNome(CPF,v);
		
	}

	public static void modCPFConta(String CPF, String v) throws IOException {
		//modifica o CPF da conta
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.setCPF(CPF, v);
		
	}

	public static void modPerfConta(String CPF, String v) throws Exception {
		//modifica o perfil da conta
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.setPerfil(CPF,v);
		
	}

	public static void modSalarioConta(String CPF, int v) throws IOException {
		//modifica o salario da conta
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.setSalario(CPF,v);
		
	}

	public static void modSenhaConta(String CPF, String v) throws IOException {
		//modifica a senha da conta
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.setSenha(CPF,v);
		
	}

	public static String GetSenha(String CPF) {
		//recebe a senha da conta
		return ControleAccount.getSenha(CPF);
	}

	public static void removerConta(String CPF) throws IOException {
		//remove uma conta
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.removerAccount(CPF);
		
	}

	public static String getContaName(String CPF) {
		//recebe o nome da conta
		return ControleAccount.getContaName(CPF);
	}

	public static String getPerfilConta(String CPF) {
		//recebe o perfil da conta
		return ControleAccount.getPerfil(CPF);
	}

	public static String getSalarConta(String CPF) {
		//recebe o salario da conta
		return ControleAccount.getSalario(CPF);
	}


	public static String getCPFConta(String text) {
		//procura uma conta pelo CPF
		return ControleAccount.getCPFConta(text);
	}

	public static void CadastrarConta(String nome, String cpf, String perfil,String senha) throws Exception {
		//cria uma conta
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.cadastrarAccount(cpf, senha);
		ControleAccount.setNome(cpf,nome);
		ControleAccount.setPerfil(cpf,perfil);
		
	}

	public static Object procurarAccountPorNome(String vnome) {
		//procura uma conta pelo nome
		return ControleAccount.procurarAccountPorNome(vnome);
	}

	public static String getnomeusuarioatual() {
		//recebe o nome do usuario atual
		return UsuarioAtual.getName();
	}

	public static ArrayList<String> getNOrdemPedidos() {
		//recebe uma lista com o numero de ordem dos pedidos
		return ControlePedido.getNOrdemPedidos();
	}

	public static void cadastrarPedido(String n) throws IOException {
		//Cria um pedido
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.cadastrarPedido(n);
		
	}

	public static String getClientePedido(String nOrdem) {
		//recebe o cliente do pedido
		return ControlePedido.getClientePedido(nOrdem);
	}

	public static String getEntradaPedido(String nOrdem) {
		//recebe o horario e dia em que o pedido entrou
		return ControlePedido.getEntradaPedido(nOrdem);
	}

	public static String getSaidaPedido(String nOrdem) {
		//recebe o horario e dia em que o pedido saiu
		return ControlePedido.getSaidaPedido(nOrdem);
	}

	public static String getPreoTotPedido(String nOrdem) {
		//recebe a soma do pre�o de todos os items de um pedido
		return ControlePedido.getPreoTotPedido(nOrdem);
	}

	public static String getPreoExtPedido(String nOrdem) {
		//recebe o pre�o extra um pedido
		return ControlePedido.getPreoExtPedido(nOrdem);
	}

	public static String getLocalPedido(String nOrdem) {
		//recebe o local um pedido
		return ControlePedido.getLocalPedido(nOrdem);
	}

	public static String getEstadoPedido(String nOrdem) {
		//recebe o estado de um pedido
		return ControlePedido.getEstadoPedido(nOrdem);
	}

	public static void setClientePedido(String nOrdem, String v) throws IOException {
		//muda o cliente de um pedido
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setClientePedido(nOrdem,v);
		
	}

	public static void setPreoExtPedido(String nOrdem, String v) throws IOException {
		//muda o pre�o extra de um pedido
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setPreoExtPedido(nOrdem, v);
		
	}

	public static void setLocalPedido(String nOrdem, String v) throws IOException {
		//muda o local de um pedido
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setLocalPedido(nOrdem, v);
		
	}

	public static void EnviarPedido(String nOrdem) throws IOException {
		//muda o estado de um pedido para "Em preparo"
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.enviarPedido(nOrdem);
		
	}

	public static ArrayList<String> getItemsDoPedido(String nOrdem) {
		//recebe nomes das refei�oes do pedido
		return ControlePedido.getRefeiPedido(nOrdem);
	}

	public static void addRefeiPedido(String nOrdem, String n) throws IOException {
		//adiciona uma refei�ao a um pedido
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.addRefeiPedido(nOrdem,n);
		
	}

	public static void removRefeiPedido(String nOrdem, String text) throws IOException {
		//remove uma refei�ao de um pedido
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.removRefeiPedido(nOrdem,text);
		
	}

	public static String getEstadoRefei�ao(String nOrdem, String refei) {
		//recebe o estado do pedido
		return ControlePedido.getEstadoRefei�ao(nOrdem, refei);
	}

	public static void setEstadoRefeiPedido(String nOrdem, String refei, String text) throws IOException {
		//muda o estado de uma refei�ao de um pedido
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModCozinha")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setEstadoRefeiPedido(nOrdem,refei,text);
		
	}

	public static String getQuantiRefei(String nOrdem, String refei) {
		//recebe a quantidade de uma refei�ao de um pedido
		return ControlePedido.getQuantiRefei(nOrdem,refei);
	}

	public static void setEstadoPedido(String nOrdem, String string) throws IOException {
		//muda o estado do pedido
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModCozinha")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setEstadoPedido(nOrdem, string);
		
	}

	public static void setEstadoTRefeiPedido(String nOrdem, String string) throws IOException {
		//muda o estado de todas as refei�oes de um pedido
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModCozinha")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setEstadoTRefeiPedido(nOrdem, string);
	}

}


