package main;

import java.io.IOException;
import java.util.ArrayList;

import javax.swing.Icon;

public class Fachada {
	
	//test variables
	public static Account UsuarioAtual = null;
	
	
	
	public static void testvar() {
		ControlePerfil.cadastrarPerfil("Gerente");
		ControlePerfil.modPermPerfil("Gerente", "ModCardapio", true);
		ControlePerfil.modPermPerfil("Gerente", "ModPedidos", true);
		ControlePerfil.modPermPerfil("Gerente", "ModCozinha", true);
		ControlePerfil.modPermPerfil("Gerente", "ModPerfil", true);
		
		ControleAccount.cadastrarAccount("00011122233", "1234");
		ControleAccount.setNome("00011122233","gerente");
		try {
			ControleAccount.setPerfil("00011122233","Gerente");
		} catch (Exception e1) {
		}
		
		ControlePerfil.cadastrarPerfil("Atendente");
		ControlePerfil.modPermPerfil("Atendente", "ModPedidos", true);
		ControlePerfil.modPermPerfil("Atendente", "ModCozinha", true);
		
		ControleAccount.cadastrarAccount("11122233344", "1234");
		ControleAccount.setNome("11122233344","atendente");
		try {
			ControleAccount.setPerfil("11122233344","Atendente");
		} catch (Exception e) {
		}
		
		ControleRefei�ao.cadastrarRefei�ao(1,"ref1",1000);
		ControleRefei�ao.cadastrarRefei�ao(2,"ref2",2000);
		
		
	}
	//test variables end
	
	public static void login(String CPF,String Senh) {
		UsuarioAtual = ControleAccount.login(CPF,Senh);
		
	}
	
	public static String getNomeUsuario() {
		String r = "usuario";
		if (UsuarioAtual !=null) {
			r = UsuarioAtual.getName();
		}
		return r;
	}
	
	//move to controlerefei�ao
	public static ArrayList<Refei�ao> getRefei(){
		return ControleRefei�ao.getRefei();
	}
	
	
	public static void addRefei(String nome,String pre�o) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModCardapio")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleRefei�ao.cadastrarRefei�ao(1,nome,Integer.parseInt(pre�o)); //TODO ask for nid
	}
	public static void removRefei(String nome) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModCardapio")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleRefei�ao.removerRefei�ao(nome);
	}
	//move to controlerefei�ao end

	public static ArrayList<String> getPerfilNames() {
		
		return ControlePerfil.getPerfisNames();
	}

	public static ArrayList<String> getPerfilPermNames() {
		return ControlePerfil.getPerfisPermNames();
	}

	public static void removerPerfil(String n) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePerfil.removerPerfil(n);
		
	}

	public static boolean getPerfPerm(String n, String n2) {
		return ControlePerfil.getPerfPerm(n,n2);
	}

	public static void setPerfPerm(String n, String n2, boolean value) throws Exception {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePerfil.setPerfPerm(n,n2,value);
	}

	public static void cadastrarPerfil(String n) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePerfil.cadastrarPerfil(n);
		
	}

	public static ArrayList<String> getContaNames() throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		return ControleAccount.getContaNames();
	}

	public static void modNomeConta(String CPF, String v) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.setNome(CPF,v);
		
	}

	public static void modCPFConta(String CPF, String v) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.setCPF(CPF, v);
		
	}

	public static void modPerfConta(String CPF, String v) throws Exception {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.setPerfil(CPF,v);
		
	}

	public static void modSalarioConta(String CPF, int v) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.setSalario(CPF,v);
		
	}

	public static void modSenhaConta(String CPF, String v) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.setSenha(CPF,v);
		
	}

	public static String GetSenha(String CPF) {
		return ControleAccount.getSenha(CPF);
	}

	public static void removerConta(String CPF) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.removerAccount(CPF);
		
	}

	public static String getContaName(String CPF) {
		return ControleAccount.getContaName(CPF);
	}

	public static String getPerfilConta(String CPF) {
		return ControleAccount.getPerfil(CPF);
	}

	public static String getSalarConta(String CPF) {
		return ControleAccount.getSalario(CPF);
	}

	public static String getSenhaConta(String CPF) {
		return ControleAccount.getSenha(CPF);
	}

	public static String getCPFConta(String text) {
		return ControleAccount.getCPFConta(text);
	}

	public static void CadastrarConta(String nome, String cpf, String perfil,String senha) throws Exception {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPerfil")==false)) {
			throw new IOException("Acesso negado");
		}
		ControleAccount.cadastrarAccount(cpf, senha);
		ControleAccount.setNome(cpf,nome);
		ControleAccount.setPerfil(cpf,perfil);
		
	}

	public static Object procurarAccountPorNome(String vnome) {
		return ControleAccount.procurarAccountPorNome(vnome);
	}

	public static String getnomeusuarioatual() {
		return UsuarioAtual.getName();
	}

	public static ArrayList<String> getNOrdemPedidos() {
		return ControlePedido.getNOrdemPedidos();
	}

	public static void cadastrarPedido(String n) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.cadastrarPedido(n);
		
	}

	public static String getClientePedido(String nOrdem) {
		return ControlePedido.getClientePedido(nOrdem);
	}

	public static String getEntradaPedido(String nOrdem) {
		return ControlePedido.getEntradaPedido(nOrdem);
	}

	public static String getSaidaPedido(String nOrdem) {
		return ControlePedido.getSaidaPedido(nOrdem);
	}

	public static String getPreoTotPedido(String nOrdem) {
		return ControlePedido.getPreoTotPedido(nOrdem);
	}

	public static String getPreoExtPedido(String nOrdem) {
		return ControlePedido.getPreoExtPedido(nOrdem);
	}

	public static String getLocalPedido(String nOrdem) {
		return ControlePedido.getLocalPedido(nOrdem);
	}

	public static String getEstadoPedido(String nOrdem) {
		return ControlePedido.getEstadoPedido(nOrdem);
	}

	public static void setClientePedido(String nOrdem, String v) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setClientePedido(nOrdem,v);
		
	}

	public static void setPreoExtPedido(String nOrdem, String v) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setPreoExtPedido(nOrdem, v);
		
	}

	public static void setLocalPedido(String nOrdem, String v) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setLocalPedido(nOrdem, v);
		
	}

	public static void EnviarPedido(String nOrdem) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.enviarPedido(nOrdem);
		
	}

	public static ArrayList<String> getItemsDoPedido(String nOrdem) {
		return ControlePedido.getRefeiPedido(nOrdem);
	}

	public static void addRefeiPedido(String nOrdem, String n) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.addRefeiPedido(nOrdem,n);
		
	}

	public static void removRefeiPedido(String nOrdem, String text) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModPedidos")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.removRefeiPedido(nOrdem,text);
		
	}

	public static String getEstadoRefei�ao(String nOrdem, String refei) {
		
		return ControlePedido.getEstadoRefei�ao(nOrdem, refei);
	}

	public static void setEstadoRefeiPedido(String nOrdem, String refei, String text) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModCozinha")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setEstadoRefeiPedido(nOrdem,refei,text);
		
	}

	public static String getQuantiRefei(String nOrdem, String refei) {
		return ControlePedido.getQuantiRefei(nOrdem,refei);
	}

	public static void setEstadoPedido(String nOrdem, String string) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModCozinha")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setEstadoPedido(nOrdem, string);
		
	}

	public static void setEstadoTRefeiPedido(String nOrdem, String string) throws IOException {
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm("ModCozinha")==false)) {
			throw new IOException("Acesso negado");
		}
		ControlePedido.setEstadoTRefeiPedido(nOrdem, string);
	}

}


