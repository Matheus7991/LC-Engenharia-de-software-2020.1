package main;

import java.util.ArrayList;

public class ControleAccount {
private static ArrayList<Account> Contas = new ArrayList<Account>();
	
	public static ArrayList<Account> getContas() {
		return Contas;
	}
	
	
	public static void cadastrarAccount(String CPF,String senha) {
		if (procurarAccount(CPF)!=null) {
			return;
		}
		Account P = new Account(CPF, senha);
		Contas.add(P);
	}
	
	public static void removerAccount(String CPF) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		Contas.remove(r);
		
	}
	
	public static void atualizar() {
		
	}
	
	public static Account procurarAccount(String CPF) {
		if (CPF==null) {
			return null;
		}
		int u = Contas.size()-1;
		int i = 0;
		while (i<=u) {
			Account o = Contas.get(i);
			if (o.getCPF().compareTo(CPF)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}
	
	public static Account procurarAccountPorNome(String Nome) {
		int u = Contas.size()-1;
		int i = 0;
		while (i<=u) {
			Account o = Contas.get(i);
			if (o.getName().compareTo(Nome)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}


	public static ArrayList<String> getContaNames() {
		ArrayList<String> r = new ArrayList<String>();
		int u = Contas.size()-1;
		int i = 0;
		while (i<=u) {
			Account o = Contas.get(i);
			r.add(o.getName());
			
			i=i+1;
		}
		return r ;
	}


	public static void setNome(String CPF, String Nome) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		r.setName(Nome);
	}


	public static void setPerfil(String CPF, String nome) throws Exception {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		r.setPerfil(nome);
		
	}


	public static Account login(String CPF, String senh) {
		int i = Contas.size()-1;
		Account u = null;
		while (i>=0) {
			if (Contas.get(i).getCPF().compareTo(CPF)==0) {
				u = Contas.get(i);
				break;
			}
			i=i-1;
		}
		if (u!=null) {
			if (u.getSenh().compareTo(senh)==0) {
				return u;
			}
		}
		return null;
		
	}


	public static void setCPF(String CPF, String v) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		r.setCPF(v);
		
	}


	public static void setSalario(String CPF, int v) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		r.setSalario(v);
	}


	public static void setSenha(String CPF, String v) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		r.setSenh(v);
		
	}


	public static String getSenha(String CPF) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return null;
		}
		return r.getSenh();
		
	}


	public static String getContaName(String CPF) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return null;
		}
		return r.getName();
	}


	public static String getPerfil(String CPF) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return null;
		}
		return r.getPerfil().getName();
	}


	public static String getSalario(String CPF) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return null;
		}
		return Integer.toString(r.getSalario());
	}


	public static String getCPFConta(String Nome) {
		int u = Contas.size()-1;
		int i = 0;
		while (i<=u) {
			Account o = Contas.get(i);
			if (o.getName().compareTo(Nome)==0) {
				return o.getCPF();
			}
			
			i=i+1;
		}
		return null;
	}
	
	
}
