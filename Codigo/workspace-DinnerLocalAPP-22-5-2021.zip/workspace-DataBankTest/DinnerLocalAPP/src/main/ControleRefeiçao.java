package main;

import java.util.ArrayList;

public class ControleRefei�ao {
	//cadastrar
	//remover
	//atualizar
	//procurar
	
	public static ArrayList<Refei�ao> Refei�oes = new ArrayList<Refei�ao>();
	
	public static void cadastrarRefei�ao(int nid,String nome,int custo) {
		if (procurarRefei�ao(nome)!=null && procurarRefei�aoNid(nid)!=null) {
			return;
		}
		Refei�ao P = new Refei�ao(nid, nome, custo);
		Refei�oes.add(P);
	}

	public static void removerRefei�ao(String n) {
		Refei�ao r = procurarRefei�ao(n);
		if (r==null) {
			return;
		}
		Refei�oes.remove(r);
	}
	
	public static void atualizar() {
		
	}
	
	public static Refei�ao procurarRefei�ao(String n) {
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			if (o.getName().compareTo(n)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}
	
	private static Object procurarRefei�aoNid(int nid) {
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			if (o.getNid()==nid) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}

	public static ArrayList<Refei�ao> getRefei() {
		return Refei�oes;
	}
	
}
