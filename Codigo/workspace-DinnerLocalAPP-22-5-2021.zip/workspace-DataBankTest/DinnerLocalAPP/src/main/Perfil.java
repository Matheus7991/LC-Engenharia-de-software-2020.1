package main;

import java.util.ArrayList;

public class Perfil {
	
	private String nome="";
	private ArrayList<String> PermissoesNome= new ArrayList<String>();
	private ArrayList<Boolean> PermissoesBool= new ArrayList<Boolean>();
	
	public Perfil(String nnome) {
		this.nome=nnome;
		PermissoesNome.add("ModCardapio");
		PermissoesNome.add("ModPedidos");
		PermissoesNome.add("ModCozinha");
		PermissoesNome.add("ModPerfil");
		
		int u = PermissoesNome.size()-1;
		int i = 0;
		while (i<=u) {
			PermissoesBool.add(false);
			i=i+1;
		}
		
	}
	
	public String getName() {
		return nome;
	}
	public void setName(String r) {
		nome = r;
	}
	
	public boolean setPerm (String n, boolean value) {
		int r = PermissoesNome.indexOf(n);
		if (r==-1) {
			return false;
		}else {
			PermissoesBool.set(r, value);
			return true;
		}
		
	}
	
	public boolean getPerm(String n) {
		return  PermissoesBool.get(PermissoesNome.indexOf(n));
	}

	public ArrayList<String> getPermNames() {
		return PermissoesNome;
	}
	
	
	
}
