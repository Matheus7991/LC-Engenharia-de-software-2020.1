package main;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;

public class Mainwindow {

	
	private Container Ocardapio = null;
	public JFrame frame;
	private JTextField txtCpf;
	private JPasswordField pwdSenha;
	private JTextField txtNome;
	private JTextField txtPreo;
	private JLabel lblBemVindoUsuario;
	private JPanel panel_14; //Tela de perfis
	private JPanel panel_13; //Tela de mod de perfis
	private JLabel lblSelecionarPerfil; //Texto selecionar perfil
	private JPanel panel_1; //Tela de contas
	private String CPFselecion=null;
	private JLabel lblNome_2;//Nome da conta selecionada
	private JLabel lblCpf_1; //CPF da conta selecionada
	private JLabel lblPerfil; //Perfil da contaselecionada
	private JLabel lblSalario; //Salario da conta selecionada
	private JLabel lblSenha_1; //Senha da  conta selecionada
	private JPanel panel_15; //Tela de pedidos;
	private String Pedidoselecion = null;
	private JLabel lblNomecliente; //Nome cliente, do pedido selecionado
	private JLabel lblNordem_1; //N.Ordem, do pedido selecionado 
	private JLabel lblEntrada_1; //Entrada do pedido selecionado
	private JLabel lblSaida_1; //saida to pedido selecionado
	private JLabel lblPreoTotal; //pre�o dos items , do pedido selecionado
	private JLabel lblPreoExra;//pre�o extra , do pedido
	private JLabel lblPreoTotal_1;//pre�o dos items + extra
	private JLabel lblLocal_1;//Local
	private JLabel lblEstado_2;//estado do pedido (Editando, Em espera, Em preparo, Pronto, Em entrega, Encerrado, Cancelado)
	private JPanel panel_16;//tela de items do pedido;
	private JPanel panel_5;//tela de cozinha
	
	
	// Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mainwindow window = new Mainwindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	 
	/**
	 * Create the application.
	 */
	public Mainwindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		Fachada.testvar();
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 701, 477);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		frame.getContentPane().add(tabbedPane, BorderLayout.CENTER);
		
		JPanel LoginPanel = new JPanel();
		tabbedPane.addTab("Login", null, LoginPanel, null);
		LoginPanel.setLayout(null);
		
		lblBemVindoUsuario = new JLabel("Bem vindo usuario");
		lblBemVindoUsuario.setBounds(10, 11, 460, 14);
		LoginPanel.add(lblBemVindoUsuario);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fachada.login(txtCpf.getText(),String.valueOf(pwdSenha.getPassword()));
				AtualizarLogin();
			}
		});
		btnLogin.setBounds(10, 360, 89, 23);
		LoginPanel.add(btnLogin);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setBounds(10, 335, 46, 14);
		LoginPanel.add(lblSenha);
		
		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setBounds(10, 310, 46, 14);
		LoginPanel.add(lblCpf);
		
		txtCpf = new JTextField();
		txtCpf.setText("CPF");
		txtCpf.setBounds(55, 304, 86, 20);
		LoginPanel.add(txtCpf);
		txtCpf.setColumns(10);
		
		pwdSenha = new JPasswordField();
		pwdSenha.setText("Senha");
		pwdSenha.setBounds(55, 329, 86, 20);
		LoginPanel.add(pwdSenha);
		
		JPanel PedidosPanel = new JPanel();
		tabbedPane.addTab("Pedidos", null, PedidosPanel, null);
		PedidosPanel.setLayout(null);
		
		JLabel lblSelectionarPedido = new JLabel("Selectionar pedido:");
		lblSelectionarPedido.setBounds(10, 11, 112, 14);
		PedidosPanel.add(lblSelectionarPedido);
		
		JScrollPane scrollPane_8 = new JScrollPane();
		scrollPane_8.setBounds(10, 36, 173, 379);
		PedidosPanel.add(scrollPane_8);
		
		panel_15 = new JPanel();
		scrollPane_8.setViewportView(panel_15);
		GridBagLayout gbl_panel_15 = new GridBagLayout();
		gbl_panel_15.columnWidths = new int[] {150, 0};
		gbl_panel_15.rowHeights = new int[] {30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0};
		gbl_panel_15.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gbl_panel_15.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		panel_15.setLayout(gbl_panel_15);
		
		JScrollPane scrollPane_9 = new JScrollPane();
		scrollPane_9.setBounds(507, 36, 173, 359);
		PedidosPanel.add(scrollPane_9);
		
		panel_16 = new JPanel();
		scrollPane_9.setViewportView(panel_16);
		GridBagLayout gbl_panel_16 = new GridBagLayout();
		gbl_panel_16.columnWidths = new int[] {150, 0};
		gbl_panel_16.rowHeights = new int[] {30, 30, 30, 0, 0, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0};
		gbl_panel_16.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gbl_panel_16.rowWeights = new double[]{0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel_16.setLayout(gbl_panel_16);
		
		JLabel lblItemsDoPedido = new JLabel("Items (Clique para remover)");
		lblItemsDoPedido.setBounds(499, 11, 181, 14);
		PedidosPanel.add(lblItemsDoPedido);
		
		JButton btnEditar = new JButton("Editar:"); //Nomecliente
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (Pedidoselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Novo Nome:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					Fachada.setClientePedido(Pedidoselecion,v);
				} catch (IOException e) {
					JOptionPane.showMessageDialog(frame, e.getMessage());
				}
				atualizarPedidos();
			}
		});
		btnEditar.setBounds(432, 36, 65, 23);
		PedidosPanel.add(btnEditar);
		
		lblNomecliente = new JLabel("NomeCliente:");
		lblNomecliente.setBounds(193, 36, 229, 23);
		PedidosPanel.add(lblNomecliente);
		
		JButton button_18 = new JButton("Editar:");//pre�o extra
		button_18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Pedidoselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Pre�o extra:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					Fachada.setPreoExtPedido(Pedidoselecion,v);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
			}
		});
		button_18.setBounds(432, 206, 65, 23);
		PedidosPanel.add(button_18);
		
		lblNordem_1 = new JLabel("N.Ordem:");
		lblNordem_1.setBounds(193, 70, 229, 23);
		PedidosPanel.add(lblNordem_1);
		
		lblEntrada_1 = new JLabel("Entrada:");
		lblEntrada_1.setBounds(193, 104, 229, 23);
		PedidosPanel.add(lblEntrada_1);
		
		lblSaida_1 = new JLabel("Saida:");
		lblSaida_1.setBounds(193, 138, 229, 23);
		PedidosPanel.add(lblSaida_1);
		
		lblPreoTotal = new JLabel("Pre\u00E7o Items");
		lblPreoTotal.setBounds(193, 176, 229, 23);
		PedidosPanel.add(lblPreoTotal);
		
		lblPreoExra = new JLabel("Pre\u00E7o Extra");
		lblPreoExra.setBounds(193, 206, 229, 23);
		PedidosPanel.add(lblPreoExra);
		
		lblPreoTotal_1 = new JLabel("Pre\u00E7o Total");
		lblPreoTotal_1.setBounds(193, 240, 229, 23);
		PedidosPanel.add(lblPreoTotal_1);
		
		lblLocal_1 = new JLabel("Local");
		lblLocal_1.setBounds(193, 274, 229, 23);
		PedidosPanel.add(lblLocal_1);
		
		JButton button_17 = new JButton("Editar:"); //Local
		button_17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Pedidoselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Local:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					Fachada.setLocalPedido(Pedidoselecion,v);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
			}
		});
		button_17.setBounds(432, 274, 65, 23);
		PedidosPanel.add(button_17);
		
		lblEstado_2 = new JLabel("Estado: ");
		lblEstado_2.setBounds(193, 308, 229, 23);
		PedidosPanel.add(lblEstado_2);
		
		JButton btnEnviar_1 = new JButton("Enviar");
		btnEnviar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.setEstadoPedido(Pedidoselecion, "Em espera");
					Fachada.setEstadoTRefeiPedido(Pedidoselecion, "Em espera");
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
			}
		});
		btnEnviar_1.setBounds(193, 342, 89, 23);
		PedidosPanel.add(btnEnviar_1);
		
		JButton btnAtualizar_3 = new JButton("Atualizar");
		btnAtualizar_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atualizarPedidos();
			}
		});
		btnAtualizar_3.setBounds(591, 392, 89, 23);
		PedidosPanel.add(btnAtualizar_3);
		
		JButton btnEncerrar = new JButton("Encerrar");
		btnEncerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.setEstadoPedido(Pedidoselecion, "Encerrado");
					Fachada.setEstadoTRefeiPedido(Pedidoselecion, "Encerrado");
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
			}
		});
		btnEncerrar.setBounds(193, 376, 89, 23);
		PedidosPanel.add(btnEncerrar);
		
		JButton btnCancelar_1 = new JButton("Cancelar");
		btnCancelar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.setEstadoPedido(Pedidoselecion, "Cancelado");
					Fachada.setEstadoTRefeiPedido(Pedidoselecion, "Cancelado");
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
			}
		});
		btnCancelar_1.setBounds(292, 376, 89, 23);
		PedidosPanel.add(btnCancelar_1);
		//##############################################################################
		/*
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.insets = new Insets(0, 0, 5, 0);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 0;
		Ocardapio.add(panel_1, gbc_panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(0, 0, 46, 14);
		panel_1.add(lblNome);
		
		JButton btnAdicionar = new JButton("Adicionar");
		btnAdicionar.setBounds(546, 0, 89, 23);
		panel_1.add(btnAdicionar);
		
		JButton btnModificar = new JButton("Modificar");
		btnModificar.setBounds(448, 0, 89, 23);
		panel_1.add(btnModificar);
		
		JLabel lblPreo = new JLabel("Pre\u00E7o");
		lblPreo.setBounds(334, 0, 46, 14);
		panel_1.add(lblPreo);
		*/
		
		JPanel CozinhaPanel = new JPanel();
		CozinhaPanel.setLayout(null);
		tabbedPane.addTab("Cozinha", null, CozinhaPanel, null);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(10, 11, 670, 364);
		CozinhaPanel.add(scrollPane_4);
		
		panel_5 = new JPanel();
		scrollPane_4.setViewportView(panel_5);
		GridBagLayout gbl_panel_5 = new GridBagLayout();
		gbl_panel_5.columnWidths = new int[]{663, 0};
		gbl_panel_5.rowHeights = new int[] {60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60};
		gbl_panel_5.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_panel_5.rowWeights = new double[]{0.0, 1.0, 1.0, 1.0, 0.0};
		panel_5.setLayout(gbl_panel_5);
		
		//################################################
		JPanel panel_6 = new JPanel();
		panel_6.setLayout(null);
		GridBagConstraints gbc_panel_6 = new GridBagConstraints();
		gbc_panel_6.fill = GridBagConstraints.BOTH;
		gbc_panel_6.insets = new Insets(0, 0, 5, 0);
		gbc_panel_6.gridx = 0;
		gbc_panel_6.gridy = 0;
		panel_5.add(panel_6, gbc_panel_6);
		
		JLabel label_2 = new JLabel("Codigo");
		label_2.setBounds(10, 4, 231, 14);
		panel_6.add(label_2);
		
		JButton button_2 = new JButton("Pronto");
		button_2.setBounds(564, 4, 89, 23);
		panel_6.add(button_2);
		
		JButton button_3 = new JButton("Em Preparo");
		button_3.setBounds(465, 4, 89, 23);
		panel_6.add(button_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.PINK);
		panel_4.setBounds(337, 4, 118, 23);
		panel_6.add(panel_4);
		
		JLabel lblEstado_1 = new JLabel("Estado");
		panel_4.add(lblEstado_1);
		lblEstado_1.setBackground(Color.PINK);
		
		JLabel lblNordem_2 = new JLabel("NOrdem: ");
		lblNordem_2.setBounds(262, 4, 65, 14);
		panel_6.add(lblNordem_2);
		
		JLabel lblEntrada_2 = new JLabel("Entrada:");
		lblEntrada_2.setBounds(10, 30, 317, 14);
		panel_6.add(lblEntrada_2);
		
		JLabel lblSaida_2 = new JLabel("Saida:");
		lblSaida_2.setBounds(337, 30, 46, 14);
		panel_6.add(lblSaida_2);
		
		//################################################
		
		JButton btnAtualizar_4 = new JButton("Atualizar");
		btnAtualizar_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AtualizarCozinha();
			}
		});
		btnAtualizar_4.setBounds(591, 386, 89, 23);
		CozinhaPanel.add(btnAtualizar_4);
		
		JPanel CardapioPanel = new JPanel();
		tabbedPane.addTab("Cardapio", null, CardapioPanel, null);
		CardapioPanel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 665, 344);
		CardapioPanel.add(scrollPane);
		
		Ocardapio = new JPanel();
		scrollPane.setColumnHeaderView(Ocardapio);
		GridBagLayout gbl_Ocardapio = new GridBagLayout();
		gbl_Ocardapio.columnWidths = new int[]{663, 0};
		gbl_Ocardapio.rowHeights = new int[] {30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30};
		gbl_Ocardapio.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_Ocardapio.rowWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		Ocardapio.setLayout(gbl_Ocardapio);
		//##############################################################################
		
		
		JButton btnNovoItem = new JButton("Novo Item");
		btnNovoItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.addRefei(txtNome.getText(), txtPreo.getText());
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
					//e1.printStackTrace();
				}
				AtualizarCardapio();
			}
		});
		btnNovoItem.setBounds(10, 392, 99, 23);
		CardapioPanel.add(btnNovoItem);
		
		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AtualizarCardapio();
			}
		});
		btnAtualizar.setBounds(596, 366, 89, 23);
		CardapioPanel.add(btnAtualizar);
		
		JLabel lblNome_1 = new JLabel("Nome");
		lblNome_1.setBounds(10, 366, 46, 14);
		CardapioPanel.add(lblNome_1);
		
		txtNome = new JTextField();
		txtNome.setText("Nome");
		txtNome.setBounds(66, 366, 259, 20);
		CardapioPanel.add(txtNome);
		txtNome.setColumns(10);
		
		txtPreo = new JTextField();
		txtPreo.setText("Pre\u00E7o");
		txtPreo.setBounds(391, 366, 86, 20);
		CardapioPanel.add(txtPreo);
		txtPreo.setColumns(10);
		
		JLabel lblPreo_1 = new JLabel("Pre\u00E7o");
		lblPreo_1.setBounds(335, 366, 46, 14);
		CardapioPanel.add(lblPreo_1);
		
		JButton btnRemover = new JButton("Remover");
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Fachada.removRefei(txtNome.getText());
				} catch (IOException e) {
					JOptionPane.showMessageDialog(frame, e.getMessage());
					//e.printStackTrace();
				}
				AtualizarCardapio();
			}
		});
		btnRemover.setBounds(119, 392, 89, 23);
		CardapioPanel.add(btnRemover);
		
		JPanel EstoquePanel = new JPanel();
		tabbedPane.addTab("Estoque", null, EstoquePanel, null);
		EstoquePanel.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 11, 670, 325);
		EstoquePanel.add(scrollPane_1);
		
		JPanel panel = new JPanel();
		scrollPane_1.setViewportView(panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0};
		gbl_panel.rowHeights = new int[]{0};
		gbl_panel.columnWeights = new double[]{Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JPanel PerfilPanel = new JPanel();
		tabbedPane.addTab("Perfis", null, PerfilPanel, null);
		PerfilPanel.setLayout(null);
		
		lblSelecionarPerfil = new JLabel("Selecionar perfil:");
		lblSelecionarPerfil.setBounds(10, 11, 173, 14);
		PerfilPanel.add(lblSelecionarPerfil);
		
		JScrollPane scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(193, 36, 173, 379);
		PerfilPanel.add(scrollPane_6);
		
		panel_13 = new JPanel();
		scrollPane_6.setViewportView(panel_13);
		GridBagLayout gbl_panel_13 = new GridBagLayout();
		gbl_panel_13.columnWidths = new int[] {150};
		gbl_panel_13.rowHeights = new int[]{30, 0, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0};
		gbl_panel_13.columnWeights = new double[]{1.0};
		gbl_panel_13.rowWeights = new double[]{1.0, 1.0, 1.0, 0.0, 4.9E-324, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel_13.setLayout(gbl_panel_13);
		
		//#########################################################
		/*
		JCheckBox chckbxNewCheckBox = new JCheckBox("Permissao1");
		//chckbxNewCheckBox.setSelected(false);
		//Boolean r = chckbxNewCheckBox.isSelected();
		chckbxNewCheckBox.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_chckbxNewCheckBox = new GridBagConstraints();
		gbc_chckbxNewCheckBox.anchor = GridBagConstraints.WEST;
		gbc_chckbxNewCheckBox.insets = new Insets(0, 0, 5, 0);
		gbc_chckbxNewCheckBox.gridx = 0;
		gbc_chckbxNewCheckBox.gridy = 0;
		panel_13.add(chckbxNewCheckBox, gbc_chckbxNewCheckBox);
		*/
		//#########################################################
		/*
		JButton btnRemoverPerfil = new JButton("Remover Perfil");
		btnRemoverPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GridBagConstraints gbc_btnRemoverPerfil = new GridBagConstraints();
		gbc_btnRemoverPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnRemoverPerfil.gridx = 0;
		gbc_btnRemoverPerfil.gridy = 1;
		panel_13.add(btnRemoverPerfil, gbc_btnRemoverPerfil);
		*/
		//#########################################################
		
		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(10, 36, 173, 379);
		PerfilPanel.add(scrollPane_5);
		
		panel_14 = new JPanel();
		scrollPane_5.setViewportView(panel_14);
		GridBagLayout gbl_panel_14 = new GridBagLayout();
		gbl_panel_14.columnWidths = new int[] {150, 0};
		gbl_panel_14.rowHeights = new int[]{30, 0, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0};
		gbl_panel_14.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_panel_14.rowWeights = new double[]{1.0, 1.0, 1.0, 0.0, 4.9E-324, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel_14.setLayout(gbl_panel_14);
		
		//#################################################
		/*
		JButton btnNovoPerfil = new JButton("Novo Perfil");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GridBagConstraints gbc_btnNovoPerfil = new GridBagConstraints();
		gbc_btnNovoPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoPerfil.gridx = 0;
		gbc_btnNovoPerfil.gridy = 1;
		panel_14.add(btnNovoPerfil, gbc_btnNovoPerfil);
		*/
		//#################################################
		
		JLabel lblModificarPerfil = new JLabel("Permiss\u00F5es:");
		lblModificarPerfil.setBounds(193, 11, 103, 14);
		PerfilPanel.add(lblModificarPerfil);
		
		JButton btnAtualizar_1 = new JButton("Atualizar");
		btnAtualizar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atualizarPerfis();
			}
		});
		btnAtualizar_1.setBounds(596, 392, 89, 23);
		PerfilPanel.add(btnAtualizar_1);
		
		JPanel ContasPanel = new JPanel();
		tabbedPane.addTab("Contas", null, ContasPanel, null);
		ContasPanel.setLayout(null);
		
		JLabel lblSelecionarConta = new JLabel("Selecionar conta:");
		lblSelecionarConta.setBounds(10, 11, 117, 14);
		ContasPanel.add(lblSelecionarConta);
		
		JScrollPane scrollPane_7 = new JScrollPane();
		scrollPane_7.setBounds(10, 36, 173, 379);
		ContasPanel.add(scrollPane_7);
		
		panel_1 = new JPanel();
		scrollPane_7.setViewportView(panel_1);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[] {150};
		gbl_panel_1.rowHeights = new int[] {0, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0};
		gbl_panel_1.columnWeights = new double[]{0.0};
		gbl_panel_1.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		//#######################
		/*
		JButton btnConta = new JButton("Conta1");
		btnConta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		GridBagConstraints gbc_btnConta = new GridBagConstraints();
		gbc_btnConta.anchor = GridBagConstraints.WEST;
		gbc_btnConta.insets = new Insets(0, 0, 5, 0);
		gbc_btnConta.gridx = 0;
		gbc_btnConta.gridy = 0;
		panel_1.add(btnConta, gbc_btnConta);
		*/
		//#######################
		/*
		JButton btnNovaConta = new JButton("Nova Conta");
		btnNovaConta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GridBagConstraints gbc_btnNovaConta = new GridBagConstraints();
		gbc_btnNovaConta.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovaConta.gridx = 0;
		gbc_btnNovaConta.gridy = 1;
		panel_1.add(btnNovaConta, gbc_btnNovaConta);
		*/
		//#######################
		JLabel lblAes = new JLabel("A\u00E7\u00F5es:");
		lblAes.setBounds(634, 11, 46, 14);
		ContasPanel.add(lblAes);
		
		JButton editarnome = new JButton("Editar");//TO DO
		editarnome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (CPFselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Novo Nome:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					Fachada.modNomeConta(CPFselecion,v);
				} catch (IOException e) {
					JOptionPane.showMessageDialog(frame, e.getMessage());
				}
				atualizarContas();
				
			}
		});
		editarnome.setBounds(619, 36, 76, 23);
		ContasPanel.add(editarnome);
		
		lblNome_2 = new JLabel("Nome:");
		lblNome_2.setBounds(193, 36, 416, 22);
		ContasPanel.add(lblNome_2);
		
		JButton editarcpf = new JButton("Editar");
		editarcpf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (CPFselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Novo CPF:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					Fachada.modCPFConta(CPFselecion,v);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarContas();
			}
		});
		editarcpf.setBounds(619, 70, 76, 23);
		ContasPanel.add(editarcpf);
		
		JButton editarperfil = new JButton("Editar");
		editarperfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (CPFselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Novo Perfil:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					Fachada.modPerfConta(CPFselecion,v);
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarContas();
			}
		});
		editarperfil.setBounds(619, 104, 76, 23);
		ContasPanel.add(editarperfil);
		
		JButton editarsalario = new JButton("Editar");
		editarsalario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					if (CPFselecion==null) {
						return;
					}
					String v = JOptionPane.showInputDialog("Novo Salario:");
					if (v==null || v.isEmpty()) {
						return;
					}
					int vv = Integer.parseInt(v);
					try {
						Fachada.modSalarioConta(CPFselecion,vv);
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(frame, e1.getMessage());
					}
					atualizarContas();
			}
		});
		editarsalario.setBounds(619, 138, 76, 23);
		ContasPanel.add(editarsalario);
		
		lblCpf_1 = new JLabel("CPF:");
		lblCpf_1.setBounds(193, 69, 416, 22);
		ContasPanel.add(lblCpf_1);
		
		lblPerfil = new JLabel("Perfil:");
		lblPerfil.setBounds(193, 104, 416, 22);
		ContasPanel.add(lblPerfil);
		
		lblSalario = new JLabel("Salario:");
		lblSalario.setBounds(193, 138, 416, 22);
		ContasPanel.add(lblSalario);
		
		JButton btnRemover_1 = new JButton("Remover Conta");
		btnRemover_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (CPFselecion==null) {
					return;
				}
				try {
					Fachada.removerConta(CPFselecion);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				CPFselecion=null;
				atualizarContas();
			}
		});
		btnRemover_1.setBounds(558, 204, 122, 23);
		ContasPanel.add(btnRemover_1);
		
		JButton editarsenha = new JButton("Editar");
		editarsenha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (CPFselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Nova senha:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					Fachada.modSenhaConta(CPFselecion,v);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarContas();
			}
		});
		editarsenha.setBounds(619, 170, 76, 23);
		ContasPanel.add(editarsenha);
		
		JButton versenha = new JButton("Ver");
		versenha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				lblSenha_1.setText("Senha: "+Fachada.GetSenha(CPFselecion));
			}
		});
		versenha.setBounds(548, 170, 61, 23);
		ContasPanel.add(versenha);
		
		lblSenha_1 = new JLabel("Senha:");
		lblSenha_1.setBounds(193, 170, 345, 22);
		ContasPanel.add(lblSenha_1);
		
		JButton btnAtualizar_2 = new JButton("Atualizar");
		btnAtualizar_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atualizarContas();
			}
		});
		btnAtualizar_2.setBounds(591, 392, 89, 23);
		ContasPanel.add(btnAtualizar_2);
		
		JPanel PedidosoldPanel = new JPanel();
		tabbedPane.addTab("Pedidosold", null, PedidosoldPanel, null);
		PedidosoldPanel.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 11, 670, 314);
		PedidosoldPanel.add(scrollPane_2);
		
		JPanel panel_2 = new JPanel();
		scrollPane_2.setViewportView(panel_2);
		GridBagLayout gbl_panel_2 = new GridBagLayout();
		gbl_panel_2.columnWidths = new int[] {650};
		gbl_panel_2.rowHeights = new int[] {180, 180};
		gbl_panel_2.columnWeights = new double[]{1.0};
		gbl_panel_2.rowWeights = new double[]{0.0, 1.0};
		panel_2.setLayout(gbl_panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.YELLOW);
		panel_3.setLayout(null);
		GridBagConstraints gbc_panel_3 = new GridBagConstraints();
		gbc_panel_3.fill = GridBagConstraints.BOTH;
		gbc_panel_3.insets = new Insets(0, 0, 5, 0);
		gbc_panel_3.gridx = 0;
		gbc_panel_3.gridy = 0;
		panel_2.add(panel_3, gbc_panel_3);
		
		JLabel label = new JLabel("NomeCliente:");
		label.setBounds(10, 10, 78, 14);
		panel_3.add(label);
		
		JButton button = new JButton("Encerrado");
		button.setBounds(549, 134, 89, 23);
		panel_3.add(button);
		
		JButton button_1 = new JButton("Selecionar");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		button_1.setBounds(10, 141, 89, 23);
		panel_3.add(button_1);
		
		JLabel label_1 = new JLabel("Pre\u00E7o Total:");
		label_1.setBounds(10, 70, 65, 14);
		panel_3.add(label_1);
		
		JButton btnCancelar = new JButton("Cancelado");
		btnCancelar.setBounds(549, 100, 89, 23);
		panel_3.add(btnCancelar);
		
		JButton btnNewButton = new JButton("Em Preparo");
		btnNewButton.setBounds(450, 66, 89, 23);
		panel_3.add(btnNewButton);
		
		JLabel lblEstado = new JLabel("Estado:");
		lblEstado.setBounds(383, 11, 46, 14);
		panel_3.add(lblEstado);
		
		JButton btnEmEntrega = new JButton("Em entrega");
		btnEmEntrega.setBounds(450, 100, 89, 23);
		panel_3.add(btnEmEntrega);
		
		JButton btnPronto = new JButton("Pronto");
		btnPronto.setBounds(549, 66, 89, 23);
		panel_3.add(btnPronto);
		
		JLabel lblAlterarEstado = new JLabel("Alterar estado:");
		lblAlterarEstado.setBounds(536, 10, 102, 14);
		panel_3.add(lblAlterarEstado);
		
		JButton btnEditando = new JButton("Editando");
		btnEditando.setBounds(450, 32, 89, 23);
		panel_3.add(btnEditando);
		
		JLabel lblRefeioes = new JLabel("Refei\u00E7oes");
		lblRefeioes.setBounds(231, 11, 89, 14);
		panel_3.add(lblRefeioes);
		
		JButton btnEmEspera = new JButton("Em espera");
		btnEmEspera.setBounds(549, 32, 89, 23);
		panel_3.add(btnEmEspera);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(138, 36, 302, 121);
		panel_3.add(scrollPane_3);
		
		JLabel lblNordem = new JLabel("N.Ordem:");
		lblNordem.setBounds(10, 25, 65, 14);
		panel_3.add(lblNordem);
		
		JLabel lblEntrada = new JLabel("Entrada:");
		lblEntrada.setBounds(10, 40, 46, 14);
		panel_3.add(lblEntrada);
		
		JLabel lblSaida = new JLabel("Saida:");
		lblSaida.setBounds(10, 55, 46, 14);
		panel_3.add(lblSaida);
		
		JLabel lblLocal = new JLabel("Local:");
		lblLocal.setBounds(10, 85, 46, 14);
		panel_3.add(lblLocal);
		
		JButton btnEnviar = new JButton("Enviar");
		btnEnviar.setBounds(450, 134, 89, 23);
		panel_3.add(btnEnviar);
		
		JPanel DataPanel = new JPanel();
		tabbedPane.addTab("Arquivo", null, DataPanel, null);
	}
	
	//Atualizar
	private void AtualizarCardapio() {
		Ocardapio.removeAll();
		ArrayList<Refei�ao> refs = Fachada.getRefei();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JPanel panel_1 = new JPanel();
			GridBagConstraints gbc_panel_1 = new GridBagConstraints();
			gbc_panel_1.insets = new Insets(0, 0, 5, 0);
			gbc_panel_1.fill = GridBagConstraints.BOTH;
			gbc_panel_1.gridx = 0;
			gbc_panel_1.gridy = i; //+1
			Ocardapio.add(panel_1, gbc_panel_1);
			panel_1.setLayout(null);
			
			JLabel lblNome = new JLabel(refs.get(i).getNome());
			lblNome.setBounds(0, 0, 46, 14);
			panel_1.add(lblNome);
			
			JButton btnAdicionar = new JButton("Adicionar");
			btnAdicionar.setBounds(546, 0, 89, 23);
			panel_1.add(btnAdicionar);
			
			JButton btnModificar = new JButton("Modificar");
			btnModificar.setBounds(448, 0, 89, 23);
			panel_1.add(btnModificar);
			
			JLabel lblPreo = new JLabel(Integer.toString(refs.get(i).getCusto()));
			lblPreo.setBounds(334, 0, 86, 14);
			panel_1.add(lblPreo);
			i=i+1;
		}
		Ocardapio.revalidate();
		Ocardapio.repaint();
	}
	
	private void atualizarPerfis() {
		panel_14.removeAll();
		ArrayList<String> refs = Fachada.getPerfilNames();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JButton btnNomeperfil = new JButton(refs.get(i));
			btnNomeperfil.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					atualizarPerms(btnNomeperfil.getText());
					lblSelecionarPerfil.setText("Selecionar Perfil: "+btnNomeperfil.getText());
					//System.out.println(btnNomeperfil.getText());
				}
			});
			GridBagConstraints gbc_btnNomeperfil = new GridBagConstraints();
			gbc_btnNomeperfil.anchor = GridBagConstraints.WEST;
			gbc_btnNomeperfil.insets = new Insets(0, 0, 5, 0);
			gbc_btnNomeperfil.gridx = 0;
			gbc_btnNomeperfil.gridy = i;
			panel_14.add(btnNomeperfil, gbc_btnNomeperfil);
			i=i+1;
		}
		JButton btnNovoPerfil = new JButton("Novo Perfil");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Nome do perfil:");
				try {
					Fachada.cadastrarPerfil(n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPerfis();
				atualizarPerms(null);
				
			}
		});
		GridBagConstraints gbc_btnNovoPerfil = new GridBagConstraints();
		gbc_btnNovoPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoPerfil.gridx = 0;
		gbc_btnNovoPerfil.gridy = i;
		panel_14.add(btnNovoPerfil, gbc_btnNovoPerfil);
		panel_14.revalidate();
		panel_14.repaint();
	}
	
	private void atualizarPerms(String n) {
		panel_13.removeAll();
		if (n==null) {
			panel_13.revalidate();
			panel_13.repaint();
			return;
		}
		ArrayList<String> refs = Fachada.getPerfilPermNames();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JCheckBox chckbxNewCheckBox = new JCheckBox(refs.get(i));
			chckbxNewCheckBox.setSelected(Fachada.getPerfPerm(n,refs.get(i)));
			chckbxNewCheckBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						Fachada.setPerfPerm(n,chckbxNewCheckBox.getText(),chckbxNewCheckBox.isSelected());
					} catch (Exception e1) {
					}
					//System.out.println(chckbxNewCheckBox.isSelected());
				}
			});
			//chckbxNewCheckBox.setSelected(false);
			//Boolean r = chckbxNewCheckBox.isSelected();
			chckbxNewCheckBox.setHorizontalAlignment(SwingConstants.CENTER);
			GridBagConstraints gbc_chckbxNewCheckBox = new GridBagConstraints();
			gbc_chckbxNewCheckBox.anchor = GridBagConstraints.WEST;
			gbc_chckbxNewCheckBox.insets = new Insets(0, 0, 5, 0);
			gbc_chckbxNewCheckBox.gridx = 0;
			gbc_chckbxNewCheckBox.gridy = i;
			panel_13.add(chckbxNewCheckBox, gbc_chckbxNewCheckBox);
			i=i+1;
		}
		panel_13.revalidate();
		panel_13.repaint();
		JButton btnRemoverPerfil = new JButton("Remover Perfil");
		btnRemoverPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.removerPerfil(n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPerfis();
				atualizarPerms(null);
				lblSelecionarPerfil.setText("Selecionar Perfil:");
			}
		});
		GridBagConstraints gbc_btnRemoverPerfil = new GridBagConstraints();
		gbc_btnRemoverPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnRemoverPerfil.gridx = 0;
		gbc_btnRemoverPerfil.gridy = i;
		panel_13.add(btnRemoverPerfil, gbc_btnRemoverPerfil);
	}
	
	private void atualizarContas() {
		panel_1.removeAll();
		ArrayList<String> refs;
		try {
			refs = Fachada.getContaNames();
		} catch (IOException e2) {
			JOptionPane.showMessageDialog(frame, e2.getMessage());
			return;
		}
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JButton btnConta = new JButton(refs.get(i));
			btnConta.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					CPFselecion = Fachada.getCPFConta(btnConta.getText());
					atualizarContas();
				}
			});
			GridBagConstraints gbc_btnConta = new GridBagConstraints();
			gbc_btnConta.anchor = GridBagConstraints.WEST;
			gbc_btnConta.insets = new Insets(0, 0, 5, 0);
			gbc_btnConta.gridx = 0;
			gbc_btnConta.gridy = i;
			panel_1.add(btnConta, gbc_btnConta);
			i=i+1;
		}
		JButton btnNovaConta = new JButton("Nova Conta");
		btnNovaConta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String vnome =JOptionPane.showInputDialog("Nome da Conta");
				if (Fachada.procurarAccountPorNome(vnome)!=null) {
					JOptionPane.showMessageDialog(frame, "Este Nome j� existe");
					return;
				}
				String vcpf = JOptionPane.showInputDialog("CPF da Conta");
				if (Fachada.getContaName(vcpf)!=null) {
					JOptionPane.showMessageDialog(frame, "Este CPF j� existe");
					return;
				}
				String vsenha =JOptionPane.showInputDialog("Senha da Conta");
				String vperfil =JOptionPane.showInputDialog("Perfil da Conta");
				try {
					Fachada.CadastrarConta(vnome,vcpf,vperfil,vsenha);
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarContas();
			}
		});
		GridBagConstraints gbc_btnNovaConta = new GridBagConstraints();
		gbc_btnNovaConta.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovaConta.gridx = 0;
		gbc_btnNovaConta.gridy = i;
		panel_1.add(btnNovaConta, gbc_btnNovaConta);
		
		lblNome_2.setText("Nome: " + Fachada.getContaName(CPFselecion)); 
		lblCpf_1.setText("CPF: " + CPFselecion); 
		lblPerfil.setText("Perfil: " + Fachada.getPerfilConta(CPFselecion)); 
		lblSalario.setText("Salario: " + Fachada.getSalarConta(CPFselecion)); 
		lblSenha_1.setText("Senha: ");// + Fachada.getSenhaConta(CPFselecion)); 
		
		panel_1.revalidate();
		panel_1.repaint();
	}
	
	private void atualizarPedidos() {
		panel_15.removeAll();
		ArrayList<String> refs = Fachada.getNOrdemPedidos();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JButton btnNome = new JButton(refs.get(i));
			btnNome.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Pedidoselecion = btnNome.getText();
					atualizarPedidos();
				}
			});
			GridBagConstraints gbc_btnNome = new GridBagConstraints();
			gbc_btnNome.insets = new Insets(0, 0, 5, 0);
			gbc_btnNome.anchor = GridBagConstraints.WEST;
			gbc_btnNome.gridx = 0;
			gbc_btnNome.gridy = i;
			panel_15.add(btnNome, gbc_btnNome);
			i=i+1;
		}
		JButton btnNovoPerfil = new JButton("Novo Pedido");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Numero de ordem");
				try {
					Fachada.cadastrarPedido(n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
				
			}
		});
		GridBagConstraints gbc_btnNovoPerfil = new GridBagConstraints();
		gbc_btnNovoPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoPerfil.gridx = 0;
		gbc_btnNovoPerfil.gridy = i;
		panel_15.add(btnNovoPerfil, gbc_btnNovoPerfil);
		

		lblNomecliente.setText("NomeCliente: "+Fachada.getClientePedido(Pedidoselecion)); //Nome cliente, do pedido selecionado
		lblNordem_1.setText("N.Ordem: "+Pedidoselecion); //N.Ordem, do pedido selecionado 
		lblEntrada_1.setText("Entrada: "+Fachada.getEntradaPedido(Pedidoselecion)); //Entrada do pedido selecionado
		lblSaida_1.setText("Saida: "+Fachada.getSaidaPedido(Pedidoselecion)); //saida to pedido selecionado
		String p1 = Fachada.getPreoTotPedido(Pedidoselecion);
		String p2 = Fachada.getPreoExtPedido(Pedidoselecion);
		int v1 = 0;
		if (p1!=null) {
			v1 = Integer.parseInt(p1);
			if (p2!=null) {
				v1=v1+Integer.parseInt(p2);
			}
		}
		lblPreoTotal.setText("Pre�o Items: "+p1); //pre�o dos items , do pedido selecionado
		lblPreoExra.setText("Pre�o Extra: "+p2);//pre�o extra , do pedido
		lblPreoTotal_1.setText("Pre�o Total: "+v1);//pre�o dos items + extra
		lblLocal_1.setText("Local: "+Fachada.getLocalPedido(Pedidoselecion));//Local
		lblEstado_2.setText("Estado: "+Fachada.getEstadoPedido(Pedidoselecion));;//estado do pedido (Editando, Em espera, Em preparo, Pronto, Em entrega, Encerrado, Cancelado)
		
		AtualizarItems();
		panel_15.revalidate();
		panel_15.repaint();
	}
	
	private void AtualizarItems() {
		if (Pedidoselecion==null) {
			return;
		}
		panel_16.removeAll();
		ArrayList<String> refs = Fachada.getItemsDoPedido(Pedidoselecion);
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JButton btnNomeperfil = new JButton(Fachada.getQuantiRefei(Pedidoselecion,refs.get(i))+"x "+ refs.get(i));
			String truename = refs.get(i);
			btnNomeperfil.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						Fachada.removRefeiPedido(Pedidoselecion,truename);
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(frame, e1.getMessage());
					}
					atualizarPedidos();
				}
			});
			GridBagConstraints gbc_btnNomeperfil = new GridBagConstraints();
			gbc_btnNomeperfil.anchor = GridBagConstraints.WEST;
			gbc_btnNomeperfil.insets = new Insets(0, 0, 5, 0);
			gbc_btnNomeperfil.gridx = 0;
			gbc_btnNomeperfil.gridy = i;
			panel_16.add(btnNomeperfil, gbc_btnNomeperfil);
			i=i+1;
		}
		JButton btnNovoPerfil = new JButton("Novo Item");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Nome do Item:");
				if (n==null || n.isEmpty()) {
					return;
				}
				try {
					Fachada.addRefeiPedido(Pedidoselecion,n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				
				atualizarPedidos();
				
			}
		});
		GridBagConstraints gbc_btnNovoPerfil = new GridBagConstraints();
		gbc_btnNovoPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoPerfil.gridx = 0;
		gbc_btnNovoPerfil.gridy = i;
		panel_16.add(btnNovoPerfil, gbc_btnNovoPerfil);
		panel_16.revalidate();
		panel_16.repaint();
	}
	
	private void AtualizarCozinha() {
		panel_5.removeAll();
		ArrayList<String> refs = Fachada.getNOrdemPedidos();
		int a=0;
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			if (Fachada.getEstadoPedido(refs.get(i)).compareTo("editando")==0) {
				i=i+1;
				continue;
			}
			ArrayList<String> refs2 = Fachada.getItemsDoPedido(refs.get(i));
			int ii = 0;
			int uu = refs2.size()-1;
			while (ii<=uu) {	
				String trueid = refs2.get(ii);
				JPanel panel_6 = new JPanel();
				panel_6.setLayout(null);
				GridBagConstraints gbc_panel_6 = new GridBagConstraints();
				gbc_panel_6.fill = GridBagConstraints.BOTH;
				gbc_panel_6.insets = new Insets(0, 0, 5, 0);
				gbc_panel_6.gridx = 0;
				gbc_panel_6.gridy = a;
				a=a+1;
				panel_5.add(panel_6, gbc_panel_6);
				
				JLabel label_2 = new JLabel(Fachada.getQuantiRefei(refs.get(i),refs2.get(ii))+"x "+refs2.get(ii));//id da refei�ao
				label_2.setBounds(10, 4, 231, 14);
				panel_6.add(label_2);
				
				JLabel lblNordem_2 = new JLabel(refs.get(i));
				lblNordem_2.setBounds(262, 4, 65, 14);
				panel_6.add(lblNordem_2);
				
				JButton button_2 = new JButton("Pronto");
				button_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						try {
							Fachada.setEstadoRefeiPedido(lblNordem_2.getText(),trueid,"Pronto");
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(frame, e1.getMessage());
						}
						AtualizarCozinha();
						
					}
				});
				button_2.setBounds(564, 4, 89, 23);
				panel_6.add(button_2);
				
				JButton button_3 = new JButton("Em Preparo");
				button_3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						try {
							Fachada.setEstadoRefeiPedido(lblNordem_2.getText(),trueid,"Em Preparo");
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(frame, e1.getMessage());
						}
						AtualizarCozinha();
						
					}
				});
				button_3.setBounds(465, 4, 89, 23);
				panel_6.add(button_3);
				
				JPanel panel_4 = new JPanel();
				panel_4.setBackground(Color.PINK);
				panel_4.setBounds(337, 4, 118, 23);
				panel_6.add(panel_4);
				JLabel lblEstado_1 = new JLabel(Fachada.getEstadoRefei�ao(refs.get(i),refs2.get(ii)));
				panel_4.add(lblEstado_1);
				lblEstado_1.setBackground(Color.PINK);
				
				JLabel lblEntrada_2 = new JLabel(Fachada.getEntradaPedido(refs.get(i)));
				lblEntrada_2.setBounds(10, 30, 317, 14);
				panel_6.add(lblEntrada_2);
				
				JLabel lblSaida_2 = new JLabel("Saida:");
				lblSaida_2.setBounds(337, 30, 46, 14);
				panel_6.add(lblSaida_2);
				ii=ii+1;
			}
			i=i+1;
		}
		JButton btnNovoPerfil = new JButton("Novo Item");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Nome do Item:");
				try {
					Fachada.addRefeiPedido(Pedidoselecion,n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				
				atualizarPedidos();
				
			}
		});
		panel_5.revalidate();
		panel_5.repaint();
	}
	
	
	
	private void AtualizarLogin() {
		String r = "usuario";
		String rr = Fachada.getnomeusuarioatual();
		if (rr!=null) {
			r=rr;
		}
		lblBemVindoUsuario.setText("Bem vindo "+r);
	}
}
