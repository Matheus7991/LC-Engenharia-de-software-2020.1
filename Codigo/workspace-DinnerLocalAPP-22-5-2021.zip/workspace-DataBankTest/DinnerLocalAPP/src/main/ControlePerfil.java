package main;

import java.util.ArrayList;

public class ControlePerfil {
		//cadastrar
		//remover
		//atualizar
		//procurar
	private static ArrayList<Perfil> Perfis = new ArrayList<Perfil>();
	
	
	public static void cadastrarPerfil(String n) {
		if (procurarPerfil(n)!=null) {
			return;
		}
		Perfil P = new Perfil(n);
		Perfis.add(P);
	}
	
	public static void removerPerfil(String n) {
		Perfil r = procurarPerfil(n);
		if (r==null) {
			return;
		}
		Perfis.remove(r);
	}
	
	public static void atualizar() {
		
	}
	
	public static Perfil procurarPerfil(String n) {
		int u = Perfis.size()-1;
		int i = 0;
		while (i<=u) {
			Perfil o = Perfis.get(i);
			if (o.getName().compareTo(n)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}
	
	public static void modPermPerfil(String n,String perm,boolean value) {
		Perfil p = procurarPerfil(n);
		p.setPerm(perm, value);
	}
	
	public static ArrayList<Perfil> getPerfis() {
		return Perfis;
	}
	
	public static ArrayList<String> getPerfisNames() {
		ArrayList<String> r = new ArrayList<String>();
		int u = Perfis.size()-1;
		int i = 0;
		while (i<=u) {
			Perfil o = Perfis.get(i);
			r.add(o.getName());
			
			i=i+1;
		}
		return r ;
	}

	public static ArrayList<String> getPerfisPermNames() {
		ArrayList<String> r = new ArrayList<String>();
		if (Perfis.size()>0) {
			r = Perfis.get(0).getPermNames();
		}
		return r ;
	}

	public static boolean getPerfPerm(String n, String n2) {
		Perfil p = procurarPerfil(n);
		if (p==null) {
			return false;
		}
		
		return p.getPerm(n2);
	}

	public static void setPerfPerm(String n, String n2, boolean value) throws Exception {
		Perfil p = procurarPerfil(n);
		if (p==null) {
			throw new Exception("Perfil n�o existe");
		}
		p.setPerm(n2, value);
		
	}
}
