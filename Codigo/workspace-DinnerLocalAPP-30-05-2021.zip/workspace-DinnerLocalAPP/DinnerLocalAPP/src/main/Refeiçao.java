package main;

import java.util.ArrayList;

public class Refei�ao {
	private int id = 0;
	private String nome = "";
	private int custo;
	private ArrayList<String> Ingredientes;
	private ArrayList<Integer> QIngredientes;
	
	public Refei�ao(int nid,String nnome) {
		this.id = nid;
		this.nome = nnome;
		this.Ingredientes = new ArrayList<String>();
		this.QIngredientes = new ArrayList<Integer>();
	}
	
	public String procurarIngrediente(String n) {
		int u = Ingredientes.size()-1;
		int i = 0;
		while (i<=u) {
			String o = Ingredientes.get(i);
			if (o.compareTo(n)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String r) {
		nome = r;
	}
	public int getCusto() {
		return custo;
	}
	public void setCusto(int r) {
		custo = r;
	}

	public String getName() {
		return nome;
	}

	public int getNid() {
		return id;
	}
	
	public void eatItemPedido(Integer times) {
		int u = Ingredientes.size()-1;
		int i = 0;
		System.out.println("times: "+ times);
		while (i<=u) {
			System.out.println(Ingredientes.get(i));
			System.out.println(QIngredientes.get(i));
			ControleItemPedido.reduzir(Ingredientes.get(i),QIngredientes.get(i)*times);
			i=i+1;
		}
		
	}

	public ArrayList<String> getigreds() {
		ArrayList<String> r = new ArrayList<String>();
		int u = Ingredientes.size()-1;
		int i = 0;
		while (i<=u) {
			r.add(QIngredientes.get(i)+" "+ControleItemPedido.getSufix(Ingredientes.get(i))+" "+Ingredientes.get(i));
			i=i+1;
		}
		return r;
	}

	public void removigred(String n) {
		int y =n.indexOf(" ", n.indexOf(" ") + 1);
		n = n.substring(y+1);
		System.out.println(n);
		System.out.println(Ingredientes);
		String r = procurarIngrediente(n);
		if (r==null) {
			return;
		}
		QIngredientes.remove(Ingredientes.indexOf(r));
		Ingredientes.remove(r);
	}

	public void addigred(String n,int q) {
		String r = procurarIngrediente(n);
		if (r!=null) {
			return;
		}
		ItemPedido rr = ControleItemPedido.procurarItemPedido(n);
		if (rr==null) {
			return;
		}
		Ingredientes.add(n);
		QIngredientes.add(q);
		
	}
}
