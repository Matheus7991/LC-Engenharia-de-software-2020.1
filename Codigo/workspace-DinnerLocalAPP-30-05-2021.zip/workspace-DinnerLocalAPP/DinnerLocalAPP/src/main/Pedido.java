package main;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Pedido {
	private String nomeCliente = "";
	private String nOrdem;
	private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss dd/MM/yyyy ");  
	private LocalDateTime entrada = null;
	private LocalDateTime saida = null;
	private String local;
	private String estado; //Editando, Em espera , Em preparo , Pronto , Em entrega, entregue , Encerrado(pago) , Cancelado
	
	private ArrayList<Refei�ao> Refei�oes = new ArrayList<Refei�ao>();
	private ArrayList<String> EstadoRefei = new ArrayList<String>();
	private ArrayList<Integer> QuantiRefei = new ArrayList<Integer>();
	private ArrayList<LocalDateTime> SaidaRefei = new ArrayList<LocalDateTime>();
	private int preoExtra = 0;
	private boolean enviado = false;
	
	public Pedido(String nordem) {
		this.nOrdem = nordem;
		this.estado = "editando";
	}

	public String getNordem() {
		return nOrdem;
	}

	public String getCliente() {
		return nomeCliente;
	}

	public String getEntrada() {
		if (entrada==null) {
			return null;
		}
		return dtf.format(entrada);
	}

	public String getSaida() {
		if (saida==null) {
			return null;
		}
		return dtf.format(saida);
	}

	public void Encerrar() {
		saida = LocalDateTime.now();  
	}
	/* valores possiveis
	 * Editando
	 * em espera
	 * Pronto
	 * Em entrega
	 * encerrado (pago)
	 * Cancelado
	 */

	public String getPreoTotal() {
		int r = 0;
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			int oo = QuantiRefei.get(i);
			r = r+(o.getCusto()*oo);
			i=i+1;
		}
		return Integer.toString(r) ;
	}

	public String getPreoExtra() {
		return Integer.toString(preoExtra);
	}

	public String getLocal() {
		return local;
	}

	public String getEstado() {
		return estado;
	}

	public void setCliente(String v) {
		nomeCliente=v;
		
	}

	public void setPreoExt(String v) {
		try {
			preoExtra = Integer.parseInt(v);
		}catch(Exception e){
			
		}
		
	}

	public void setLocal(String v) {
		local =v;
		
	}

	public void enviar() {
		enviado = true;
		estado = "Em espera";
		
	}

	public ArrayList<String> getRefeiList(String nOrdem2) {
		ArrayList<String> r = new ArrayList<String>();
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			r.add(o.getName());
			
			i=i+1;
		}
		return r ;
	}
	
	public String getQuantiRefei(String refei) {
		Refei�ao r = procurarRefei(refei);
		if (r==null) {
			return null;
		}
		int oo=Refei�oes.indexOf(r);
		return Integer.toString(QuantiRefei.get(oo));
	}

	public void addRefei(String n) {
		Refei�ao R = ControleRefei�ao.procurarRefei�ao(n);
		if (R==null) {
			return;
		}
		Refei�ao Reif = procurarRefei(n);
		if (Reif==null) {
			Refei�oes.add(R);
			EstadoRefei.add("Em espera");
			QuantiRefei.add(1);
			SaidaRefei.add(null);
		}else {
			int oo = Refei�oes.indexOf(R);
			QuantiRefei.set(oo, QuantiRefei.get(oo)+1);
		}
	}

	private Refei�ao procurarRefei(String n) {
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			if (o.getName().compareTo(n)==0) {
				return o;
			}
			i=i+1;
		}
		return null;
	}

	public void removRefei(String text) {
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			if (o.getName().compareTo(text)==0) {
				int oo = Refei�oes.indexOf(o);
				if(QuantiRefei.get(oo)>1) {
					QuantiRefei.set(oo, QuantiRefei.get(oo)-1);
				}else {
					Refei�oes.remove(o);
					EstadoRefei.remove(oo);
					QuantiRefei.remove(oo);
					SaidaRefei.remove(oo);
				}
				return;
			}
			i=i+1;
		}
	}

	public String getEstadoRefei(String refei) {
		Refei�ao r = procurarRefei(refei);
		if (r==null) {
			return null;
		}
		int oo = Refei�oes.indexOf(r);
		return EstadoRefei.get(oo);
		
	}

	public void setEstadoRefei(String refei, String text) {
		Refei�ao r = procurarRefei(refei);
		if (r==null) {
			return;
		}
		int oo = Refei�oes.indexOf(r);
		boolean o = false;
		EstadoRefei.set(oo, text);
		
		if (text.compareTo("Pronto")==0) {
			o=true;
			Refei�oes.get(oo).eatItemPedido(QuantiRefei.get(oo));
			SaidaRefei.set(oo, LocalDateTime.now());
		}
		if (o) {
			int u = Refei�oes.size()-1;
			int i = 0;
			o=true;
			while (i<=u) {
				if (text.compareTo("Pronto")!=0) {
					o=false;
					break;
				}
				i=i+1;
			}
			if (o) {
				setEstado("Pronto");
			}
		}
	}
	
	public void setEstadoTRefei(String text) {
		int u = Refei�oes.size()-1;
		int i = 0;
		boolean o=false;
		while (i<=u) {
			EstadoRefei.set(i, text);
			if (text.compareTo("Pronto")==0) {
				o=true;
				SaidaRefei.set(i, LocalDateTime.now());
			}
			i=i+1;
		}
		if (o) {
			setEstado("Pronto");
		}
		//EstadoRefei.forEach(a->{System.out.println(a);a=text;System.out.println(a);});
	}

	public void setEstado(String string) {
		estado = string;
		if (string.compareTo("Em espera")==0) {
			this.entrada = LocalDateTime.now();  
		}else if(string.compareTo("Pronto")==0) {
			this.saida = LocalDateTime.now();  
		}
	}

	public String getSaidaRefeiPedido(String refei) {
		Refei�ao r = procurarRefei(refei);
		if (r==null) {
			return null;
		}
		int oo = Refei�oes.indexOf(r);
		if (SaidaRefei.get(oo)==null) {
			return null;
		}
		return dtf.format(SaidaRefei.get(oo));
	}

	public void eatItemPedido(String iDrefei) {
		Refei�ao r = procurarRefei(iDrefei);
		if (r==null) {
			return;
		}
		int o = Refei�oes.indexOf(r);
		System.out.println("clk4");
		r.eatItemPedido(QuantiRefei.get(o));
	}
}











