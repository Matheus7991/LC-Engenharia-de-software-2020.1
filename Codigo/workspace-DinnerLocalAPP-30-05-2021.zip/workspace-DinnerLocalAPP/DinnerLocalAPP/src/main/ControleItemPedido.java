package main;

import java.util.ArrayList;

public class ControleItemPedido {
	private static ArrayList<ItemPedido> ItemsPedidos = new ArrayList<ItemPedido>();
	//Cadastrar
	//Remover
	//Atualizar
	//Procurar
	//Relatorio (Custo total de todos os ItemsPedidos)
	
	//encerrar pedido (o cliente esta pagando)
	
	public static void cadastrarItemPedido(String Nome) {
		if (procurarItemPedido(Nome)!=null) {
			return;
		}
		ItemPedido P = new ItemPedido(Nome);
		ItemsPedidos.add(P);
	}
	
	public static void removerItemPedido(String Nordem) {
		ItemPedido r = procurarItemPedido(Nordem);
		if (r==null) {
			return;
		}
		ItemsPedidos.remove(r);
		
	}
	
	public static void atualizar() {
		
	}
	
	public static ItemPedido procurarItemPedido(String Nome) {
		if (Nome==null) {
			return null;
		}
		int u = ItemsPedidos.size()-1;
		int i = 0;
		while (i<=u) {
			ItemPedido o = ItemsPedidos.get(i);
			if (o.getNome().compareTo(Nome)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}
	public static void reduzir(String string, Integer integer) {
		ItemPedido p = procurarItemPedido(string);
		if (p==null) {
			return;
		}
		p.redQuanti(integer);
		
	}

	public static void setNome(String nome, String novonome) {
		ItemPedido p = procurarItemPedido(nome);
		if (p==null) {
			return;
		}
		p.setNome(novonome);
	}

	public static void setQuant(String nome, int novovalor) {
		ItemPedido p = procurarItemPedido(nome);
		if (p==null) {
			return;
		}
		p.setQuant(novovalor);
		
	}

	public static ArrayList<String> GetNames() {
		ArrayList<String> r = new ArrayList<String>();
		int u = ItemsPedidos.size()-1;
		int i = 0;
		while (i<=u) {
			r.add(ItemsPedidos.get(i).getNome());
			i=i+1;
		}
		return r;
	}

	public static int getQuantiItemPedido(String n) {
		ItemPedido p = procurarItemPedido(n);
		if (p==null) {
			return 0;
		}
		return p.getQuantidad();
		
	}

	public static String getSufix(String n) {
		ItemPedido p = procurarItemPedido(n);
		if (p==null) {
			return null;
		}
		return p.getsufix();
	}

	public static String getValid(String n) {
		ItemPedido p = procurarItemPedido(n);
		if (p==null) {
			return null;
		}
		return p.getvalid();
	}

	public static void setSufix(String n, String n2) {
		ItemPedido p = procurarItemPedido(n);
		if (p==null) {
			return;
		}
		p.setSufix(n2);
	}

	public static void setValid(String n, String v3, String v2, String v) {//dia , mes , ano
		ItemPedido p = procurarItemPedido(n);
		if (p==null) {
			return;
		}
		p.setvalid(v3,v2,v);
		
	}


}
