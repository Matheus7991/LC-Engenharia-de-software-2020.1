package main;

import java.util.ArrayList;

public class ControleRefei�ao {
	//cadastrar
	//remover
	//atualizar
	//procurar
	
	public static ArrayList<Refei�ao> Refei�oes = new ArrayList<Refei�ao>();
	
	public static void cadastrarRefei�ao(String nome) {
		if (procurarRefei�ao(nome)!=null) {
			return;
		}
		int i =0;
		while (procurarRefei�aoNid(Integer.toString(i))!=null) {
			i=i+1;
		}
		Refei�ao P = new Refei�ao(i, nome);
		Refei�oes.add(P);
	}

	public static void removerRefei�ao(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return;
		}
		Refei�oes.remove(r);
	}
	
	public static void atualizar() {
		
	}
	
	public static Refei�ao procurarRefei�ao(String n) {
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			if (o.getName().compareTo(n)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}
	
	private static Refei�ao procurarRefei�aoNid(String nid) {
		int inid = Integer.parseInt(nid);
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			if (o.getNid()==inid) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}

	public static ArrayList<Refei�ao> getRefei() {
		return Refei�oes;
	}

	public static void modPreco(String string, int i) {
		Refei�ao r = procurarRefei�aoNid(string);
		if (r==null) {
			return;
		}
		r.setCusto(i);
		
	}

	public static ArrayList<String> getIDs() {
		ArrayList<String> r = new ArrayList<String>();
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			r.add(Integer.toString(Refei�oes.get(i).getNid()));
			i=i+1;
		}
		return r;
	}

	public static ArrayList<String> getIgred(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return null;
		}
		return r.getigreds();
	}

	public static void removIgred(String ID, String n) {
		Refei�ao r = procurarRefei�aoNid(ID);
		if (r==null) {
			return;
		}
		r.removigred(n);
	}

	public static void addIgred(String n, String ingred,int q) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return;
		}
		r.addigred(ingred,q);
		
	}

	public static String getnome(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return null;
		}
		return r.getName();
	}

	public static int getpreco(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return 0;
		}
		return r.getCusto();
	}

	public static void setnome(String n, String n2) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return;
		}
		r.setNome(n2);
	}

	
}
