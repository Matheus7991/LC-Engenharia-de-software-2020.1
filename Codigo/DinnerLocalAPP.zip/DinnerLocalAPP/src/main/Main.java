package main;

import java.util.ArrayList;

public class Main {
	public static ArrayList<Account> Accounts = new ArrayList<Account>();
	public static Account UsuarioAtual = null;
	
	public static ArrayList<Refei�ao> Refei�oes = new ArrayList<Refei�ao>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Account gerente = new Account("00011122233", "1234");
		gerente.permModCardapio=true;
		Account Atendente = new Account("11122233344", "1234");
		Accounts.add(gerente);
		Accounts.add(Atendente);
		Refei�ao ref1 = new Refei�ao(1,"ref1","10.00 R$");
		Refei�ao ref2 = new Refei�ao(2,"ref2","20.00 R$");
		Refei�oes.add(ref1);
		Refei�oes.add(ref2);
		
		Mainwindow wind = new Mainwindow();
		wind.frame.setVisible(true);
		
	}

}
