package main;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class Mainwindow {

	private Container Ocardapio = null;
	public JFrame frame;
	private JTextField txtCpf;
	private JPasswordField pwdSenha;
	private JTextField txtNome;
	private JTextField txtPreo;

	/**
	 * Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mainwindow window = new Mainwindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	 */
	/**
	 * Create the application.
	 */
	public Mainwindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 701, 477);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		frame.getContentPane().add(tabbedPane, BorderLayout.CENTER);
		
		JPanel LoginPanel = new JPanel();
		tabbedPane.addTab("Login", null, LoginPanel, null);
		LoginPanel.setLayout(null);
		
		JLabel lblBemVindoUsuario = new JLabel("Bem vindo usuario");
		lblBemVindoUsuario.setBounds(10, 11, 460, 14);
		LoginPanel.add(lblBemVindoUsuario);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fachada.login(txtCpf.getText(),String.valueOf(pwdSenha.getPassword()));
			}
		});
		btnLogin.setBounds(10, 360, 89, 23);
		LoginPanel.add(btnLogin);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setBounds(10, 335, 46, 14);
		LoginPanel.add(lblSenha);
		
		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setBounds(10, 310, 46, 14);
		LoginPanel.add(lblCpf);
		
		txtCpf = new JTextField();
		txtCpf.setText("CPF");
		txtCpf.setBounds(55, 304, 86, 20);
		LoginPanel.add(txtCpf);
		txtCpf.setColumns(10);
		
		pwdSenha = new JPasswordField();
		pwdSenha.setText("Senha");
		pwdSenha.setBounds(55, 329, 86, 20);
		LoginPanel.add(pwdSenha);
		
		JPanel CardapioPanel = new JPanel();
		tabbedPane.addTab("Cardapio", null, CardapioPanel, null);
		CardapioPanel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 665, 344);
		CardapioPanel.add(scrollPane);
		
		Ocardapio = new JPanel();
		scrollPane.setColumnHeaderView(Ocardapio);
		GridBagLayout gbl_Ocardapio = new GridBagLayout();
		gbl_Ocardapio.columnWidths = new int[]{663, 0};
		gbl_Ocardapio.rowHeights = new int[] {30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30};
		gbl_Ocardapio.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_Ocardapio.rowWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		Ocardapio.setLayout(gbl_Ocardapio);
		//##############################################################################
		/*
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.insets = new Insets(0, 0, 5, 0);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 0;
		Ocardapio.add(panel_1, gbc_panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(0, 0, 46, 14);
		panel_1.add(lblNome);
		
		JButton btnAdicionar = new JButton("Adicionar");
		btnAdicionar.setBounds(546, 0, 89, 23);
		panel_1.add(btnAdicionar);
		
		JButton btnModificar = new JButton("Modificar");
		btnModificar.setBounds(448, 0, 89, 23);
		panel_1.add(btnModificar);
		
		JLabel lblPreo = new JLabel("Pre\u00E7o");
		lblPreo.setBounds(334, 0, 46, 14);
		panel_1.add(lblPreo);
		*/
		//##############################################################################
		
		
		JButton btnNovoItem = new JButton("Novo Item");
		btnNovoItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.addRefei(txtNome.getText(), txtPreo.getText());
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
					//e1.printStackTrace();
				}
				AtualizarCardapio();
			}
		});
		btnNovoItem.setBounds(10, 392, 99, 23);
		CardapioPanel.add(btnNovoItem);
		
		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AtualizarCardapio();
			}
		});
		btnAtualizar.setBounds(596, 366, 89, 23);
		CardapioPanel.add(btnAtualizar);
		
		JLabel lblNome_1 = new JLabel("Nome");
		lblNome_1.setBounds(10, 366, 46, 14);
		CardapioPanel.add(lblNome_1);
		
		txtNome = new JTextField();
		txtNome.setText("Nome");
		txtNome.setBounds(66, 366, 259, 20);
		CardapioPanel.add(txtNome);
		txtNome.setColumns(10);
		
		txtPreo = new JTextField();
		txtPreo.setText("Pre\u00E7o");
		txtPreo.setBounds(391, 366, 86, 20);
		CardapioPanel.add(txtPreo);
		txtPreo.setColumns(10);
		
		JLabel lblPreo_1 = new JLabel("Pre\u00E7o");
		lblPreo_1.setBounds(335, 366, 46, 14);
		CardapioPanel.add(lblPreo_1);
		
		JButton btnRemover = new JButton("Remover");
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Fachada.removRefei(txtNome.getText());
				} catch (IOException e) {
					JOptionPane.showMessageDialog(frame, e.getMessage());
					//e.printStackTrace();
				}
				AtualizarCardapio();
			}
		});
		btnRemover.setBounds(119, 392, 89, 23);
		CardapioPanel.add(btnRemover);
	}
	
	private void AtualizarCardapio() {
		Ocardapio.removeAll();
		ArrayList<Refei�ao> refs = Fachada.getRefei();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JPanel panel_1 = new JPanel();
			GridBagConstraints gbc_panel_1 = new GridBagConstraints();
			gbc_panel_1.insets = new Insets(0, 0, 5, 0);
			gbc_panel_1.fill = GridBagConstraints.BOTH;
			gbc_panel_1.gridx = 0;
			gbc_panel_1.gridy = i; //+1
			Ocardapio.add(panel_1, gbc_panel_1);
			panel_1.setLayout(null);
			
			JLabel lblNome = new JLabel(refs.get(i).getNome());
			lblNome.setBounds(0, 0, 46, 14);
			panel_1.add(lblNome);
			
			JButton btnAdicionar = new JButton("Adicionar");
			btnAdicionar.setBounds(546, 0, 89, 23);
			panel_1.add(btnAdicionar);
			
			JButton btnModificar = new JButton("Modificar");
			btnModificar.setBounds(448, 0, 89, 23);
			panel_1.add(btnModificar);
			
			JLabel lblPreo = new JLabel(refs.get(i).getCusto());
			lblPreo.setBounds(334, 0, 86, 14);
			panel_1.add(lblPreo);
			i=i+1;
		}
		Ocardapio.revalidate();
		Ocardapio.repaint();
	}
}
