package main;

public class Account {
	private String CPF = "00011122233";
	private String senh = "1234";
	private String nome = "";
	private boolean permModContas = false;
	public boolean permModCardapio = false;
	
	public Account(String nCPF,String nSenha) {
		this.CPF = nCPF;
		this.senh = nSenha;
	}
	
	public String getCPF() {
		return CPF;
	}
	public void setCPF(String r) {
		CPF = r;
	}
	public String getSenh() {
		return senh;
	}
	public void setSenh(String r) {
		senh = r;
	}
	public String getName() {
		return nome;
	}
	public void setName(String r) {
		nome = r;
	}
	
}
