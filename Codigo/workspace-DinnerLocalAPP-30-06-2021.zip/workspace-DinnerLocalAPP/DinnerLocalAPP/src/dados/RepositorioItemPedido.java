package dados;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RepositorioItemPedido extends Conexao {
	public void cadastarItemPedido(String nome) throws SQLException {
		String cmd = "INSERT INTO `new_testschema`.`itempedido` (`NomeItemPedido`) VALUES ('"+nome+"');";
		Execute(cmd);
	}

	public void removerItemPedido(String nome) throws SQLException {
		String cmd = "DELETE FROM `new_testschema`.`itempedido` WHERE (`NomeItemPedido` = '"+nome+"');\r\n" + 
				"";
		Execute(cmd);
		
	}

	public ArrayList<ArrayList<String>> getUpdate() throws SQLException {
		ResultSet results = Query("SELECT * FROM new_testschema.itempedido;");
		ArrayList<ArrayList<String>> r = new ArrayList<ArrayList<String>>();
		while (results.next()) {
			ArrayList<String> rr = new ArrayList<String>();
			rr.add(results.getString("NomeItemPedido"));
			rr.add(results.getString("Quantidade"));
			rr.add(results.getString("QSufix"));
			rr.add(results.getString("Validade"));
			r.add(rr);
		}
		return r;
	}

	public void updateatribute(String NomeItemPedido, String nomeatribut, String novovalor) throws SQLException {
		String cmd = "UPDATE `new_testschema`.`itempedido` SET `"+nomeatribut+"` = '"+novovalor+"' WHERE (`NomeItemPedido` = '"+NomeItemPedido+"');";
		Execute(cmd);
	}
	
}
