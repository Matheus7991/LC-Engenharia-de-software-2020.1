package dados;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RepositorioRefei�ao extends Conexao {
	public void createtable() throws SQLException {//execute if table doesnt exists
		String createtable =
						"";
		Execute(createtable);
	}

	public void cadastrarRefei�ao(String nome) throws SQLException {
		String cmd = "INSERT INTO `new_testschema`.`refei�ao` (`NomeRefei�ao`) VALUES ('"+nome+"');";
		Execute(cmd);
		
	}

	public void removerRefei�ao(String n) throws SQLException {
		String cmd = "DELETE FROM `new_testschema`.`refei�ao` WHERE (`NomeRefei�ao` = '"+n+"');";
		Execute(cmd);
		
	}

	public ArrayList<ArrayList<String>> getUpdateRefei�ao() throws SQLException {
		ResultSet results = Query("SELECT * FROM new_testschema.refei�ao;");
		ArrayList<ArrayList<String>> r = new ArrayList<ArrayList<String>>();
		while (results.next()) {
			ArrayList<String> rr = new ArrayList<String>();
			rr.add(results.getString("NomeRefei�ao"));
			rr.add(results.getString("custo"));
			//rr.add(results.getString("igredientes"));
			//rr.add(results.getString("Qigredientes"));
			rr.add(results.getString("idRefei�ao"));
			r.add(rr);
		}
		return r;
	}
	
	public ArrayList<ArrayList<String>> getUpdateItempedidoRefei�ao() throws SQLException {
		ResultSet results = Query("SELECT * FROM new_testschema.itempedidorefei�ao;");
		ArrayList<ArrayList<String>> r = new ArrayList<ArrayList<String>>();
		while (results.next()) {
			ArrayList<String> rr = new ArrayList<String>();
			rr.add(results.getString("NomeItemPedido"));
			rr.add(results.getString("idrefei�ao"));
			rr.add(results.getString("Quantidade"));
			r.add(rr);
		}
		return r;
	}
	
	
	public void updateatributeRefei�ao(String id, String nomeatribut, String novovalor) throws SQLException {
		String cmd = "UPDATE `new_testschema`.`refei�ao` SET `"+nomeatribut+"` = '"+novovalor+"' WHERE (`idRefei�ao` = '"+id+"');";
		Execute(cmd);
	}
	public void cadastrarItempedidoRefei�ao(String idRefei�ao,String NomeItemPedido, String Quant) throws SQLException {
		String cmd3 = "INSERT INTO `new_testschema`.`itempedidorefei�ao` (`NomeItemPedido`, `idrefei�ao`, `Quantidade`) VALUES ('"+NomeItemPedido+"', '"+idRefei�ao+"', '"+Quant+"');";
		Execute(cmd3);
	}
	public void removerItempedidoRefei�ao(String idRefei�ao,String NomeItemPedido, String Quant) throws SQLException {
		String cmd3 = "DELETE FROM `new_testschema`.`itempedidorefei�ao` WHERE (`NomeItemPedido`='"+NomeItemPedido+"') AND (`idrefei�ao`='"+idRefei�ao+"') AND (`Quantidade`='"+Quant+"');";
		Execute(cmd3);
	}
	
	public void updateItempedidoRefei�ao(String idRefei�ao,String NomeItemPedido, String Quant) throws SQLException {
		String cmd = "UPDATE `new_testschema`.`itempedidorefei�ao` SET `Quantidade` = '"+Quant+"' WHERE (`idRefei�ao` = '"+idRefei�ao+"') AND (`nomeitempedido` = '"+NomeItemPedido+"');";
		Execute(cmd);
	}

}
