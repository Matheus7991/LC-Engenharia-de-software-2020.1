package dados;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Conexao {
	static String driver = "com.mysql.cj.jdbc.Driver";  //com.mysql.jdbc.Driver is deprecated
	static String url = "jdbc:mysql://localhost:3306/new_testschema";
	static String user = "root";
	static String pass = "Root1337";
	
	static Connection con = null;
	
	public static void StartConnection() throws ClassNotFoundException, SQLException {
		Class.forName(driver);
		
		con = DriverManager.getConnection(url, user, pass);
	}
	
	public static void EndConnection() throws SQLException {
		con.close();
	}
	
	public ResultSet Query(String Q) throws SQLException {
		
		PreparedStatement stmt = con.prepareStatement(Q);
		ResultSet rs = stmt.executeQuery();
		
		return rs;
	}
	
	public void Execute(String Q) throws SQLException {
		PreparedStatement stmt = con.prepareStatement(Q);
		stmt.executeUpdate();
	}
	
	
}
