package dados;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RepositorioPedido extends Conexao {
	public void cadastrarPedido(String n,String entrada) throws SQLException {
		String cmd = "INSERT INTO `new_testschema`.`pedido` (`nOrdem`,'Entrada') VALUES ('"+n+"','"+entrada+"');";
		Execute(cmd);
	}

	public void removerPedido(String n) throws SQLException {
		String cmd = "DELETE FROM `new_testschema`.`pedido` WHERE (`nOrdem` = '"+n+"');";
		Execute(cmd);
	}

	public ArrayList<ArrayList<String>> getUpdatePedido() throws SQLException {
		
		ResultSet results = Query("SELECT * FROM new_testschema.pedido;");
		ArrayList<ArrayList<String>> r = new ArrayList<ArrayList<String>>();
		while (results.next()) {
			ArrayList<String> rr = new ArrayList<String>();
			rr.add(results.getString("nOrdem"));
			rr.add(results.getString("NomeCliente"));
			rr.add(results.getString("Entrada"));
			rr.add(results.getString("Saida"));
			rr.add(results.getString("local"));
			rr.add(results.getString("estado"));
			r.add(rr);
		}
		return r;
	}
	
	public ArrayList<ArrayList<String>> getUpdateRefei�aoPedido() throws SQLException {
		
		ResultSet results = Query("SELECT * FROM new_testschema.pedido;");
		ArrayList<ArrayList<String>> r = new ArrayList<ArrayList<String>>();
		while (results.next()) {
			ArrayList<String> rr = new ArrayList<String>();
			rr.add(results.getString("nomerefei�ao"));
			rr.add(results.getString("idpedido"));
			rr.add(results.getString("estadorefei�ao"));
			rr.add(results.getString("quantirefei�ao"));
			rr.add(results.getString("saidarefei�ao"));
			r.add(rr);
		}
		return r;
	}

	public void updatePedido(String id, String nomeatribut, String novovalor) throws SQLException {
		String cmd = "UPDATE `new_testschema`.`pedido` SET `"+nomeatribut+"` = '"+novovalor+"' WHERE (`nOrdem` = '"+id+"');";
		Execute(cmd);
	}
	
	public void cadastrarRefei�aoPedido(String nomerefei�ao,String idPedido) throws SQLException {
		String cmd3 = "INSERT INTO `new_testschema`.`itempedidorefei�ao` (`idrefei�ao`, `idPedido`) VALUES ('"+nomerefei�ao+"', '"+idPedido+"');";
		Execute(cmd3);
	}
	
	public void removerRefei�aoPedido(String nomerefei�ao,String idPedido) throws SQLException {
		String cmd3 = "DELETE FROM `new_testschema`.`itempedidorefei�ao` WHERE (`idrefei�ao`='"+nomerefei�ao+"') AND (`idPedido`='"+idPedido+"');";
		Execute(cmd3);
	}
	
	public void updateRefei�aoPedido(String nomerefei�ao,String idPedido, String nomeatribut,String novovalor) throws SQLException {
		String cmd = "UPDATE `new_testschema`.`itempedidorefei�ao` SET '"+nomeatribut+"' = '"+novovalor+"' WHERE (`idRefei�ao` = '"+nomerefei�ao+"') AND (`idPedido` = '"+idPedido+"');";
		Execute(cmd);
	}
	public void updateRefei�aoPedidoTodos(String idPedido, String nomeatribut,String novovalor) throws SQLException {
		String cmd = "UPDATE `new_testschema`.`itempedidorefei�ao` SET '"+nomeatribut+"' = '"+novovalor+"' WHERE (`idPedido` = '"+idPedido+"');";
		Execute(cmd);
	}
	
}
