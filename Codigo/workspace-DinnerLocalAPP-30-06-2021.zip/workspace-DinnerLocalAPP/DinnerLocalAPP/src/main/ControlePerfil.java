package main;

import java.sql.SQLException; 
import dados.RepositorioPerfil;

import java.util.ArrayList;

public class ControlePerfil {
		//cadastrar
		//remover
		//atualizar
		//procurar
	
	private RepositorioPerfil Repo = new RepositorioPerfil();
	private boolean ModRepo = false;
	
	private ArrayList<Perfil> Perfis = new ArrayList<Perfil>();
	
	private Fachada AFachada;
	public ControlePerfil(Fachada fachada) {
		AFachada = fachada;
	}

	public void cadastrarPerfil(String n) {
		n=n.toLowerCase();
		if (procurarPerfil(n)!=null) {
			return;
		}
		Perfil P = new Perfil(n);
		Perfis.add(P);
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.cadastrarPerfil(n);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void removerPerfil(String n) {
		n=n.toLowerCase();
		Perfil r = procurarPerfil(n);
		if (r!=null) {
			Perfis.remove(r);
		}
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.removerPerfil(n);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	public void atualizar() throws SQLException {
		ModRepo=false;
		
		ArrayList<ArrayList<String>> received = Repo.getUpdate();
		Perfis.clear();
		
		int i = 0;
		int u = received.size()-1;
		while (i<=u) {
			String n = received.get(i).get(0);
			cadastrarPerfil(n);
			modPermPerfil(n, "ModPerfil", Boolean.parseBoolean(received.get(i).get(1)));
			modPermPerfil(n, "ModCardapio", Boolean.parseBoolean(received.get(i).get(2)));
			modPermPerfil(n, "ModPedidos", Boolean.parseBoolean(received.get(i).get(3)));
			modPermPerfil(n, "ModCozinha", Boolean.parseBoolean(received.get(i).get(4)));
			modPermPerfil(n, "ModItemPedidos", Boolean.parseBoolean(received.get(i).get(5)));
			modPermPerfil(n, "ModArquivo", Boolean.parseBoolean(received.get(i).get(6)));
			i=i+1;
		}
		ModRepo=true;
		
	}
	
	public Perfil procurarPerfil(String n) {
		n=n.toLowerCase();
		int u = Perfis.size()-1;
		int i = 0;
		while (i<=u) {
			Perfil o = Perfis.get(i);
			if (o.getName().compareTo(n)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}
	
	public void modPermPerfil(String n,String perm,boolean value) {
		Perfil p = procurarPerfil(n);
		p.setPerm(perm, value);
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.modPermPerfil(n,perm,value);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList<Perfil> getPerfis() {
		return Perfis;
	}
	
	public ArrayList<String> getPerfisNames() {
		ArrayList<String> r = new ArrayList<String>();
		int u = Perfis.size()-1;
		int i = 0;
		while (i<=u) {
			Perfil o = Perfis.get(i);
			r.add(o.getName());
			
			i=i+1;
		}
		return r ;
	}

	public ArrayList<String> getPerfisPermNames() {
		ArrayList<String> r = new ArrayList<String>();
		if (Perfis.size()>0) {
			r = Perfis.get(0).getPermNames();
		}
		return r ;
	}

	public boolean getPerfPerm(String n, String n2) {
		Perfil p = procurarPerfil(n);
		if (p==null) {
			return false;
		}
		
		return p.getPerm(n2);
	}

	public void setPerfPerm(String n, String n2, boolean value) throws Exception {
		Perfil p = procurarPerfil(n);
		if (p==null) {
			throw new Exception("Perfil n�o existe");
		}
		p.setPerm(n2, value);
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.modPermPerfil(n,n2,value);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
