package main;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ItemPedido {
	private String Nome="";
	private int Quantidad=0;
	private String Qsufix="";
	private LocalDateTime validade;
	private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss dd/MM/yyyy ");  
	
	public ItemPedido(String nome) {
		this.Nome = nome;
		// TODO Auto-generated constructor stub
	}

	public String getNome() {
		return Nome;
	}

	public void redQuanti(Integer integer) {
		Quantidad = Quantidad-integer;
		
	}

	public void setNome(String novonome) {
		this.Nome=novonome;
		
	}

	public void setQuant(int novovalor) {
		Quantidad = novovalor;
		
	}

	public int getQuantidad() {
		return Quantidad;
	}

	public String getsufix() {
		return Qsufix;
	}

	public String getvalid() {
		if (validade==null) {
			return null;
		}
		return dtf.format(validade);
	}

	public void setSufix(String n2) {
		Qsufix = n2;
		
	}

	public void setvalid(String v3, String v2, String v) { //dia , mes , ano
		validade = LocalDateTime.of(Integer.parseInt(v), Integer.parseInt(v2), Integer.parseInt(v3), 0, 0);
		
	}

}
