package main;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import dados.RepositorioAccount;

public class ControleAccount {
	
	public Account UsuarioAtual = null;
	
	private ArrayList<Account> Contas = new ArrayList<Account>();
	
	private RepositorioAccount Repo = new RepositorioAccount();
	private boolean ModRepo=false;
	private Fachada AFachada;

	public ControleAccount(Fachada fachada) {
		AFachada = fachada;
	}



	public ArrayList<Account> getContas() {
		return Contas;
	}
	
	
	
	public void cadastrarAccount(String CPF,String senha) {
		if (procurarAccount(CPF)!=null) {
			return;
		}
		Account P = new Account(CPF, senha,AFachada.getControlePerfil());
		Contas.add(P);
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.cadastarAccount(CPF,senha);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void removerAccount(String CPF) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		Contas.remove(r);
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.removerAccount(CPF);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void atualizar() throws SQLException {
		ModRepo=false;
		ArrayList<ArrayList<String>> received = Repo.getUpdate();
		Contas.clear();
		
		int i = 0;
		int u = received.size()-1;
		while (i<=u) {
			ArrayList<String> n = received.get(i);
			cadastrarAccount(n.get(0),n.get(1));
			setNome(n.get(0), n.get(2));
			setSalario(n.get(0), Integer.parseInt(n.get(3)));
			try {
				setPerfil(n.get(0), n.get(4));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			i=i+1;
		}
		ModRepo=true;
	}
	
	public Account procurarAccount(String CPF) {
		if (CPF==null) {
			return null;
		}
		int u = Contas.size()-1;
		int i = 0;
		while (i<=u) {
			Account o = Contas.get(i);
			if (o.getCPF().compareTo(CPF)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}
	
	public Account procurarAccountPorNome(String Nome) {
		int u = Contas.size()-1;
		int i = 0;
		while (i<=u) {
			Account o = Contas.get(i);
			if (o.getName().compareTo(Nome)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}


	public ArrayList<String> getContaNames() {
		ArrayList<String> r = new ArrayList<String>();
		int u = Contas.size()-1;
		int i = 0;
		while (i<=u) {
			Account o = Contas.get(i);
			r.add(o.getName());
			
			i=i+1;
		}
		return r ;
	}


	public void setNome(String CPF, String Nome) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		r.setName(Nome);
		
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.updateatribute(CPF, "NomeConta", Nome);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void setPerfil(String CPF, String nome) throws Exception {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		r.setPerfil(nome);
		if (ModRepo==false) {
			return;
		}
		Repo.updateatribute(CPF, "Perfil", nome);
	}


	public Account login(String CPF, String senh) {
		int i = Contas.size()-1;
		Account u = null;
		while (i>=0) {
			if (Contas.get(i).getCPF().compareTo(CPF)==0) {
				u = Contas.get(i);
				break;
			}
			i=i-1;
		}
		if (u!=null) {
			if (u.getSenh().compareTo(senh)==0) {
				UsuarioAtual = u;
				return u;
			}
		}
		return null;
		
	}


	public void setCPF(String CPF, String v) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		r.setCPF(v);
		
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.updateatribute(CPF, "CPF", v);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void setSalario(String CPF, int v) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		r.setSalario(v);
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.updateatribute(CPF, "Salario", Integer.toString(v) );
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public void setSenha(String CPF, String v) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return;
		}
		r.setSenh(v);
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.updateatribute(CPF, "Senha", v);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public String getSenha(String CPF) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return null;
		}
		return r.getSenh();
		
	}


	public String getContaName(String CPF) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return null;
		}
		return r.getName();
	}


	public String getPerfil(String CPF) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return null;
		}
		return r.getPerfil().getName();
	}


	public String getSalario(String CPF) {
		Account r = procurarAccount(CPF);
		if (r==null) {
			return null;
		}
		return Integer.toString(r.getSalario());
	}


	public String getCPFConta(String Nome) {
		int u = Contas.size()-1;
		int i = 0;
		while (i<=u) {
			Account o = Contas.get(i);
			if (o.getName().compareTo(Nome)==0) {
				return o.getCPF();
			}
			
			i=i+1;
		}
		return null;
	}
	
	public void getAccess(String type) throws IOException {
		//System.out.println(UsuarioAtual);
		//System.out.println(UsuarioAtual.getPerfil()==null);
		//System.out.println(UsuarioAtual.getPerfil().getPerm(type));
		if ((UsuarioAtual==null) || UsuarioAtual.getPerfil()==null || (UsuarioAtual.getPerfil().getPerm(type)==false)) {
			throw new IOException("Acesso negado");
		}
	}



	public String getNomeAtual() {
		if (UsuarioAtual==null) {
			return "Usuario";
		}
		return UsuarioAtual.getName();
	}



	public void logoff() {
		UsuarioAtual=null;
		
	}
}
