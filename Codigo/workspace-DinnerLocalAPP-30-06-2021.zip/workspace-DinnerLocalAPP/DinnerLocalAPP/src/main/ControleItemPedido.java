package main;

import java.sql.SQLException;
import java.util.ArrayList;

import dados.RepositorioItemPedido;

public class ControleItemPedido {
	private ArrayList<ItemPedido> ItemsPedidos = new ArrayList<ItemPedido>();
	private Fachada AFachada;
	
	private RepositorioItemPedido Repo = new RepositorioItemPedido();
	private boolean ModRepo=false;
	//Cadastrar
	//Remover
	//Atualizar
	//Procurar
	//Relatorio (Custo total de todos os ItemsPedidos)
	
	//encerrar pedido (o cliente esta pagando)
	
	public ControleItemPedido(Fachada fachada) {
		AFachada = fachada;
	}

	public void cadastrarItemPedido(String Nome) {
		if (procurarItemPedido(Nome)!=null) {
			return;
		}
		ItemPedido P = new ItemPedido(Nome);
		ItemsPedidos.add(P);
		if (ModRepo==true) {
			try {
				Repo.cadastarItemPedido(Nome);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void removerItemPedido(String Nome) {
		ItemPedido r = procurarItemPedido(Nome);
		if (r==null) {
			return;
		}
		
		ItemsPedidos.remove(r);
		if (ModRepo==true) {
			try {
				Repo.removerItemPedido(Nome);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void atualizar() throws SQLException {
		ModRepo=false;
		ArrayList<ArrayList<String>> received = Repo.getUpdate();
		ItemsPedidos.clear();
		
		int i = 0;
		int u = received.size()-1;
		while (i<=u) {
			ArrayList<String> n = received.get(i);
			cadastrarItemPedido(n.get(0));
			if (n.get(1)==null) {
				n.set(1, "0");
			}
			setQuant(n.get(0), Integer.parseInt(n.get(1)));
			setSufix(n.get(0),n.get(2));
			String datetimeget = n.get(3);//2022-02-01 00:00:00
			System.out.println(datetimeget);
			if (datetimeget!=null && datetimeget.isEmpty()==false) {
			int index = datetimeget.indexOf("-");
				String year = datetimeget.substring(0, index);
				System.out.println(year);
				datetimeget = datetimeget.substring(index+1);
				index = datetimeget.indexOf("-");
				String month = datetimeget.substring(0, index);
				System.out.println(month);
				datetimeget = datetimeget.substring(index+1);
				index = datetimeget.indexOf(" ");
				String day = datetimeget.substring(0, index);
				System.out.println(day);
				datetimeget = datetimeget.substring(index+1);
				setValid(n.get(0),day,month,year);
			}else {
				setValid(n.get(0),"1","1","1");
			}
			i=i+1;
		}
		ModRepo=true;
		
	}
	
	public ItemPedido procurarItemPedido(String Nome) {
		if (Nome==null) {
			return null;
		}
		int u = ItemsPedidos.size()-1;
		int i = 0;
		while (i<=u) {
			ItemPedido o = ItemsPedidos.get(i);
			if (o.getNome().compareTo(Nome)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}
	public void reduzir(String string, Integer integer) {
		ItemPedido p = procurarItemPedido(string);
		if (p==null) {
			return;
		}
		p.redQuanti(integer);
		if (ModRepo==true) {
			try {
				Repo.updateatribute(string, "Quantidade", Integer.toString(p.getQuantidad()));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void setNome(String nome, String novonome) {
		ItemPedido p = procurarItemPedido(nome);
		if (p==null) {
			return;
		}
		p.setNome(novonome);
		if (ModRepo==true) {
			try {
				Repo.updateatribute(nome, "NomeItemPedido", novonome);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void setQuant(String nome, int novovalor) {
		ItemPedido p = procurarItemPedido(nome);
		if (p==null) {
			return;
		}
		p.setQuant(novovalor);
		if (ModRepo==true) {
			try {
				Repo.updateatribute(nome, "Quantidade", Integer.toString(novovalor));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public ArrayList<String> GetNames() {
		ArrayList<String> r = new ArrayList<String>();
		int u = ItemsPedidos.size()-1;
		int i = 0;
		while (i<=u) {
			r.add(ItemsPedidos.get(i).getNome());
			i=i+1;
		}
		return r;
	}

	public int getQuantiItemPedido(String n) {
		ItemPedido p = procurarItemPedido(n);
		if (p==null) {
			return 0;
		}
		return p.getQuantidad();
		
	}

	public String getSufix(String n) {
		ItemPedido p = procurarItemPedido(n);
		if (p==null) {
			return null;
		}
		return p.getsufix();
	}

	public String getValid(String n) {
		ItemPedido p = procurarItemPedido(n);
		if (p==null) {
			return null;
		}
		return p.getvalid();
	}

	public void setSufix(String n, String n2) {
		ItemPedido p = procurarItemPedido(n);
		if (p==null) {
			return;
		}
		p.setSufix(n2);
		if (ModRepo==true) {
			try {
				Repo.updateatribute(n, "QSufix", n2);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void setValid(String n, String v3, String v2, String v) {//dia , mes , ano
		ItemPedido p = procurarItemPedido(n);
		if (p==null) {
			return;
		}
		p.setvalid(v3,v2,v);
		if (ModRepo==true) {
			try { //2022-02-01 00:00:00
				Repo.updateatribute(n, "Validade", v+"-"+v2+"-"+v3);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}


}
