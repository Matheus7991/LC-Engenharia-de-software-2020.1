package main;

import java.util.ArrayList;

public class Utility {
	static ArrayList<String> stringtodate(String datetimeget) {
		ArrayList<String> ret = new ArrayList<String>();
		if (datetimeget!=null && datetimeget.isEmpty()==false) {
		int index = datetimeget.indexOf("-");
			String year = datetimeget.substring(0, index);
			System.out.println(year);
			datetimeget = datetimeget.substring(index+1);
			index = datetimeget.indexOf("-");
			String month = datetimeget.substring(0, index);
			System.out.println(month);
			datetimeget = datetimeget.substring(index+1);
			index = datetimeget.indexOf(" ");
			String day = datetimeget.substring(0, index);
			System.out.println(day);
			datetimeget = datetimeget.substring(index+1);
			ret.add(day);
			ret.add(month);
			ret.add(year);
		}else {
			ret.add("1");
			ret.add("1");
			ret.add("1");
		}
		return ret;
	}
}
