package main;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import dados.RepositorioPedido;
import dados.RepositorioRefei�ao;

public class ControlePedido {
	
	private ArrayList<Pedido> Pedidos = new ArrayList<Pedido>();
	private RepositorioPedido Repo = new RepositorioPedido();
	private boolean ModRepo = false;
	private Fachada AFachada;
	//Cadastrar
	//Remover
	//Atualizar
	//Procurar
	//Relatorio (Custo total de todos os pedidos)
	
	//encerrar pedido (o cliente esta pagando)
	
	public ControlePedido(Fachada eFachada) {
		AFachada = eFachada;
	}

	public void cadastrarPedido(String Nordem) throws IOException {
		AFachada.getAccess("ModPedidos");
		if (procurarPedido(Nordem)!=null) {
			return;
		}
		Pedido P = new Pedido(Nordem, AFachada);
		Pedidos.add(P);
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.cadastrarPedido(Nordem, P.getSaida());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void removerPedido(String Nordem) throws IOException {
		AFachada.getAccess("ModPedidos");
		Pedido r = procurarPedido(Nordem);
		if (r==null) {
			return;
		}
		Pedidos.remove(r);
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.removerPedido(Nordem);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void atualizar() throws IOException, SQLException {
		ModRepo=false;
		ArrayList<ArrayList<String>> received = Repo.getUpdatePedido();
		Pedidos.clear();
		
		int i = 0;
		int u = received.size()-1;
		while (i<=u) {
			String n = received.get(i).get(0);
			cadastrarPedido(n);
			setClientePedido(n, received.get(i).get(1));
			ArrayList<String> datetimeget = Utility.stringtodate(received.get(i).get(2));
			setentrada(n,datetimeget.get(0),datetimeget.get(1),datetimeget.get(2));
			datetimeget = Utility.stringtodate(received.get(i).get(3));
			setsaida(n,datetimeget.get(0),datetimeget.get(1),datetimeget.get(2));
			setLocalPedido(n, received.get(i).get(4));
			setEstadoPedido(n, received.get(i).get(5));
			
			i=i+1;
		}
		received = Repo.getUpdateRefei�aoPedido();
		i = 0;
		u = received.size()-1;
		while (i<=u) {
			addRefeiPedido(received.get(i).get(1), received.get(i).get(0));
			setEstadoRefeiPedido(received.get(i).get(1), received.get(i).get(0), received.get(i).get(2));
			setQuantRefeiPedido(received.get(i).get(1), received.get(i).get(0), received.get(i).get(3));
			this.setSaidaRefeiPedido(received.get(i).get(1), received.get(i).get(0), received.get(i).get(4));
			i=i+1;
		}
		
		ModRepo=true;
		
		
	}
	
	private void setSaidaRefeiPedido(String nOrdem, String refei, String text) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		ArrayList<String> datetimeget = Utility.stringtodate(text);
		p.setSaidaRefei(refei,datetimeget.get(0),datetimeget.get(1),datetimeget.get(2));
		
	}

	private void setQuantRefeiPedido(String nOrdem, String refei, String text) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setQuantRefei(refei,text);
		
	}

	private void setsaida(String Nordem, String day, String month, String year) {
		if (Nordem==null) {
			return;
		}
		Pedido p = procurarPedido(Nordem);
		if (p==null) {
			return;
		}
		p.setsaida(day,month,year);
	}

	private void setentrada(String Nordem, String day, String month, String year) {
		if (Nordem==null) {
			return;
		}
		Pedido p = procurarPedido(Nordem);
		if (p==null) {
			return;
		}
		p.setentrada(day,month,year);
	}

	public Pedido procurarPedido(String Nordem) {
		if (Nordem==null) {
			return null;
		}
		int u = Pedidos.size()-1;
		int i = 0;
		while (i<=u) {
			Pedido o = Pedidos.get(i);
			if (o.getNordem().compareTo(Nordem)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}

	public ArrayList<String> getNOrdemPedidos() {
		ArrayList<String> r = new ArrayList<String>();
		int u = Pedidos.size()-1;
		int i = 0;
		while (i<=u) {
			Pedido o = Pedidos.get(i);
			r.add(o.getNordem());
			
			i=i+1;
		}
		return r ;
	}

	public String getClientePedido(String Nordem) {
		if (Nordem==null) {
			return null;
		}
		Pedido p = procurarPedido(Nordem);
		if (p==null) {
			return null;
		}
		return p.getCliente();
	}

	public String getEntradaPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getEntrada();
	}

	public String getSaidaPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getSaida();
	}

	public String getPreoTotPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getPreoTotal();
	}

	public String getPreoExtPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getPreoExtra();
	}

	public String getLocalPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getLocal();
	}

	public String getEstadoPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getEstado();
	}

	public void setClientePedido(String nOrdem, String v) throws IOException, SQLException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setCliente(v);
		if (ModRepo==true) {
			Repo.updatePedido(nOrdem, "NomeCliente", v); 
		}
	}

	public void setPreoExtPedido(String nOrdem, String v) throws IOException, SQLException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setPreoExt(v);
		if (ModRepo==true) {
			Repo.updatePedido(nOrdem, "pre�oextra", v); 
		}
	}

	public void setLocalPedido(String nOrdem, String v) throws IOException, SQLException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setLocal(v);
		if (ModRepo==true) {
			Repo.updatePedido(nOrdem, "local", v); 
		}
		
	}

	public void enviarPedido(String nOrdem) throws IOException, SQLException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.enviar();
		if (ModRepo==true) {
			Repo.updatePedido(nOrdem, "enviado", "1"); 
		}
		
	}

	public ArrayList<String> getRefeiPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getRefeiList(nOrdem);
		
	}

	public void addRefeiPedido(String nOrdem, String n) throws IOException, SQLException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		int exists =0;
		if (p.getQuantiRefei(n)!=null) {
			exists=Integer.parseInt(p.getQuantiRefei(n));
		}
		
		p.addRefei(n);
		
		if (ModRepo==true) {
			if (exists!=0) {
				Repo.cadastrarRefei�aoPedido(n,nOrdem);
			}else {
				Repo.updateRefei�aoPedido(n, nOrdem, "quantirefei�ao", Integer.toString(exists+1));
			}
		}
		
	}

	public void removRefeiPedido(String nOrdem, String text) throws IOException, SQLException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.removRefei(text);
		if (ModRepo==true) {
			Repo.removerRefei�aoPedido(text, nOrdem);
		}
	}

	public String getEstadoRefei�ao(String nOrdem, String refei) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getEstadoRefei(refei);
		
	}

	public void setEstadoRefeiPedido(String nOrdem, String refei, String text) throws IOException, SQLException {
		AFachada.getAccess("ModCozinha");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		int exists =0;
		if (p.getQuantiRefei(refei)!=null) {
			exists=Integer.parseInt(p.getQuantiRefei(refei));
		}
		
		
		p.setEstadoRefei(refei,text);
		
		
		if (ModRepo==true) {
			if (exists!=0) {
				Repo.cadastrarRefei�aoPedido(refei,nOrdem);
			}else {
				Repo.updateRefei�aoPedido(refei, nOrdem, "estadorefei�ao", Integer.toString(exists+1));
			}
		}
		
	}

	public String getQuantiRefei(String nOrdem, String refei) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getQuantiRefei(refei);
	}

	public void setEstadoPedido(String nOrdem, String string) throws IOException, SQLException {
		AFachada.getAccess("ModCozinha");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setEstado(string);
		if (ModRepo==true) {
			Repo.updatePedido(nOrdem, "estado", string);
		}
	}

	public void setEstadoTRefeiPedido(String nOrdem, String string) throws IOException, SQLException {
		AFachada.getAccess("ModCozinha");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setEstadoTRefei(string);
		if (ModRepo==true) {
			Repo.updatePedido(nOrdem, "estado", string);
			Repo.updateRefei�aoPedidoTodos(nOrdem, "estadorefei�ao", string);
		}
	}

	public String getSaidaRefeiPedido(String nOrdem, String string2) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getSaidaRefeiPedido(string2);
	}

	public void eatItemPedido(String nordem, String iDrefei) throws IOException {
		AFachada.getAccess("ModCozinha");
		Pedido p = procurarPedido(nordem);
		if (p==null) {
			return;
		}
		System.out.println("clk3");
		p.eatItemPedido(iDrefei);
		
	}
	
	
}
