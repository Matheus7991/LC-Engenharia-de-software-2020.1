package main;

import java.sql.SQLException;
import java.util.ArrayList;

import dados.RepositorioRefei�ao;

public class ControleRefei�ao {
	//cadastrar
	//remover
	//atualizar
	//procurar
	
	public ArrayList<Refei�ao> Refei�oes = new ArrayList<Refei�ao>();
	
	private RepositorioRefei�ao Repo = new RepositorioRefei�ao();
	private boolean ModRepo = false;
	private Fachada AFachada;
	
	public ControleRefei�ao(Fachada fachada) {
		AFachada = fachada;
	}

	public void cadastrarRefei�ao(String nome) {
		if (procurarRefei�ao(nome)!=null) {
			return;
		}
		int i =0;
		while (procurarRefei�aoNid(Integer.toString(i))!=null) {
			i=i+1;
		}
		Refei�ao P = new Refei�ao(i, nome, AFachada);
		Refei�oes.add(P);
		
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.cadastrarRefei�ao(nome);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void cadastrarRefei�ao(String nome,int nid) {
		if (procurarRefei�ao(nome)!=null) {
			return;
		}
		Refei�ao P = new Refei�ao(nid, nome, AFachada);
		Refei�oes.add(P);
		
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.cadastrarRefei�ao(nome);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void removerRefei�ao(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return;
		}
		Refei�oes.remove(r);
		if (ModRepo==false) {
			return;
		}
		try {
			Repo.removerRefei�ao(n);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void atualizar() throws SQLException {
		ModRepo=false;
		ArrayList<ArrayList<String>> received = Repo.getUpdateRefei�ao();
		Refei�oes.clear();
		
		int i = 0;
		int u = received.size()-1;
		while (i<=u) {
			String n = received.get(i).get(0);
			cadastrarRefei�ao(n,Integer.parseInt(received.get(i).get(2)));
			modPreco(received.get(i).get(2), Integer.parseInt(received.get(i).get(1)));
			i=i+1;
		}
		received = Repo.getUpdateItempedidoRefei�ao();
		i = 0;
		u = received.size()-1;
		while (i<=u) {
			addIgred(received.get(i).get(1), received.get(i).get(0),Integer.parseInt(received.get(i).get(2)));
			i=i+1;
		}
		
		ModRepo=true;
		
	}
	
	public Refei�ao procurarRefei�ao(String n) {
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			if (o.getName().compareTo(n)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}
	
	private Refei�ao procurarRefei�aoNid(String nid) {
		int inid = Integer.parseInt(nid);
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			Refei�ao o = Refei�oes.get(i);
			if (o.getNid()==inid) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}

	public ArrayList<Refei�ao> getRefei() {
		return Refei�oes;
	}

	public void modPreco(String string, int i) {
		Refei�ao r = procurarRefei�aoNid(string);
		if (r==null) {
			return;
		}
		r.setCusto(i);
		if (ModRepo==true) {
			try {
				Repo.updateatributeRefei�ao(string, "custo", Integer.toString(i));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	public ArrayList<String> getIDs() {
		ArrayList<String> r = new ArrayList<String>();
		int u = Refei�oes.size()-1;
		int i = 0;
		while (i<=u) {
			r.add(Integer.toString(Refei�oes.get(i).getNid()));
			i=i+1;
		}
		return r;
	}

	public ArrayList<String> getIgred(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return null;
		}
		return r.getigreds();
	}

	public void removIgred(String ID, String n) throws SQLException {
		Refei�ao r = procurarRefei�aoNid(ID);
		if (r==null) {
			return;
		}
		ArrayList<String> ingreds = r.getigredsnames();
		int y =n.indexOf(" ", n.indexOf(" ") + 1);
		n = n.substring(y+1);
		int i= ingreds.indexOf(n);
		System.out.println(i);
		ArrayList<String> qingreds = r.getqigreds();
		System.out.println(qingreds);
		String u = qingreds.get(i);
		
		r.removigred(n);
		
		if (ModRepo==true) {
				Repo.removerItempedidoRefei�ao(ID,n, u);
				i=i+1;
			
		}
	}

	public void addIgred(String n, String ingred,int q) throws SQLException {
		Refei�ao r = procurarRefei�aoNid(n);
		System.out.println("heya "+r+" n "+ingred+" n "+q);
		if (r==null) {
			return;
		}
		ArrayList<String> ingreds = r.getigredsnames();
		ArrayList<String> qingreds = r.getqigreds();
		int i= ingreds.indexOf(ingred);
		boolean existed =  true;
		if (i==-1) {
			existed = false;
		}
		
		r.addigred(ingred,q);
		if (ModRepo==true) {
			if (existed==false) {
				Repo.cadastrarItempedidoRefei�ao(n,ingred, Integer.toString(q));
			}else {
				int u = Integer.parseInt(qingreds.get(i))+q;
				Repo.updateItempedidoRefei�ao(n, ingred, Integer.toString(u));
			}
		}
	}

	public String getnome(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return null;
		}
		return r.getName();
	}

	public int getpreco(String n) {
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return 0;
		}
		return r.getCusto();
	}

	public void setnome(String n, String n2) {
		System.out.println("got:");
		System.out.println(n);
		System.out.println(n2);
		Refei�ao r = procurarRefei�aoNid(n);
		if (r==null) {
			return;
		}
		r.setNome(n2);
		if (ModRepo==true) {
			try {
				Repo.updateatributeRefei�ao(n, "NomeRefei�ao",n2);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
}
