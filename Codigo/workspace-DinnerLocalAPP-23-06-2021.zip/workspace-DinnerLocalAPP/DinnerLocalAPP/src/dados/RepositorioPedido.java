package dados;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RepositorioPedido extends Conexao {
	public void cadastrarPedido(String n) throws SQLException {
		String cmd = "INSERT INTO `new_testschema`.`perfil` (`NomePerfil`) VALUES ('"+n+"');";
		Execute(cmd);
	}

	public void removerPerfil(String n) throws SQLException {
		String cmd = "DELETE FROM `new_testschema`.`perfil` WHERE (`NomePerfil` = '"+n+"');";
		Execute(cmd);
	}

	public ArrayList<ArrayList<String>> getUpdate() throws SQLException {
		
		ResultSet results = Query("SELECT * FROM new_testschema.Perfil;");
		ArrayList<ArrayList<String>> r = new ArrayList<ArrayList<String>>();
		while (results.next()) {
			ArrayList<String> rr = new ArrayList<String>();
			rr.add(results.getString("NomePerfil"));
			rr.add(results.getString("ModCardapio"));
			rr.add(results.getString("ModPedidos"));
			rr.add(results.getString("ModCozinha"));
			rr.add(results.getString("ModPerfil"));
			rr.add(results.getString("ModItemPedidos"));
			rr.add(results.getString("ModArquivo"));
			r.add(rr);
		}
		return r;
	}

	
}
