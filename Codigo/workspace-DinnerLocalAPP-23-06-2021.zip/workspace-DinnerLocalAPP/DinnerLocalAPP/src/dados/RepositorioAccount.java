package dados;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RepositorioAccount extends Conexao {
	public void createtable() throws SQLException {//execute if table doesnt exists
		String createtable =
						"CREATE TABLE `new_testschema`.`conta` (\r\n" + 
						"  `CPF` VARCHAR(12) NOT NULL,\r\n" + 
						"  `Senha` VARCHAR(45) NULL,\r\n" + 
						"  `NomeConta` VARCHAR(45) NULL,\r\n" + 
						"  `Salario` INT NULL,\r\n" + 
						"  `Perfil` VARCHAR(45) NULL,\r\n" + 
						"  PRIMARY KEY (`CPF`),\r\n" + 
						"  UNIQUE INDEX `CPF_UNIQUE` (`CPF` ASC) VISIBLE,\r\n" + 
						"  INDEX `Perfil_idx` (`Perfil` ASC) VISIBLE,\r\n" + 
						"  CONSTRAINT `Perfil`\r\n" + 
						"    FOREIGN KEY (`Perfil`)\r\n" + 
						"    REFERENCES `new_testschema`.`perfil` (`NomePerfil`)\r\n" + 
						"    ON DELETE NO ACTION\r\n" + 
						"    ON UPDATE NO ACTION);";
		Execute(createtable);
	}

	public void cadastarAccount(String cPF, String senha) throws SQLException {
		String cmd = "INSERT INTO `new_testschema`.`conta` (`CPF`, `Senha`, `NomeConta`, `Salario`, `Perfil`) VALUES ('"+cPF+"', '"+senha+"', 'SemNome', '0', 'SemPerfil');";
		Execute(cmd);
	}

	public void removerAccount(String cPF) throws SQLException {
		String cmd = "DELETE FROM `new_testschema`.`conta` WHERE (`CPF` = '"+cPF+"');";
		Execute(cmd);
		
	}

	public ArrayList<ArrayList<String>> getUpdate() throws SQLException {
		ResultSet results = Query("SELECT * FROM new_testschema.conta;");
		ArrayList<ArrayList<String>> r = new ArrayList<ArrayList<String>>();
		while (results.next()) {
			ArrayList<String> rr = new ArrayList<String>();
			rr.add(results.getString("CPF"));
			rr.add(results.getString("Senha"));
			rr.add(results.getString("NomeConta"));
			rr.add(results.getString("Salario"));
			rr.add(results.getString("Perfil"));
			r.add(rr);
		}
		return r;
	}

	public void updateatribute(String cPF, String nomeatribut, String novovalor) throws SQLException {
		String cmd = "UPDATE `new_testschema`.`conta` SET `"+nomeatribut+"` = '"+novovalor+"' WHERE (`CPF` = '"+cPF+"');";
		Execute(cmd);
	}
	
	
}
