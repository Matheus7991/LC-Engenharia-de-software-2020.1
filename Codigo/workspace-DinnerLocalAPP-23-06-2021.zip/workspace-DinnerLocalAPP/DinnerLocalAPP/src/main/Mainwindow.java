package main;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;

public class Mainwindow {

	
	private Container Ocardapio = null;
	public JFrame frame;
	private JTextField txtCpf;
	private JPasswordField pwdSenha;
	private JLabel lblBemVindoUsuario;
	private JPanel panel_14; //Tela de perfis
	private JPanel panel_13; //Tela de mod de perfis
	private JLabel lblSelecionarPerfil; //Texto selecionar perfil
	private JPanel panel_1; //Tela de contas
	
	private String CPFselecion=null;
	private JLabel lblNome_2;//Nome da conta selecionada
	private JLabel lblCpf_1; //CPF da conta selecionada
	private JLabel lblPerfil; //Perfil da contaselecionada
	private JLabel lblSalario; //Salario da conta selecionada
	private JLabel lblSenha_1; //Senha da  conta selecionada
	private JPanel panel_15; //Tela de pedidos;
	
	private String Pedidoselecion = null;
	private JLabel lblNomecliente; //Nome cliente, do pedido selecionado
	private JLabel lblNordem_1; //N.Ordem, do pedido selecionado 
	private JLabel lblEntrada_1; //Entrada do pedido selecionado
	private JLabel lblSaida_1; //saida to pedido selecionado
	private JLabel lblPreoTotal; //pre�o dos items , do pedido selecionado
	private JLabel lblPreoExra;//pre�o extra , do pedido
	private JLabel lblPreoTotal_1;//pre�o dos items + extra
	private JLabel lblLocal_1;//Local
	private JLabel lblEstado_2;//estado do pedido (Editando, Em espera, Em preparo, Pronto, Em entrega, Encerrado, Cancelado)
	private JPanel panel_16;//tela de items do pedido;
	private JPanel panel_5;//tela de cozinha
	
	private String ItemPedidoSelecion = null;
	private JPanel panelOfEstoques; //Tela de itempedidos
	private JLabel lblNome_3ItPe;
	private JLabel lblQuantidadeItPe;
	private JLabel lblValidadeItPe;
	
	private String RefeiSelecion=null;
	private JPanel panelCardap;
	private JPanel panelIngredientes;
	private JLabel lblId;
	private JLabel lblNome_3;
	private JLabel lblCusto;
	
	private Fachada AFachada = Fachada.newFachada();
	
	// Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mainwindow window = new Mainwindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}
	 
	/**
	 * Create the application.
	 */
	public Mainwindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		AFachada.testvar();
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 701, 493);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		frame.getContentPane().add(tabbedPane, BorderLayout.CENTER);
		
		JPanel LoginPanel = new JPanel();
		tabbedPane.addTab("Login", null, LoginPanel, null);
		LoginPanel.setLayout(null);
		
		lblBemVindoUsuario = new JLabel("Bem vindo usuario");
		lblBemVindoUsuario.setBounds(10, 11, 460, 14);
		LoginPanel.add(lblBemVindoUsuario);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AFachada.login(txtCpf.getText(),String.valueOf(pwdSenha.getPassword()));
				AtualizarLogin();
			}
		});
		btnLogin.setBounds(10, 360, 89, 23);
		LoginPanel.add(btnLogin);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setBounds(10, 335, 46, 14);
		LoginPanel.add(lblSenha);
		
		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setBounds(10, 310, 46, 14);
		LoginPanel.add(lblCpf);
		
		txtCpf = new JTextField();
		txtCpf.setText("CPF");
		txtCpf.setBounds(55, 304, 86, 20);
		LoginPanel.add(txtCpf);
		txtCpf.setColumns(10);
		
		pwdSenha = new JPasswordField();
		pwdSenha.setText("Senha");
		pwdSenha.setBounds(55, 329, 86, 20);
		LoginPanel.add(pwdSenha);
		
		JButton btnLogoff = new JButton("Logoff");
		btnLogoff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AFachada.logoff();
				AtualizarLogin();
			}
		});
		btnLogoff.setBounds(10, 394, 89, 23);
		LoginPanel.add(btnLogoff);
		
		JPanel PedidosPanel = new JPanel();
		tabbedPane.addTab("Pedidos", null, PedidosPanel, null);
		PedidosPanel.setLayout(null);
		
		JLabel lblSelectionarPedido = new JLabel("Selectionar pedido:");
		lblSelectionarPedido.setBounds(10, 11, 112, 14);
		PedidosPanel.add(lblSelectionarPedido);
		
		JScrollPane scrollPane_8 = new JScrollPane();
		scrollPane_8.setBounds(10, 36, 173, 379);
		PedidosPanel.add(scrollPane_8);
		
		panel_15 = new JPanel();
		scrollPane_8.setViewportView(panel_15);
		GridBagLayout gbl_panel_15 = new GridBagLayout();
		gbl_panel_15.columnWidths = new int[] {150, 0};
		gbl_panel_15.rowHeights = new int[] {30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0};
		gbl_panel_15.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gbl_panel_15.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		panel_15.setLayout(gbl_panel_15);
		
		JScrollPane scrollPane_9 = new JScrollPane();
		scrollPane_9.setBounds(507, 36, 173, 359);
		PedidosPanel.add(scrollPane_9);
		
		panel_16 = new JPanel();
		scrollPane_9.setViewportView(panel_16);
		GridBagLayout gbl_panel_16 = new GridBagLayout();
		gbl_panel_16.columnWidths = new int[] {150, 0};
		gbl_panel_16.rowHeights = new int[] {30, 30, 30, 0, 0, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0};
		gbl_panel_16.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gbl_panel_16.rowWeights = new double[]{0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel_16.setLayout(gbl_panel_16);
		
		JLabel lblItemsDoPedido = new JLabel("Items (Clique para remover)");
		lblItemsDoPedido.setBounds(499, 11, 181, 14);
		PedidosPanel.add(lblItemsDoPedido);
		
		JButton btnEditar = new JButton("Editar:"); //Nomecliente
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (Pedidoselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Novo Nome:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					AFachada.setClientePedido(Pedidoselecion,v);
				} catch (IOException e) {
					JOptionPane.showMessageDialog(frame, e.getMessage());
				}
				atualizarPedidos();
			}
		});
		btnEditar.setBounds(432, 36, 65, 23);
		PedidosPanel.add(btnEditar);
		
		lblNomecliente = new JLabel("NomeCliente:");
		lblNomecliente.setBounds(193, 36, 229, 23);
		PedidosPanel.add(lblNomecliente);
		
		JButton button_18 = new JButton("Editar:");//pre�o extra
		button_18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Pedidoselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Pre�o extra:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					AFachada.setPreoExtPedido(Pedidoselecion,v);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
			}
		});
		button_18.setBounds(432, 206, 65, 23);
		PedidosPanel.add(button_18);
		
		lblNordem_1 = new JLabel("N.Ordem:");
		lblNordem_1.setBounds(193, 70, 229, 23);
		PedidosPanel.add(lblNordem_1);
		
		lblEntrada_1 = new JLabel("Entrada:");
		lblEntrada_1.setBounds(193, 104, 229, 23);
		PedidosPanel.add(lblEntrada_1);
		
		lblSaida_1 = new JLabel("Saida:");
		lblSaida_1.setBounds(193, 138, 229, 23);
		PedidosPanel.add(lblSaida_1);
		
		lblPreoTotal = new JLabel("Pre\u00E7o Items");
		lblPreoTotal.setBounds(193, 176, 229, 23);
		PedidosPanel.add(lblPreoTotal);
		
		lblPreoExra = new JLabel("Pre\u00E7o Extra");
		lblPreoExra.setBounds(193, 206, 229, 23);
		PedidosPanel.add(lblPreoExra);
		
		lblPreoTotal_1 = new JLabel("Pre\u00E7o Total");
		lblPreoTotal_1.setBounds(193, 240, 229, 23);
		PedidosPanel.add(lblPreoTotal_1);
		
		lblLocal_1 = new JLabel("Local");
		lblLocal_1.setBounds(193, 274, 229, 23);
		PedidosPanel.add(lblLocal_1);
		
		JButton button_17 = new JButton("Editar:"); //Local
		button_17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Pedidoselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Local:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					AFachada.setLocalPedido(Pedidoselecion,v);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
			}
		});
		button_17.setBounds(432, 274, 65, 23);
		PedidosPanel.add(button_17);
		
		lblEstado_2 = new JLabel("Estado: ");
		lblEstado_2.setBounds(193, 308, 229, 23);
		PedidosPanel.add(lblEstado_2);
		
		JButton btnEnviar_1 = new JButton("Enviar");
		btnEnviar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					AFachada.setEstadoPedido(Pedidoselecion, "Em espera");
					AFachada.setEstadoTRefeiPedido(Pedidoselecion, "Em espera");
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
			}
		});
		btnEnviar_1.setBounds(193, 342, 89, 23);
		PedidosPanel.add(btnEnviar_1);
		
		JButton btnAtualizar_3 = new JButton("Atualizar");
		btnAtualizar_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atualizarPedidos();
			}
		});
		btnAtualizar_3.setBounds(591, 392, 89, 23);
		PedidosPanel.add(btnAtualizar_3);
		
		JButton btnEncerrar = new JButton("Encerrar");
		btnEncerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					AFachada.setEstadoPedido(Pedidoselecion, "Encerrado");
					AFachada.setEstadoTRefeiPedido(Pedidoselecion, "Encerrado");
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
			}
		});
		btnEncerrar.setBounds(193, 376, 89, 23);
		PedidosPanel.add(btnEncerrar);
		
		JButton btnCancelar_1 = new JButton("Cancelar");
		btnCancelar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					AFachada.setEstadoPedido(Pedidoselecion, "Cancelado");
					AFachada.setEstadoTRefeiPedido(Pedidoselecion, "Cancelado");
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
			}
		});
		btnCancelar_1.setBounds(292, 376, 89, 23);
		PedidosPanel.add(btnCancelar_1);
		
		JButton removebutton = new JButton("Remover");
		removebutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					AFachada.removPedido(Pedidoselecion);
					Pedidoselecion=null;
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
			}
		});
		removebutton.setBounds(193, 410, 89, 23);
		PedidosPanel.add(removebutton);
		//##############################################################################
		/*
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.insets = new Insets(0, 0, 5, 0);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 0;
		Ocardapio.add(panel_1, gbc_panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(0, 0, 46, 14);
		panel_1.add(lblNome);
		
		JButton btnAdicionar = new JButton("Adicionar");
		btnAdicionar.setBounds(546, 0, 89, 23);
		panel_1.add(btnAdicionar);
		
		JButton btnModificar = new JButton("Modificar");
		btnModificar.setBounds(448, 0, 89, 23);
		panel_1.add(btnModificar);
		
		JLabel lblPreo = new JLabel("Pre\u00E7o");
		lblPreo.setBounds(334, 0, 46, 14);
		panel_1.add(lblPreo);
		*/
		
		JPanel CardapioPanel = new JPanel();
		tabbedPane.addTab("Cardapio", null, CardapioPanel, null);
		CardapioPanel.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 46, 173, 379);
		CardapioPanel.add(scrollPane_2);
		
		panelCardap = new JPanel();
		scrollPane_2.setViewportView(panelCardap);
		GridBagLayout gbl_panelCardap = new GridBagLayout();
		gbl_panelCardap.columnWidths = new int[]{150, 0};
		gbl_panelCardap.rowHeights = new int[]{30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0, 0};
		gbl_panelCardap.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gbl_panelCardap.rowWeights = new double[]{0.0, 0.0, 4.9E-324, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panelCardap.setLayout(gbl_panelCardap);
		
		JLabel lblItems = new JLabel("Items");
		lblItems.setBounds(10, 11, 173, 14);
		CardapioPanel.add(lblItems);
		
		lblId = new JLabel("Id:");
		lblId.setBounds(193, 46, 299, 14);
		CardapioPanel.add(lblId);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(507, 46, 173, 379);
		CardapioPanel.add(scrollPane_3);
		
		panelIngredientes = new JPanel();
		scrollPane_3.setViewportView(panelIngredientes);
		GridBagLayout gbl_panelIngredientes = new GridBagLayout();
		gbl_panelIngredientes.columnWidths = new int[] {150, 0};
		gbl_panelIngredientes.rowHeights = new int[]{30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0, 0};
		gbl_panelIngredientes.columnWeights = new double[]{0.0};
		gbl_panelIngredientes.rowWeights = new double[]{0.0, 0.0, 4.9E-324, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panelIngredientes.setLayout(gbl_panelIngredientes);
		
		JButton btnNewButton = new JButton("New button");
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 0);
		gbc_btnNewButton.gridx = 0;
		gbc_btnNewButton.gridy = 0;
		panelIngredientes.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New button");
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 0);
		gbc_btnNewButton_1.gridx = 0;
		gbc_btnNewButton_1.gridy = 1;
		panelIngredientes.add(btnNewButton_1, gbc_btnNewButton_1);
		
		JLabel lblIgredientes = new JLabel("Igredientes");
		lblIgredientes.setBounds(507, 11, 173, 14);
		CardapioPanel.add(lblIgredientes);
		
		lblNome_3 = new JLabel("Nome:");
		lblNome_3.setBounds(193, 71, 299, 14);
		CardapioPanel.add(lblNome_3);
		
		lblCusto = new JLabel("Custo:");
		lblCusto.setBounds(193, 96, 299, 14);
		CardapioPanel.add(lblCusto);
		
		JButton btnEditar_2 = new JButton("Editar");//editar nome de refei�
		btnEditar_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Nome do Item:");
				try {
					AFachada.modnomeRefei(RefeiSelecion,n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				AtualizarCardapio2();
			}
		});
		btnEditar_2.setBounds(408, 71, 89, 23);
		CardapioPanel.add(btnEditar_2);
		
		JButton btnEditar_3 = new JButton("Editar");//editar custo da refei
		btnEditar_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Custo:");
				try {
					AFachada.modCustRefei(n,RefeiSelecion);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				AtualizarCardapio2();
			}
		});
		btnEditar_3.setBounds(408, 96, 89, 23);
		CardapioPanel.add(btnEditar_3);
		
		JButton btnAtualizar_6 = new JButton("Atualizar");
		btnAtualizar_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AtualizarCardapio2();
			}
		});
		btnAtualizar_6.setBounds(403, 402, 89, 23);
		CardapioPanel.add(btnAtualizar_6);
		
		JButton btnRemover = new JButton("Remover"); //remover refei do cardapio
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					AFachada.removRefei(RefeiSelecion);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				AtualizarCardapio2();
			}
		});
		btnRemover.setBounds(403, 137, 89, 23);
		CardapioPanel.add(btnRemover);
		
		JPanel CozinhaPanel = new JPanel();
		CozinhaPanel.setLayout(null);
		tabbedPane.addTab("Cozinha", null, CozinhaPanel, null);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(10, 11, 670, 364);
		CozinhaPanel.add(scrollPane_4);
		
		panel_5 = new JPanel();
		scrollPane_4.setViewportView(panel_5);
		GridBagLayout gbl_panel_5 = new GridBagLayout();
		gbl_panel_5.columnWidths = new int[]{663, 0};
		gbl_panel_5.rowHeights = new int[] {60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60};
		gbl_panel_5.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_panel_5.rowWeights = new double[]{0.0, 1.0, 1.0, 1.0, 0.0};
		panel_5.setLayout(gbl_panel_5);
		
		//################################################
		JPanel panel_6 = new JPanel();
		panel_6.setLayout(null);
		GridBagConstraints gbc_panel_6 = new GridBagConstraints();
		gbc_panel_6.fill = GridBagConstraints.BOTH;
		gbc_panel_6.insets = new Insets(0, 0, 5, 0);
		gbc_panel_6.gridx = 0;
		gbc_panel_6.gridy = 0;
		panel_5.add(panel_6, gbc_panel_6);
		
		JLabel label_2 = new JLabel("Codigo");
		label_2.setBounds(10, 4, 231, 14);
		panel_6.add(label_2);
		
		JButton button_2 = new JButton("Pronto");
		button_2.setBounds(564, 4, 89, 23);
		panel_6.add(button_2);
		
		JButton button_3 = new JButton("Em Preparo");
		button_3.setBounds(465, 4, 89, 23);
		panel_6.add(button_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.PINK);
		panel_4.setBounds(337, 4, 118, 23);
		panel_6.add(panel_4);
		
		JLabel lblEstado_1 = new JLabel("Estado");
		panel_4.add(lblEstado_1);
		lblEstado_1.setBackground(Color.PINK);
		
		JLabel lblNordem_2 = new JLabel("NOrdem: ");
		lblNordem_2.setBounds(262, 4, 65, 14);
		panel_6.add(lblNordem_2);
		
		JLabel lblEntrada_2 = new JLabel("Entrada:");
		lblEntrada_2.setBounds(10, 30, 317, 14);
		panel_6.add(lblEntrada_2);
		
		JLabel lblSaida_2 = new JLabel("Saida:");
		lblSaida_2.setBounds(337, 30, 46, 14);
		panel_6.add(lblSaida_2);
		
		//################################################
		
		JButton btnAtualizar_4 = new JButton("Atualizar");
		btnAtualizar_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AtualizarCozinha();
			}
		});
		btnAtualizar_4.setBounds(591, 386, 89, 23);
		CozinhaPanel.add(btnAtualizar_4);
		
		JPanel EstoquePanel = new JPanel();
		tabbedPane.addTab("Estoque", null, EstoquePanel, null);
		EstoquePanel.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 11, 173, 379);
		EstoquePanel.add(scrollPane_1);
		
		panelOfEstoques = new JPanel();
		scrollPane_1.setViewportView(panelOfEstoques);
		GridBagLayout gbl_panelOfEstoques = new GridBagLayout();
		gbl_panelOfEstoques.columnWidths = new int[]{150, 0};
		gbl_panelOfEstoques.rowHeights = new int[]{30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0, 0};
		gbl_panelOfEstoques.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gbl_panelOfEstoques.rowWeights = new double[]{0.0, 0.0, 4.9E-324, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panelOfEstoques.setLayout(gbl_panelOfEstoques);
		
		JButton btnItempedido = new JButton("ItemPedido");
		GridBagConstraints gbc_btnItempedido = new GridBagConstraints();
		gbc_btnItempedido.anchor = GridBagConstraints.WEST;
		gbc_btnItempedido.insets = new Insets(0, 0, 5, 0);
		gbc_btnItempedido.gridx = 0;
		gbc_btnItempedido.gridy = 0;
		panelOfEstoques.add(btnItempedido, gbc_btnItempedido);
		
		JButton btnNovoItem_1 = new JButton("Novo item");
		GridBagConstraints gbc_btnNovoItem_1 = new GridBagConstraints();
		gbc_btnNovoItem_1.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoItem_1.gridx = 0;
		gbc_btnNovoItem_1.gridy = 1;
		panelOfEstoques.add(btnNovoItem_1, gbc_btnNovoItem_1);
		
		lblNome_3ItPe = new JLabel("Nome:");
		lblNome_3ItPe.setBounds(193, 11, 492, 14);
		EstoquePanel.add(lblNome_3ItPe);
		
		lblQuantidadeItPe = new JLabel("Quantidade:");
		lblQuantidadeItPe.setBounds(193, 36, 492, 14);
		EstoquePanel.add(lblQuantidadeItPe);
		
		lblValidadeItPe = new JLabel("Validade: ");
		lblValidadeItPe.setBounds(193, 61, 492, 14);
		EstoquePanel.add(lblValidadeItPe);
		
		JButton btnEditarNome = new JButton("Editar");
		btnEditarNome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (ItemPedidoSelecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Novo Nome:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					AFachada.setNomeItemPedido(ItemPedidoSelecion,v);
					ItemPedidoSelecion = v;
				} catch (IOException e) {
					JOptionPane.showMessageDialog(frame, e.getMessage());
				}
				atualizarItemsPedidos();
				
			}
		});
		btnEditarNome.setBounds(596, 11, 89, 23);
		EstoquePanel.add(btnEditarNome);
		
		JButton btnEditarQuanti = new JButton("Editar");
		btnEditarQuanti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (ItemPedidoSelecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Nova quantidade:");
				if (v==null || v.isEmpty()) {
					return;
				}
				String v2 = JOptionPane.showInputDialog("Medida:");
				if (v2==null || v2.isEmpty()) {
					return;
				}
				int vv = Integer.parseInt(v);
				try {
					AFachada.setQuantItemPedido(ItemPedidoSelecion,vv);
					AFachada.setSufixItemPedido(ItemPedidoSelecion,v2);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarItemsPedidos();
			}
		});
		btnEditarQuanti.setBounds(596, 36, 89, 23);
		EstoquePanel.add(btnEditarQuanti);
		
		JButton btnEditarValid = new JButton("Editar");
		btnEditarValid.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (ItemPedidoSelecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Ano:");
				if (v==null || v.isEmpty()) {
					return;
				}
				String v2 = JOptionPane.showInputDialog("Mes:");
				if (v2==null || v2.isEmpty()) {
					return;
				}
				String v3 = JOptionPane.showInputDialog("Dia:");
				if (v3==null || v3.isEmpty()) {
					return;
				}
				try {
					AFachada.setValidItemPedido(ItemPedidoSelecion,v3,v2,v);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarItemsPedidos();
			}
		});
		btnEditarValid.setBounds(596, 61, 89, 23);
		EstoquePanel.add(btnEditarValid);
		
		JButton btnAtualizar_5 = new JButton("Atualizar");
		btnAtualizar_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atualizarItemsPedidos();
			}
		});
		btnAtualizar_5.setBounds(596, 408, 89, 23);
		EstoquePanel.add(btnAtualizar_5);
		
		JButton btnRemover_2 = new JButton("Remover");
		btnRemover_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					AFachada.removerItemPedido(ItemPedidoSelecion);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarItemsPedidos();
			}
		});
		btnRemover_2.setBounds(596, 95, 89, 23);
		EstoquePanel.add(btnRemover_2);
		
		JPanel PerfilPanel = new JPanel();
		tabbedPane.addTab("Perfis", null, PerfilPanel, null);
		PerfilPanel.setLayout(null);
		
		lblSelecionarPerfil = new JLabel("Selecionar perfil:");
		lblSelecionarPerfil.setBounds(10, 11, 173, 14);
		PerfilPanel.add(lblSelecionarPerfil);
		
		JScrollPane scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(193, 36, 173, 379);
		PerfilPanel.add(scrollPane_6);
		
		panel_13 = new JPanel();
		scrollPane_6.setViewportView(panel_13);
		GridBagLayout gbl_panel_13 = new GridBagLayout();
		gbl_panel_13.columnWidths = new int[] {150};
		gbl_panel_13.rowHeights = new int[]{30, 0, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0};
		gbl_panel_13.columnWeights = new double[]{1.0};
		gbl_panel_13.rowWeights = new double[]{1.0, 1.0, 1.0, 0.0, 4.9E-324, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel_13.setLayout(gbl_panel_13);
		
		//#########################################################
		/*
		JCheckBox chckbxNewCheckBox = new JCheckBox("Permissao1");
		//chckbxNewCheckBox.setSelected(false);
		//Boolean r = chckbxNewCheckBox.isSelected();
		chckbxNewCheckBox.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_chckbxNewCheckBox = new GridBagConstraints();
		gbc_chckbxNewCheckBox.anchor = GridBagConstraints.WEST;
		gbc_chckbxNewCheckBox.insets = new Insets(0, 0, 5, 0);
		gbc_chckbxNewCheckBox.gridx = 0;
		gbc_chckbxNewCheckBox.gridy = 0;
		panel_13.add(chckbxNewCheckBox, gbc_chckbxNewCheckBox);
		*/
		//#########################################################
		/*
		JButton btnRemoverPerfil = new JButton("Remover Perfil");
		btnRemoverPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GridBagConstraints gbc_btnRemoverPerfil = new GridBagConstraints();
		gbc_btnRemoverPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnRemoverPerfil.gridx = 0;
		gbc_btnRemoverPerfil.gridy = 1;
		panel_13.add(btnRemoverPerfil, gbc_btnRemoverPerfil);
		*/
		//#########################################################
		
		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(10, 36, 173, 379);
		PerfilPanel.add(scrollPane_5);
		
		panel_14 = new JPanel();
		scrollPane_5.setViewportView(panel_14);
		GridBagLayout gbl_panel_14 = new GridBagLayout();
		gbl_panel_14.columnWidths = new int[] {150, 0};
		gbl_panel_14.rowHeights = new int[]{30, 0, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0};
		gbl_panel_14.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_panel_14.rowWeights = new double[]{1.0, 1.0, 1.0, 0.0, 4.9E-324, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel_14.setLayout(gbl_panel_14);
		
		//#################################################
		/*
		JButton btnNovoPerfil = new JButton("Novo Perfil");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GridBagConstraints gbc_btnNovoPerfil = new GridBagConstraints();
		gbc_btnNovoPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoPerfil.gridx = 0;
		gbc_btnNovoPerfil.gridy = 1;
		panel_14.add(btnNovoPerfil, gbc_btnNovoPerfil);
		*/
		//#################################################
		
		JLabel lblModificarPerfil = new JLabel("Permiss\u00F5es:");
		lblModificarPerfil.setBounds(193, 11, 103, 14);
		PerfilPanel.add(lblModificarPerfil);
		
		JButton btnAtualizar_1 = new JButton("Atualizar");
		btnAtualizar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atualizarPerfis();
			}
		});
		btnAtualizar_1.setBounds(596, 392, 89, 23);
		PerfilPanel.add(btnAtualizar_1);
		
		JPanel ContasPanel = new JPanel();
		tabbedPane.addTab("Contas", null, ContasPanel, null);
		ContasPanel.setLayout(null);
		
		JLabel lblSelecionarConta = new JLabel("Selecionar conta:");
		lblSelecionarConta.setBounds(10, 11, 117, 14);
		ContasPanel.add(lblSelecionarConta);
		
		JScrollPane scrollPane_7 = new JScrollPane();
		scrollPane_7.setBounds(10, 36, 173, 379);
		ContasPanel.add(scrollPane_7);
		
		panel_1 = new JPanel();
		scrollPane_7.setViewportView(panel_1);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[] {150};
		gbl_panel_1.rowHeights = new int[] {0, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 0};
		gbl_panel_1.columnWeights = new double[]{0.0};
		gbl_panel_1.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		//#######################
		/*
		JButton btnConta = new JButton("Conta1");
		btnConta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		GridBagConstraints gbc_btnConta = new GridBagConstraints();
		gbc_btnConta.anchor = GridBagConstraints.WEST;
		gbc_btnConta.insets = new Insets(0, 0, 5, 0);
		gbc_btnConta.gridx = 0;
		gbc_btnConta.gridy = 0;
		panel_1.add(btnConta, gbc_btnConta);
		*/
		//#######################
		/*
		JButton btnNovaConta = new JButton("Nova Conta");
		btnNovaConta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GridBagConstraints gbc_btnNovaConta = new GridBagConstraints();
		gbc_btnNovaConta.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovaConta.gridx = 0;
		gbc_btnNovaConta.gridy = 1;
		panel_1.add(btnNovaConta, gbc_btnNovaConta);
		*/
		//#######################
		JLabel lblAes = new JLabel("A\u00E7\u00F5es:");
		lblAes.setBounds(634, 11, 46, 14);
		ContasPanel.add(lblAes);
		
		JButton editarnome = new JButton("Editar");//TO DO
		editarnome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (CPFselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Novo Nome:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					AFachada.modNomeConta(CPFselecion,v);
				} catch (IOException e) {
					JOptionPane.showMessageDialog(frame, e.getMessage());
				}
				atualizarContas();
				
			}
		});
		editarnome.setBounds(619, 36, 76, 23);
		ContasPanel.add(editarnome);
		
		lblNome_2 = new JLabel("Nome:");
		lblNome_2.setBounds(193, 36, 416, 22);
		ContasPanel.add(lblNome_2);
		
		JButton editarcpf = new JButton("Editar");
		editarcpf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (CPFselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Novo CPF:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					AFachada.modCPFConta(CPFselecion,v);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarContas();
			}
		});
		editarcpf.setBounds(619, 70, 76, 23);
		ContasPanel.add(editarcpf);
		
		JButton editarperfil = new JButton("Editar");
		editarperfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (CPFselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Novo Perfil:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					AFachada.modPerfConta(CPFselecion,v);
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarContas();
			}
		});
		editarperfil.setBounds(619, 104, 76, 23);
		ContasPanel.add(editarperfil);
		
		JButton editarsalario = new JButton("Editar");
		editarsalario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					if (CPFselecion==null) {
						return;
					}
					String v = JOptionPane.showInputDialog("Novo Salario:");
					if (v==null || v.isEmpty()) {
						return;
					}
					int vv = Integer.parseInt(v);
					try {
						AFachada.modSalarioConta(CPFselecion,vv);
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(frame, e1.getMessage());
					}
					atualizarContas();
			}
		});
		editarsalario.setBounds(619, 138, 76, 23);
		ContasPanel.add(editarsalario);
		
		lblCpf_1 = new JLabel("CPF:");
		lblCpf_1.setBounds(193, 69, 416, 22);
		ContasPanel.add(lblCpf_1);
		
		lblPerfil = new JLabel("Perfil:");
		lblPerfil.setBounds(193, 104, 416, 22);
		ContasPanel.add(lblPerfil);
		
		lblSalario = new JLabel("Salario:");
		lblSalario.setBounds(193, 138, 416, 22);
		ContasPanel.add(lblSalario);
		
		JButton btnRemover_1 = new JButton("Remover Conta");
		btnRemover_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (CPFselecion==null) {
					return;
				}
				try {
					AFachada.removerConta(CPFselecion);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				CPFselecion=null;
				atualizarContas();
			}
		});
		btnRemover_1.setBounds(558, 204, 122, 23);
		ContasPanel.add(btnRemover_1);
		
		JButton editarsenha = new JButton("Editar");
		editarsenha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (CPFselecion==null) {
					return;
				}
				String v = JOptionPane.showInputDialog("Nova senha:");
				if (v==null || v.isEmpty()) {
					return;
				}
				try {
					AFachada.modSenhaConta(CPFselecion,v);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarContas();
			}
		});
		editarsenha.setBounds(619, 170, 76, 23);
		ContasPanel.add(editarsenha);
		
		JButton versenha = new JButton("Ver");
		versenha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				lblSenha_1.setText("Senha: "+AFachada.GetSenha(CPFselecion));
			}
		});
		versenha.setBounds(548, 170, 61, 23);
		ContasPanel.add(versenha);
		
		lblSenha_1 = new JLabel("Senha:");
		lblSenha_1.setBounds(193, 170, 345, 22);
		ContasPanel.add(lblSenha_1);
		
		JButton btnAtualizar_2 = new JButton("Atualizar");
		btnAtualizar_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				atualizarContas();
			}
		});
		btnAtualizar_2.setBounds(591, 392, 89, 23);
		ContasPanel.add(btnAtualizar_2);
		
		JPanel DataPanel = new JPanel();
		tabbedPane.addTab("Arquivo", null, DataPanel, null);
	}
	
	protected void AtualizarCardapio2() {//TODO
		panelCardap.removeAll();
		ArrayList<String> refs = AFachada.getRefeiID();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			String oo = refs.get(i);
			JButton btnNomeperfil = new JButton(refs.get(i));
			btnNomeperfil.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					RefeiSelecion=oo;
					AtualizarCardapio2();
				}
			});
			GridBagConstraints gbc_btnNomeperfil = new GridBagConstraints();
			gbc_btnNomeperfil.anchor = GridBagConstraints.WEST;
			gbc_btnNomeperfil.insets = new Insets(0, 0, 5, 0);
			gbc_btnNomeperfil.gridx = 0;
			gbc_btnNomeperfil.gridy = i;
			panelCardap.add(btnNomeperfil, gbc_btnNomeperfil);
			i=i+1;
		}
		JButton btnNovoPerfil = new JButton("Novo Item");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Nome do Item:");
				try {
					AFachada.addRefei(n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				AtualizarCardapio2();
				
			}
		});
		GridBagConstraints gbc_btnNovoPerfil = new GridBagConstraints();
		gbc_btnNovoPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoPerfil.gridx = 0;
		gbc_btnNovoPerfil.gridy = i;
		panelCardap.add(btnNovoPerfil, gbc_btnNovoPerfil);
		
		panelIngredientes.removeAll();
		refs = AFachada.getIngredRefei(RefeiSelecion);
		i = 0;
		if (refs==null) {
			u=-1;
		}else {
			u = refs.size()-1;
		}
		while (i<=u) {
			String oo = refs.get(i);
			JButton btnNomeperfil = new JButton(refs.get(i));
			btnNomeperfil.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						AFachada.removIgredRefei(RefeiSelecion,oo);
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(frame, e1.getMessage());
					}
					AtualizarCardapio2();
				}
			});
			GridBagConstraints gbc_btnNomeperfil = new GridBagConstraints();
			gbc_btnNomeperfil.anchor = GridBagConstraints.WEST;
			gbc_btnNomeperfil.insets = new Insets(0, 0, 5, 0);
			gbc_btnNomeperfil.gridx = 0;
			gbc_btnNomeperfil.gridy = i;
			panelIngredientes.add(btnNomeperfil, gbc_btnNomeperfil);
			i=i+1;
		}
		JButton btnNovoPerfil1 = new JButton("Novo Item");
		btnNovoPerfil1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Nome do Item:");
				String n2i = JOptionPane.showInputDialog("Quantidade do Item:");
				if (n2i==null||n2i.isEmpty()) {
					return;
				}
				int n2 = Integer.parseInt(n2i);
				
				try {
					AFachada.addIgredRefei(RefeiSelecion,n,n2);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				AtualizarCardapio2();
				
			}
		});
		GridBagConstraints gbc_btnNovoPerfil1 = new GridBagConstraints();
		gbc_btnNovoPerfil1.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoPerfil1.gridx = 0;
		gbc_btnNovoPerfil1.gridy = i;
		panelIngredientes.add(btnNovoPerfil1, gbc_btnNovoPerfil1);
		
		
		
		
		lblId.setText("ID: "+RefeiSelecion);
		lblNome_3.setText("Nome: "+AFachada.getNomeRefei(RefeiSelecion));
		lblCusto.setText("Custo: "+AFachada.getPrecoFRefei(RefeiSelecion));
		
		
		panelCardap.revalidate();
		panelCardap.repaint();
		
	}

	private void atualizarItemsPedidos() {
		panelOfEstoques.removeAll();
		ArrayList<String> refs = AFachada.getItemPedNames();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			String oo = refs.get(i);
			JButton btnNomeperfil = new JButton(refs.get(i));
			btnNomeperfil.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					ItemPedidoSelecion=oo;
					atualizarItemsPedidos();
				}
			});
			GridBagConstraints gbc_btnNomeperfil = new GridBagConstraints();
			gbc_btnNomeperfil.anchor = GridBagConstraints.WEST;
			gbc_btnNomeperfil.insets = new Insets(0, 0, 5, 0);
			gbc_btnNomeperfil.gridx = 0;
			gbc_btnNomeperfil.gridy = i;
			panelOfEstoques.add(btnNomeperfil, gbc_btnNomeperfil);
			i=i+1;
		}
		JButton btnNovoPerfil = new JButton("Novo Item");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Nome do Item:");
				try {
					AFachada.cadastrarItemPedido(n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPerfis();
				atualizarPerms(null);
				
			}
		});
		GridBagConstraints gbc_btnNovoPerfil = new GridBagConstraints();
		gbc_btnNovoPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoPerfil.gridx = 0;
		gbc_btnNovoPerfil.gridy = i;
		panelOfEstoques.add(btnNovoPerfil, gbc_btnNovoPerfil);
		
		lblNome_3ItPe.setText("Nome: "+ItemPedidoSelecion);
		lblQuantidadeItPe.setText("Quantidade: "+AFachada.getQuantiItemPedido(ItemPedidoSelecion)+" "+AFachada.getSufixItemPedido(ItemPedidoSelecion));;
		lblValidadeItPe.setText("Validade: "+AFachada.getValidItemPedido(ItemPedidoSelecion));
		
		
		panelOfEstoques.revalidate();
		panelOfEstoques.repaint();
		
	}

	//Atualizar
	/*
	private void AtualizarCardapio() {
		Ocardapio.removeAll();
		ArrayList<Refei�ao> refs = AFachada.getRefei();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JPanel panel_1 = new JPanel();
			GridBagConstraints gbc_panel_1 = new GridBagConstraints();
			gbc_panel_1.insets = new Insets(0, 0, 5, 0);
			gbc_panel_1.fill = GridBagConstraints.BOTH;
			gbc_panel_1.gridx = 0;
			gbc_panel_1.gridy = i; //+1
			Ocardapio.add(panel_1, gbc_panel_1);
			panel_1.setLayout(null);
			
			JLabel lblNome = new JLabel(refs.get(i).getNome());
			lblNome.setBounds(0, 0, 46, 14);
			panel_1.add(lblNome);
			
			JButton btnAdicionar = new JButton("Adicionar");
			btnAdicionar.setBounds(546, 0, 89, 23);
			panel_1.add(btnAdicionar);
			
			JButton btnModificar = new JButton("Modificar");
			btnModificar.setBounds(448, 0, 89, 23);
			panel_1.add(btnModificar);
			
			JLabel lblPreo = new JLabel(Integer.toString(refs.get(i).getCusto()));
			lblPreo.setBounds(334, 0, 86, 14);
			panel_1.add(lblPreo);
			i=i+1;
		}
		Ocardapio.revalidate();
		Ocardapio.repaint();
	}
	*/
	private void atualizarPerfis() {
		panel_14.removeAll();
		ArrayList<String> refs = AFachada.getPerfilNames();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JButton btnNomeperfil = new JButton(refs.get(i));
			btnNomeperfil.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					atualizarPerms(btnNomeperfil.getText());
					lblSelecionarPerfil.setText("Selecionar Perfil: "+btnNomeperfil.getText());
					//System.out.println(btnNomeperfil.getText());
				}
			});
			GridBagConstraints gbc_btnNomeperfil = new GridBagConstraints();
			gbc_btnNomeperfil.anchor = GridBagConstraints.WEST;
			gbc_btnNomeperfil.insets = new Insets(0, 0, 5, 0);
			gbc_btnNomeperfil.gridx = 0;
			gbc_btnNomeperfil.gridy = i;
			panel_14.add(btnNomeperfil, gbc_btnNomeperfil);
			i=i+1;
		}
		JButton btnNovoPerfil = new JButton("Novo Perfil");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Nome do perfil:");
				try {
					AFachada.cadastrarPerfil(n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPerfis();
				atualizarPerms(null);
				
			}
		});
		GridBagConstraints gbc_btnNovoPerfil = new GridBagConstraints();
		gbc_btnNovoPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoPerfil.gridx = 0;
		gbc_btnNovoPerfil.gridy = i;
		panel_14.add(btnNovoPerfil, gbc_btnNovoPerfil);
		panel_14.revalidate();
		panel_14.repaint();
	}
	
	private void atualizarPerms(String n) {
		panel_13.removeAll();
		if (n==null) {
			panel_13.revalidate();
			panel_13.repaint();
			return;
		}
		ArrayList<String> refs = AFachada.getPerfilPermNames();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JCheckBox chckbxNewCheckBox = new JCheckBox(refs.get(i));
			chckbxNewCheckBox.setSelected(AFachada.getPerfPerm(n,refs.get(i)));
			chckbxNewCheckBox.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						AFachada.setPerfPerm(n,chckbxNewCheckBox.getText(),chckbxNewCheckBox.isSelected());
					} catch (Exception e1) {
					}
					//System.out.println(chckbxNewCheckBox.isSelected());
				}
			});
			//chckbxNewCheckBox.setSelected(false);
			//Boolean r = chckbxNewCheckBox.isSelected();
			chckbxNewCheckBox.setHorizontalAlignment(SwingConstants.CENTER);
			GridBagConstraints gbc_chckbxNewCheckBox = new GridBagConstraints();
			gbc_chckbxNewCheckBox.anchor = GridBagConstraints.WEST;
			gbc_chckbxNewCheckBox.insets = new Insets(0, 0, 5, 0);
			gbc_chckbxNewCheckBox.gridx = 0;
			gbc_chckbxNewCheckBox.gridy = i;
			panel_13.add(chckbxNewCheckBox, gbc_chckbxNewCheckBox);
			i=i+1;
		}
		panel_13.revalidate();
		panel_13.repaint();
		JButton btnRemoverPerfil = new JButton("Remover Perfil");
		btnRemoverPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					AFachada.removerPerfil(n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPerfis();
				atualizarPerms(null);
				lblSelecionarPerfil.setText("Selecionar Perfil:");
			}
		});
		GridBagConstraints gbc_btnRemoverPerfil = new GridBagConstraints();
		gbc_btnRemoverPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnRemoverPerfil.gridx = 0;
		gbc_btnRemoverPerfil.gridy = i;
		panel_13.add(btnRemoverPerfil, gbc_btnRemoverPerfil);
	}
	
	private void atualizarContas() {
		panel_1.removeAll();
		ArrayList<String> refs;
		refs = AFachada.getContaNames();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JButton btnConta = new JButton(refs.get(i));
			btnConta.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					CPFselecion = AFachada.getCPFConta(btnConta.getText());
					atualizarContas();
				}
			});
			GridBagConstraints gbc_btnConta = new GridBagConstraints();
			gbc_btnConta.anchor = GridBagConstraints.WEST;
			gbc_btnConta.insets = new Insets(0, 0, 5, 0);
			gbc_btnConta.gridx = 0;
			gbc_btnConta.gridy = i;
			panel_1.add(btnConta, gbc_btnConta);
			i=i+1;
		}
		JButton btnNovaConta = new JButton("Nova Conta");
		btnNovaConta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String vnome =JOptionPane.showInputDialog("Nome da Conta");
				if (AFachada.procurarAccountPorNome(vnome)!=null) {
					JOptionPane.showMessageDialog(frame, "Este Nome j� existe");
					return;
				}
				String vcpf = JOptionPane.showInputDialog("CPF da Conta");
				if (AFachada.getContaName(vcpf)!=null) {
					JOptionPane.showMessageDialog(frame, "Este CPF j� existe");
					return;
				}
				String vsenha =JOptionPane.showInputDialog("Senha da Conta");
				String vperfil =JOptionPane.showInputDialog("Perfil da Conta");
				try {
					AFachada.CadastrarConta(vnome,vcpf,vperfil,vsenha);
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarContas();
			}
		});
		GridBagConstraints gbc_btnNovaConta = new GridBagConstraints();
		gbc_btnNovaConta.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovaConta.gridx = 0;
		gbc_btnNovaConta.gridy = i;
		panel_1.add(btnNovaConta, gbc_btnNovaConta);
		
		lblNome_2.setText("Nome: " + AFachada.getContaName(CPFselecion)); 
		lblCpf_1.setText("CPF: " + CPFselecion); 
		lblPerfil.setText("Perfil: " + AFachada.getPerfilConta(CPFselecion)); 
		lblSalario.setText("Salario: " + AFachada.getSalarConta(CPFselecion)); 
		lblSenha_1.setText("Senha: ");// + AFachada.getSenhaConta(CPFselecion)); 
		
		panel_1.revalidate();
		panel_1.repaint();
	}
	
	private void atualizarPedidos() {
		panel_15.removeAll();
		ArrayList<String> refs = AFachada.getNOrdemPedidos();
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JButton btnNome = new JButton(refs.get(i));
			btnNome.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Pedidoselecion = btnNome.getText();
					atualizarPedidos();
				}
			});
			GridBagConstraints gbc_btnNome = new GridBagConstraints();
			gbc_btnNome.insets = new Insets(0, 0, 5, 0);
			gbc_btnNome.anchor = GridBagConstraints.WEST;
			gbc_btnNome.gridx = 0;
			gbc_btnNome.gridy = i;
			panel_15.add(btnNome, gbc_btnNome);
			i=i+1;
		}
		JButton btnNovoPerfil = new JButton("Novo Pedido");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Numero de ordem");
				try {
					AFachada.cadastrarPedido(n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				atualizarPedidos();
				
			}
		});
		GridBagConstraints gbc_btnNovoPerfil = new GridBagConstraints();
		gbc_btnNovoPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoPerfil.gridx = 0;
		gbc_btnNovoPerfil.gridy = i;
		panel_15.add(btnNovoPerfil, gbc_btnNovoPerfil);
		

		lblNomecliente.setText("NomeCliente: "+AFachada.getClientePedido(Pedidoselecion)); //Nome cliente, do pedido selecionado
		lblNordem_1.setText("N.Ordem: "+Pedidoselecion); //N.Ordem, do pedido selecionado 
		lblEntrada_1.setText("Entrada: "+AFachada.getEntradaPedido(Pedidoselecion)); //Entrada do pedido selecionado
		lblSaida_1.setText("Saida: "+AFachada.getSaidaPedido(Pedidoselecion)); //saida to pedido selecionado
		String p1 = AFachada.getPreoTotPedido(Pedidoselecion);
		String p2 = AFachada.getPreoExtPedido(Pedidoselecion);
		int v1 = 0;
		if (p1!=null) {
			v1 = Integer.parseInt(p1);
			if (p2!=null) {
				v1=v1+Integer.parseInt(p2);
			}
		}
		lblPreoTotal.setText("Pre�o Items: "+p1); //pre�o dos items , do pedido selecionado
		lblPreoExra.setText("Pre�o Extra: "+p2);//pre�o extra , do pedido
		lblPreoTotal_1.setText("Pre�o Total: "+v1);//pre�o dos items + extra
		lblLocal_1.setText("Local: "+AFachada.getLocalPedido(Pedidoselecion));//Local
		lblEstado_2.setText("Estado: "+AFachada.getEstadoPedido(Pedidoselecion));;//estado do pedido (Editando, Em espera, Em preparo, Pronto, Em entrega, Encerrado, Cancelado)
		
		AtualizarItems();
		panel_15.revalidate();
		panel_15.repaint();
	}
	
	private void AtualizarItems() {
		if (Pedidoselecion==null) {
			return;
		}
		panel_16.removeAll();
		ArrayList<String> refs = AFachada.getItemsDoPedido(Pedidoselecion);
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			JButton btnNomeperfil = new JButton(AFachada.getQuantiRefei(Pedidoselecion,refs.get(i))+"x "+ refs.get(i));
			String truename = refs.get(i);
			btnNomeperfil.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						AFachada.removRefeiPedido(Pedidoselecion,truename);
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(frame, e1.getMessage());
					}
					atualizarPedidos();
				}
			});
			GridBagConstraints gbc_btnNomeperfil = new GridBagConstraints();
			gbc_btnNomeperfil.anchor = GridBagConstraints.WEST;
			gbc_btnNomeperfil.insets = new Insets(0, 0, 5, 0);
			gbc_btnNomeperfil.gridx = 0;
			gbc_btnNomeperfil.gridy = i;
			panel_16.add(btnNomeperfil, gbc_btnNomeperfil);
			i=i+1;
		}
		JButton btnNovoPerfil = new JButton("Novo Item");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Nome do Item:");
				if (n==null || n.isEmpty()) {
					return;
				}
				try {
					AFachada.addRefeiPedido(Pedidoselecion,n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				
				atualizarPedidos();
				
			}
		});
		GridBagConstraints gbc_btnNovoPerfil = new GridBagConstraints();
		gbc_btnNovoPerfil.insets = new Insets(0, 0, 5, 0);
		gbc_btnNovoPerfil.gridx = 0;
		gbc_btnNovoPerfil.gridy = i;
		panel_16.add(btnNovoPerfil, gbc_btnNovoPerfil);
		panel_16.revalidate();
		panel_16.repaint();
	}
	
	private void AtualizarCozinha() {
		panel_5.removeAll();
		ArrayList<String> refs = AFachada.getNOrdemPedidos();
		int a=0;
		int i = 0;
		int u = refs.size()-1;
		while (i<=u) {
			if (AFachada.getEstadoPedido(refs.get(i)).compareTo("editando")==0) {
				i=i+1;
				continue;
			}
			ArrayList<String> refs2 = AFachada.getItemsDoPedido(refs.get(i));
			int ii = 0;
			int uu = refs2.size()-1;
			while (ii<=uu) {	
				String trueid = refs2.get(ii);
				JPanel panel_6 = new JPanel();
				panel_6.setLayout(null);
				GridBagConstraints gbc_panel_6 = new GridBagConstraints();
				gbc_panel_6.fill = GridBagConstraints.BOTH;
				gbc_panel_6.insets = new Insets(0, 0, 5, 0);
				gbc_panel_6.gridx = 0;
				gbc_panel_6.gridy = a;
				a=a+1;
				panel_5.add(panel_6, gbc_panel_6);
				
				JLabel label_2 = new JLabel(AFachada.getQuantiRefei(refs.get(i),refs2.get(ii))+"x "+refs2.get(ii));//id da refei�ao
				label_2.setBounds(10, 4, 231, 14);
				panel_6.add(label_2);
				
				JLabel lblNordem_2 = new JLabel(refs.get(i));
				lblNordem_2.setBounds(262, 4, 65, 14);
				panel_6.add(lblNordem_2);
				
				JButton button_2 = new JButton("Pronto");
				button_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						try {
							System.out.println("clk");
							AFachada.setEstadoRefeiPedido(lblNordem_2.getText(),trueid,"Pronto");
							//AFachada.eatItemPedidoRefei(lblNordem_2.getText(),trueid);
							
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(frame, e1.getMessage());
						}
						AtualizarCozinha();
						
					}
				});
				button_2.setBounds(564, 4, 89, 23);
				panel_6.add(button_2);
				
				JButton button_3 = new JButton("Em Preparo");
				button_3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						try {
							AFachada.setEstadoRefeiPedido(lblNordem_2.getText(),trueid,"Em Preparo");
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(frame, e1.getMessage());
						}
						AtualizarCozinha();
						
					}
				});
				button_3.setBounds(465, 4, 89, 23);
				panel_6.add(button_3);
				
				JPanel panel_4 = new JPanel();
				panel_4.setBackground(Color.PINK);
				panel_4.setBounds(337, 4, 118, 23);
				panel_6.add(panel_4);
				JLabel lblEstado_1 = new JLabel(AFachada.getEstadoRefei�ao(refs.get(i),refs2.get(ii)));
				panel_4.add(lblEstado_1);
				lblEstado_1.setBackground(Color.PINK);
				
				JLabel lblEntrada_2 = new JLabel(AFachada.getEntradaPedido(refs.get(i)));
				lblEntrada_2.setBounds(10, 30, 317, 14);
				panel_6.add(lblEntrada_2);
				
				JLabel lblSaida_2 = new JLabel(AFachada.getSaidaRefeiPedido(refs.get(i),refs2.get(ii)));
				lblSaida_2.setBounds(337, 30, 317, 14);
				panel_6.add(lblSaida_2);
				ii=ii+1;
			}
			i=i+1;
		}
		JButton btnNovoPerfil = new JButton("Novo Item");
		btnNovoPerfil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = JOptionPane.showInputDialog("Nome do Item:");
				try {
					AFachada.addRefeiPedido(Pedidoselecion,n);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(frame, e1.getMessage());
				}
				
				atualizarPedidos();
				
			}
		});
		panel_5.revalidate();
		panel_5.repaint();
	}
	
	
	
	private void AtualizarLogin() {
		String r = "usuario";
		String rr = AFachada.getnomeusuarioatual();
		if (rr!=null) {
			r=rr;
		}
		lblBemVindoUsuario.setText("Bem vindo "+r);
	}
}
