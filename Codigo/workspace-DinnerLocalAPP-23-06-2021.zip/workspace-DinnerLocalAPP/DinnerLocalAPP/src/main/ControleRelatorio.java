package main;

public class ControleRelatorio {

	public ControleRelatorio(Fachada fachada) {
		// TODO Auto-generated constructor stub
	}

}
