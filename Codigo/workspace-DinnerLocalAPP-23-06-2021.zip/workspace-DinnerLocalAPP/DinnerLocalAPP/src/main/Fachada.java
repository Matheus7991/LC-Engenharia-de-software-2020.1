package main;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.Icon;

import dados.Conexao;
import dados.RepositorioPerfil;

public class Fachada {
	
	private ControleAccount OControleAccount;
	private ControleItemPedido OControleItemPedido;
	private ControlePedido OControlePedido;
	private ControlePerfil OControlePerfil;
	private ControleRefei�ao OControleRefei�ao;
	private ControleRelatorio OControleRelatorio;
	
	private static Fachada instance;
	
	public static Fachada newFachada() {
		if (instance==null) {
			instance = new Fachada();
		}
		return instance;
	}
	
	private Fachada() {
		OControleAccount = new ControleAccount(this);
		OControleItemPedido = new ControleItemPedido(this);
		OControlePedido= new ControlePedido(this);
		OControlePerfil= new ControlePerfil(this);
		OControleRefei�ao= new ControleRefei�ao(this);
		OControleRelatorio= new ControleRelatorio(this);
	}
	
	
	//test variables
	public void testvar() {
		boolean useSQLserver =true;
		
		if(useSQLserver==true) {
		//TODO move startup functions to the controller`s constructors
		try {
			Conexao.StartConnection();
		} catch (ClassNotFoundException | SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		//ControlePerfil.removerPerfil("faxineiro");
		try {
			OControlePerfil.atualizar();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			OControleAccount.atualizar();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			OControleItemPedido.atualizar();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		}else {
			OControlePerfil.cadastrarPerfil("Gerente");
			OControlePerfil.modPermPerfil("Gerente", "ModCardapio", true);
			OControlePerfil.modPermPerfil("Gerente", "ModPedidos", true);
			OControlePerfil.modPermPerfil("Gerente", "ModCozinha", true);
			OControlePerfil.modPermPerfil("Gerente", "ModPerfil", true);
			OControlePerfil.modPermPerfil("Gerente", "ModItemPedidos", true);
			
			OControleAccount.cadastrarAccount("00011122233", "1234");
			OControleAccount.setNome("00011122233","gerente");
			try {
				OControleAccount.setPerfil("00011122233","Gerente");
			} catch (Exception e1) {
			}
		}
		
		try {
			OControleRefei�ao.atualizar();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		/*
		OControlePerfil.cadastrarPerfil("Gerente");
		OControlePerfil.modPermPerfil("Gerente", "ModCardapio", true);
		OControlePerfil.modPermPerfil("Gerente", "ModPedidos", true);
		OControlePerfil.modPermPerfil("Gerente", "ModCozinha", true);
		OControlePerfil.modPermPerfil("Gerente", "ModPerfil", true);
		OControlePerfil.modPermPerfil("Gerente", "ModItemPedidos", true);
		
		
		
		OControlePerfil.cadastrarPerfil("Atendente");
		OControlePerfil.modPermPerfil("Atendente", "ModPedidos", true);
		OControlePerfil.modPermPerfil("Atendente", "ModCozinha", true);
		
		OControleAccount.cadastrarAccount("11122233344", "1234");
		OControleAccount.setNome("11122233344","atendente");
		try {
			OControleAccount.setPerfil("11122233344","Atendente");
		} catch (Exception e) {
		}
		
		ControleRefei�ao.cadastrarRefei�ao("ref1");
		ControleRefei�ao.modPreco("0",1000);
		ControleRefei�ao.cadastrarRefei�ao("ref2");
		ControleRefei�ao.modPreco("1",2000);
		
		
		OControleAccount.cadastrarAccount("00011122233", "1234");
		OControleAccount.setNome("00011122233","gerente");
		try {
			OControleAccount.setPerfil("00011122233","Gerente");
		} catch (Exception e1) {
		}
		
		try {
			Repositorio.EndConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
	}
	//test variables end
	
	
	
	public ArrayList<Refei�ao> getRefei(){
		//recebe uma lista de refei�oes
		return OControleRefei�ao.getRefei();
	}
	
	
	
	public void addRefei(String nome) throws IOException {
		//cria uma refei�ao
		OControleRefei�ao.cadastrarRefei�ao(nome); //TODO ask for nid
	}
	public void removRefei(String nome) throws IOException {
		//remove uma refei�ao
		OControleRefei�ao.removerRefei�ao(nome);
	}
	//move to OControleRefei�ao end

	public ArrayList<String> getPerfilNames() {
		//recebe nomes dos perfis
		return OControlePerfil.getPerfisNames();
	}

	public ArrayList<String> getPerfilPermNames() {
		//recebe nomes das permissoes dos perfis
		return OControlePerfil.getPerfisPermNames();
	}

	public void removerPerfil(String n) throws IOException {
		//remove um perfil
		OControlePerfil.removerPerfil(n);
		
	}

	public boolean getPerfPerm(String n, String n2) {
		//recebe a permissao de um perfil
		return OControlePerfil.getPerfPerm(n,n2);
	}

	public void setPerfPerm(String n, String n2, boolean value) throws Exception {
		//muda a permissao de um perfil
		OControlePerfil.setPerfPerm(n,n2,value);
	}

	public void cadastrarPerfil(String n) throws IOException {
		//cria um perfil
		OControlePerfil.cadastrarPerfil(n);
		
	}

	public ArrayList<String> getContaNames() {
		return OControleAccount.getContaNames();
	}

	public void modNomeConta(String CPF, String v) throws IOException {
		//modifica o nome da conta
		OControleAccount.setNome(CPF,v);
		
	}

	public void modCPFConta(String CPF, String v) throws IOException {
		//modifica o CPF da conta
		OControleAccount.setCPF(CPF, v);
		
	}

	public void modPerfConta(String CPF, String v) throws Exception {
		//modifica o perfil da conta
		OControleAccount.setPerfil(CPF,v);
		
	}

	public void modSalarioConta(String CPF, int v) throws IOException {
		//modifica o salario da conta
		OControleAccount.setSalario(CPF,v);
		
	}

	public void modSenhaConta(String CPF, String v) throws IOException {
		//modifica a senha da conta
		OControleAccount.setSenha(CPF,v);
		
	}

	public String GetSenha(String CPF) {
		//recebe a senha da conta
		return OControleAccount.getSenha(CPF);
	}

	public void removerConta(String CPF) throws IOException {
		//remove uma conta
		OControleAccount.removerAccount(CPF);
		
	}

	public String getContaName(String CPF) {
		//recebe o nome da conta
		return OControleAccount.getContaName(CPF);
	}

	public String getPerfilConta(String CPF) {
		//recebe o perfil da conta
		return OControleAccount.getPerfil(CPF);
	}

	public String getSalarConta(String CPF) {
		//recebe o salario da conta
		return OControleAccount.getSalario(CPF);
	}


	public String getCPFConta(String text) {
		//procura uma conta pelo CPF
		return OControleAccount.getCPFConta(text);
	}

	public void CadastrarConta(String nome, String cpf, String perfil,String senha) throws Exception {
		//cria uma conta
		OControleAccount.cadastrarAccount(cpf, senha);
		OControleAccount.setNome(cpf,nome);
		OControleAccount.setPerfil(cpf,perfil);
		
	}

	public Object procurarAccountPorNome(String vnome) {
		//procura uma conta pelo nome
		return OControleAccount.procurarAccountPorNome(vnome);
	}

	public String getnomeusuarioatual() {
		//recebe o nome do usuario atual
		return OControleAccount.getNomeAtual();
	}

	public ArrayList<String> getNOrdemPedidos() {
		//recebe uma lista com o numero de ordem dos pedidos
		return OControlePedido.getNOrdemPedidos();
	}

	public void cadastrarPedido(String n) throws IOException {
		//Cria um pedido
		OControlePedido.cadastrarPedido(n);
		
	}

	public String getClientePedido(String nOrdem) {
		//recebe o cliente do pedido
		return OControlePedido.getClientePedido(nOrdem);
	}

	public String getEntradaPedido(String nOrdem) {
		//recebe o horario e dia em que o pedido entrou
		return OControlePedido.getEntradaPedido(nOrdem);
	}

	public String getSaidaPedido(String nOrdem) {
		//recebe o horario e dia em que o pedido saiu
		return OControlePedido.getSaidaPedido(nOrdem);
	}

	public String getPreoTotPedido(String nOrdem) {
		//recebe a soma do pre�o de todos os items de um pedido
		return OControlePedido.getPreoTotPedido(nOrdem);
	}

	public String getPreoExtPedido(String nOrdem) {
		//recebe o pre�o extra um pedido
		return OControlePedido.getPreoExtPedido(nOrdem);
	}

	public String getLocalPedido(String nOrdem) {
		//recebe o local um pedido
		return OControlePedido.getLocalPedido(nOrdem);
	}

	public String getEstadoPedido(String nOrdem) {
		//recebe o estado de um pedido
		return OControlePedido.getEstadoPedido(nOrdem);
	}

	public void setClientePedido(String nOrdem, String v) throws IOException {
		//muda o cliente de um pedido
		OControlePedido.setClientePedido(nOrdem,v);
		
	}

	public void setPreoExtPedido(String nOrdem, String v) throws IOException {
		//muda o pre�o extra de um pedido
		OControlePedido.setPreoExtPedido(nOrdem, v);
		
	}

	public void setLocalPedido(String nOrdem, String v) throws IOException {
		//muda o local de um pedido
		OControlePedido.setLocalPedido(nOrdem, v);
		
	}

	public void EnviarPedido(String nOrdem) throws IOException {
		//muda o estado de um pedido para "Em preparo"
		OControlePedido.enviarPedido(nOrdem);
		
	}

	public ArrayList<String> getItemsDoPedido(String nOrdem) {
		//recebe nomes das refei�oes do pedido
		return OControlePedido.getRefeiPedido(nOrdem);
	}

	public void addRefeiPedido(String nOrdem, String n) throws IOException {
		//adiciona uma refei�ao a um pedido
		OControlePedido.addRefeiPedido(nOrdem,n);
		
	}

	public void removRefeiPedido(String nOrdem, String text) throws IOException {
		//remove uma refei�ao de um pedido
		OControlePedido.removRefeiPedido(nOrdem,text);
		
	}

	public String getEstadoRefei�ao(String nOrdem, String refei) {
		//recebe o estado do pedido
		return OControlePedido.getEstadoRefei�ao(nOrdem, refei);
	}

	public void setEstadoRefeiPedido(String nOrdem, String refei, String text) throws IOException {
		//muda o estado de uma refei�ao de um pedido
		OControlePedido.setEstadoRefeiPedido(nOrdem,refei,text);
		
	}

	public String getQuantiRefei(String nOrdem, String refei) {
		//recebe a quantidade de uma refei�ao de um pedido
		return OControlePedido.getQuantiRefei(nOrdem,refei);
	}

	public void setEstadoPedido(String nOrdem, String string) throws IOException {
		//muda o estado do pedido
		OControlePedido.setEstadoPedido(nOrdem, string);
		
	}

	public void setEstadoTRefeiPedido(String nOrdem, String string) throws IOException {
		//muda o estado de todas as refei�oes de um pedido
		OControlePedido.setEstadoTRefeiPedido(nOrdem, string);
	}

	public String getSaidaRefeiPedido(String string, String string2) {
		return OControlePedido.getSaidaRefeiPedido(string,string2);
	}


	public void removPedido(String pedidoselecion) throws IOException {
		OControlePedido.removerPedido(pedidoselecion);
	}


	public void setNomeItemPedido(String nome, String novonome) throws IOException {
		OControleItemPedido.setNome(nome,novonome);
		
	}


	public void setQuantItemPedido(String nome, int novovalor) throws IOException {
		OControleItemPedido.setQuant(nome,novovalor);
		
	}


	public ArrayList<String> getItemPedNames() {
		return OControleItemPedido.GetNames();
	}


	public void cadastrarItemPedido(String n) throws IOException {
		OControleItemPedido.cadastrarItemPedido(n);
	}


	public int getQuantiItemPedido(String n) {
		return OControleItemPedido.getQuantiItemPedido(n);
	}


	public String getSufixItemPedido(String n) {
		return OControleItemPedido.getSufix(n);
	}


	public String getValidItemPedido(String n) {
		return OControleItemPedido.getValid(n);
	}


	public void setSufixItemPedido(String n, String n2) throws IOException {
		OControleItemPedido.setSufix(n,n2);
	}


	public void setValidItemPedido(String n, String v3, String v2, String v) throws IOException {
		OControleItemPedido.setValid(n,v3,v2,v);
		
	}


	public void removerItemPedido(String itemPedidoSelecion) throws IOException {
		OControleItemPedido.removerItemPedido(itemPedidoSelecion);
	}


	public ArrayList<String> getRefeiID() {
		return OControleRefei�ao.getIDs();
	}


	public ArrayList<String> getIngredRefei(String n) {
		if (n==null) {
			return null;
		}
		return OControleRefei�ao.getIgred(n);
	}


	public void removIgredRefei(String ID, String n) throws IOException {
		OControleRefei�ao.removIgred(ID,n);
	}


	public void addIgredRefei(String n, String n2,int q) throws IOException {
		OControleRefei�ao.addIgred(n,n2,q);
		
	}


	public String getNomeRefei(String n) {
		if (n==null) {
			return null;
		}
		return OControleRefei�ao.getnome(n);
	}


	public int getPrecoFRefei(String n) {
		if (n==null) {
			return 0;
		}
		return OControleRefei�ao.getpreco(n);
	}


	public void modnomeRefei(String n, String n2) throws IOException {
		OControleRefei�ao.setnome(n,n2);
	}


	public void modCustRefei(String n, String n2) throws IOException {
		OControleRefei�ao.modPreco(n2, Integer.parseInt(n));
		
	}


	public void eatItemPedidoRefei(String Nordem, String IDrefei) throws IOException {
		OControlePedido.eatItemPedido(Nordem,IDrefei);
	}


	public void login(String CPF, String Senh) {
		OControleAccount.login(CPF, Senh);
		
	}


	public ControlePerfil getControlePerfil() {
		return OControlePerfil;
	}


	public void getAccess(String string) throws IOException {
		OControleAccount.getAccess(string);
		
	}


	public Refei�ao procurarRefei�ao(String n) {
		return OControleRefei�ao.procurarRefei�ao(n);
	}


	public void ItemPedidoreduzir(String string, int i) {
		OControleItemPedido.reduzir(string, i);
		
	}

	public String ItemPedidogetSufix(String string) {
		return OControleItemPedido.getSufix(string);
	}

	public ItemPedido ItemPedidoprocurarItemPedido(String n) {
		// TODO Auto-generated method stub
		return OControleItemPedido.procurarItemPedido(n);
	}

	public void logoff() {
		OControleAccount.logoff();
	}

}


