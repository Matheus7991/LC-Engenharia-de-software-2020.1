package dadosArquivo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Archive {
	
	private static Userdat lerDoArquivo() {
		Userdat instanciaLocal = null;

	    File in = new File("Datab.dat");
	    FileInputStream fis = null;
	    ObjectInputStream ois = null;
	    try {
	    		fis = new FileInputStream(in);
	    		ois = new ObjectInputStream(fis);
	    		Object o = ois.readObject();
	    		instanciaLocal = (Userdat) o;
	    		System.out.print("read data "+o+"\n");
	    } catch (Exception e) {
	    		instanciaLocal = new Userdat();
	    		System.out.print("new data "+instanciaLocal+"\n");
	    } finally {
	    		if (ois != null) {
	    			try {
	    				ois.close();
	    			} catch (IOException e) {/* Silent exception */
	    			}
	    		}
	    }
		return instanciaLocal;
	}
	
	static private Userdat Pontos=lerDoArquivo();
	
	public static void send_userdata() {
		File out = new File("Datab.dat");
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		try {
		      fos = new FileOutputStream(out);
		      oos = new ObjectOutputStream(fos);
		      oos.writeObject(Pontos);
		      System.out.print("wrote data");
		} catch (Exception e) {
		      e.printStackTrace();
		} finally {
		      if (oos != null) {
		        try {
		          oos.close();
		        } catch (IOException e) {
		        }
		      }
		}
		
		
	}
	
	public static void Apagar() {
		Pontos = new Userdat();
		send_userdata();
	}

	public static Userdat getPontos() {
		return Pontos;
	}
}
