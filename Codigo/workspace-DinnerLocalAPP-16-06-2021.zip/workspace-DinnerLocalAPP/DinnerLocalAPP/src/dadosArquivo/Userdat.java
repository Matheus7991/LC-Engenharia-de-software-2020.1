package dadosArquivo;

import java.util.ArrayList;

import java.io.Serializable;

public class Userdat implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	static class account implements Serializable{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		public String firstname="primeiro";
		public String secondname="ultimo";
		public String address = "55";
		public String birth = "00/00/0000";
		public String email = "decim21686@lidte.com"; //https://temp-mail.org/pt/view/b98e876cd11e5959493694abf8e1d2cf
		public String npass = "NikeNike";
		public String CPF = "005.245.020-13";
		public String datanascimento = "1/1/1999";
		public String phone = "2222222222";
		public String CEP = "69306-502";
		public String numeroend = "120";
		
		public String cardnumber = "5479 3492 5037 2309";
		public String expirationdatemonth="09";
		public String expirationdateyear="22";
		public String securitycode="823";
		public String gender;
		public String destiny;
		public String cardname;
		public String cardcpf;
		
	}
	public account man = new account();
	public int updatetime=10;
	
	public static class item implements Serializable{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		//public String releasedate = "";
		public String itname;
		public int r_day;
		public int r_month;
		public int r_year;
		public int r_hour;
		public int r_minute;
		public String weblink = "";
		public String size ="0";
		public String price="";
		public boolean tobuy = false;
	}
	
	//remenber arraylist
	ArrayList<item> items = new ArrayList<item>();
	ArrayList<item> cart = new ArrayList<item>();
	
	public void insertitem(String itname,int r_day,int r_month,int r_year,int r_hour,int r_minute,String weblink,String price) {
		item newitem = new item();
		newitem.itname = itname;
		newitem.r_day = r_day;
		newitem.r_month = r_month;
		newitem.r_year = r_year;
		newitem.r_hour = r_hour;
		newitem.weblink = weblink;
		newitem.price = price;
		items.add(newitem);
	}
	
	public void clearitems() {
		items.clear();
	}
	
	public item getitembyid(int o) {
		item ret = null;
		try {
			ret = items.get(o);
		}catch(Exception e) {
			
		}
		return ret;
	}
	
	public item getitembyname(String o) {
		item ret = null;
		int i =0;
		int u = items.size();
		item lel = null;
		while (i<u) {
			lel = getitembyid(i);
			if (lel.itname.compareTo(o)==0) {
				ret=lel;
				break;
			}
			i+=1;
		}
		
		return ret;
	}
	
	public item getcartitembyid(int o) {
		item ret = null;
		try {
			ret = cart.get(o);
		}catch(Exception e) {
			
		}
		return ret;
	}
	
	public item getcartitembyname(String o) {
		item ret = null;
		int i =0;
		int u = cart.size();
		item lel = null;
		while (i<u) {
			lel = getcartitembyid(i);
			if (lel.itname.compareTo(o)==0) {
				ret=lel;
				break;
			}
			i+=1;
		}
		
		return ret;
	}
	
}
