package dados;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RepositorioRefei�ao extends Repositorio {
	public void createtable() throws SQLException {//execute if table doesnt exists
		String createtable =
						"";
		Execute(createtable);
	}

	public void cadastrarRefei�ao(String nome) throws SQLException {
		String cmd = "INSERT INTO `new_testschema`.`refei�ao` (`NomeRefei�ao`) VALUES ('"+nome+"');";
		Execute(cmd);
		
	}

	public void removerRefei�ao(String n) throws SQLException {
		String cmd = "DELETE FROM `new_testschema`.`refei�ao` WHERE (`NomeRefei�ao` = '"+n+"');";
		Execute(cmd);
		
	}

	public ArrayList<ArrayList<String>> getUpdate() throws SQLException {
		ResultSet results = Query("SELECT * FROM new_testschema.refei�ao;");
		ArrayList<ArrayList<String>> r = new ArrayList<ArrayList<String>>();
		while (results.next()) {
			ArrayList<String> rr = new ArrayList<String>();
			rr.add(results.getString("NomeRefei�ao"));
			rr.add(results.getString("custo"));
			rr.add(results.getString("igredientes"));
			rr.add(results.getString("Qigredientes"));
			r.add(rr);
		}
		return r;
	}
	
	public void updateatribute(String id, String nomeatribut, String novovalor) throws SQLException {
		String cmd = "UPDATE `new_testschema`.`refei�ao` SET `"+nomeatribut+"` = '"+novovalor+"' WHERE (`idRefei�ao` = '"+id+"');";
		Execute(cmd);
	}
	

}
