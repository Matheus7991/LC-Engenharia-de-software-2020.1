package main;

import java.io.IOException;
import java.util.ArrayList;

public class ControlePedido {
	
	private ArrayList<Pedido> Pedidos = new ArrayList<Pedido>();
	private Fachada AFachada;
	//Cadastrar
	//Remover
	//Atualizar
	//Procurar
	//Relatorio (Custo total de todos os pedidos)
	
	//encerrar pedido (o cliente esta pagando)
	
	public ControlePedido(Fachada eFachada) {
		AFachada = eFachada;
	}

	public void cadastrarPedido(String Nordem) throws IOException {
		AFachada.getAccess("ModPedidos");
		if (procurarPedido(Nordem)!=null) {
			return;
		}
		Pedido P = new Pedido(Nordem, AFachada);
		Pedidos.add(P);
	}
	
	public void removerPedido(String Nordem) throws IOException {
		AFachada.getAccess("ModPedidos");
		Pedido r = procurarPedido(Nordem);
		if (r==null) {
			return;
		}
		Pedidos.remove(r);
		
	}
	
	public void atualizar() {
		
	}
	
	public Pedido procurarPedido(String Nordem) {
		if (Nordem==null) {
			return null;
		}
		int u = Pedidos.size()-1;
		int i = 0;
		while (i<=u) {
			Pedido o = Pedidos.get(i);
			if (o.getNordem().compareTo(Nordem)==0) {
				return o;
			}
			
			i=i+1;
		}
		return null;
	}

	public ArrayList<String> getNOrdemPedidos() {
		ArrayList<String> r = new ArrayList<String>();
		int u = Pedidos.size()-1;
		int i = 0;
		while (i<=u) {
			Pedido o = Pedidos.get(i);
			r.add(o.getNordem());
			
			i=i+1;
		}
		return r ;
	}

	public String getClientePedido(String Nordem) {
		if (Nordem==null) {
			return null;
		}
		Pedido p = procurarPedido(Nordem);
		if (p==null) {
			return null;
		}
		return p.getCliente();
	}

	public String getEntradaPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getEntrada();
	}

	public String getSaidaPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getSaida();
	}

	public String getPreoTotPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getPreoTotal();
	}

	public String getPreoExtPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getPreoExtra();
	}

	public String getLocalPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getLocal();
	}

	public String getEstadoPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getEstado();
	}

	public void setClientePedido(String nOrdem, String v) throws IOException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setCliente(v);
	}

	public void setPreoExtPedido(String nOrdem, String v) throws IOException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setPreoExt(v);
	}

	public void setLocalPedido(String nOrdem, String v) throws IOException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setLocal(v);
		
	}

	public void enviarPedido(String nOrdem) throws IOException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.enviar();
		
	}

	public ArrayList<String> getRefeiPedido(String nOrdem) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getRefeiList(nOrdem);
		
	}

	public void addRefeiPedido(String nOrdem, String n) throws IOException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.addRefei(n);
		
	}

	public void removRefeiPedido(String nOrdem, String text) throws IOException {
		AFachada.getAccess("ModPedidos");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.removRefei(text);
	}

	public String getEstadoRefei�ao(String nOrdem, String refei) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getEstadoRefei(refei);
		
	}

	public void setEstadoRefeiPedido(String nOrdem, String refei, String text) throws IOException {
		AFachada.getAccess("ModCozinha");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setEstadoRefei(refei,text);
		
	}

	public String getQuantiRefei(String nOrdem, String refei) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getQuantiRefei(refei);
	}

	public void setEstadoPedido(String nOrdem, String string) throws IOException {
		AFachada.getAccess("ModCozinha");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setEstado(string);
	}

	public void setEstadoTRefeiPedido(String nOrdem, String string) throws IOException {
		AFachada.getAccess("ModCozinha");
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return;
		}
		p.setEstadoTRefei(string);
	}

	public String getSaidaRefeiPedido(String nOrdem, String string2) {
		Pedido p = procurarPedido(nOrdem);
		if (p==null) {
			return null;
		}
		return p.getSaidaRefeiPedido(string2);
	}

	public void eatItemPedido(String nordem, String iDrefei) throws IOException {
		AFachada.getAccess("ModCozinha");
		Pedido p = procurarPedido(nordem);
		if (p==null) {
			return;
		}
		System.out.println("clk3");
		p.eatItemPedido(iDrefei);
		
	}
	
	
}
